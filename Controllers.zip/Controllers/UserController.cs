﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace smartmeter.Controllers
{
    public class UserController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpGet,Route("User/Edit/{Id}")]
        public ActionResult Edit(int Id)
        {
            ViewBag.Id = Id;
            return View();
        }
    }
}