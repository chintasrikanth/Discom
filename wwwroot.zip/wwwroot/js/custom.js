(function($) {
  'use strict';

  var Custom = {

    warningModal: function() {
      var el = $('.modal-alert-warning');
      if ( !el.length ) return;
      el.on('click', function () {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonClass: 'btn btn-warning',
          confirmButtonText: 'Yes, delete it!'
        }).then(function () {
          swal({
            title: 'Deleted!',
            text: 'Your file has been deleted.',
            type: 'success',
            confirmButtonClass: 'btn btn-success'
          });
        });
      });
    },

    cancelModal: function() {
      var el = $('.modal-alert-cancel');
      if ( !el.length ) return;
      el.on('click', function () {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to recover this imaginary file!",
          type: 'error',
          showCancelButton: true,
          confirmButtonClass: 'btn btn-danger',
          confirmButtonText: 'Yes, delete it!'
        }).then(function () {
          swal({
            title: 'Deleted!',
            text: 'Your imaginary file has been deleted.',
            type: 'success',
            confirmButtonClass: 'btn btn-success'
          });
        });
      });
    },

    infoModal: function() {
      var el = $('.modal-alert-info');
      if ( !el.length ) return;
      el.on('click', function () {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to recover this imaginary file!",
          type: 'info',
          showCancelButton: true,
          confirmButtonText: 'Info'
        });
      });
    },

    imageModal: function () {
      var el = $('.modal-alert-image');
      if ( !el.length ) return;
      el.on('click', function () {
        swal({
          title: 'Sweet!',
          text: "Here's a custom image.",
          confirmButtonClass: 'btn btn-success',
          imageUrl: 'https://unsplash.it/400/200',
          imageWidth: 400,
          imageHeight: 200
        });
      });
    },


    /*************** Homepage ****************/




    },
  };
  $(document).ready( function() {
    Custom.init();
  });
})(jQuery);
