﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.ViewModels
{
    public class TbRoleModel
    {

        public int Id { get; set; }
        public string Role { get; set; }
        public int? ReportingRole { get; set; }
        public long CrtBy { get; set; }
        public DateTime CrtDt { get; set; }
        public long? UpdBy { get; set; }
        public DateTime? UpdDt { get; set; }
        public byte? IsActive { get; set; }
        public string StatusDisp { get; set; }

        public string ReportingRoleName { get; set; }

    }
}
