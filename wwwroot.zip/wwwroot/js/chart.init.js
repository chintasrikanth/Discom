﻿chart = {}

chart.init = function () {
}
chart.createLineChart = function (ele, data, labels, ykeys) {
    var ctx = document.getElementById(ele);
    if (ctx === null) return;

    var chart = Morris.Bar({
        element: ele,
        data: data,
        xkey: 'period',
        ykeys: ykeys,
        labels: labels,
        ymax: 'auto[100]',
        ymin: 'auto[0]',
        pointSize: 2,
        fillOpacity: 0,
        pointStrokeColors: ['#D20A28', '#E7520C', '#1BB105'],
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        lineWidth: 1,
        hideHover: 'auto',
        barColors: ['#D20A28', '#E7520C', '#1BB105'],
        resize: true,
        parseTime: false,
        //gridTextColor: '#000000',
        //hideHover:true,
        labelTop: true        
    });   
}