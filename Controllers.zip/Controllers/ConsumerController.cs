﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace smartmeter.Controllers
{
    public class ConsumerController : Controller
    {
        [Route("Consumer/Index")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("Consumer/ConsumerDetails/{Id}")]
        public ActionResult ConsumerDetails(int Id)
        {
            ViewBag.Id = Id;
            return View();
        }

        [Route("Consumer/MasterUpload")]
        public ActionResult MasterUpload()
        {
            return View();
        }

        [Route("Consumer/CIApprovedUpload")]
        public ActionResult CIApprovedUpload()
        {
            return View();
        }

        [Route("Consumer/CIApprovedUpload_EESL")]
        public ActionResult CIApprovedUpload_EESL()
        {
            return View();
        }

        [Route("Consumer/ConsumerUpdateExcel")]
        public ActionResult ConsumerUpdateExcel()
        {
            return View();
        }

        [Route("Consumer/MIApprovedUpload_ARO")]
        public ActionResult MIApprovedUpload_ARO()
        {
            return View();
        }
    }
}