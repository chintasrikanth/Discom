﻿
myApp.controller('ConsumerCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', '$timeout', 'Excel',
    function ( $scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath, $timeout, Excel) {

    $scope.numPerPageList = [{ 'name': "5", "value": 5 }, { 'name': "10", "value": 10 }, { 'name': "20", "value": 20 }];
    $scope.sortBy = 'CrtDate';
    $scope.reverse = true;
    $scope.numPerPage = 10;
    $scope.pageNum = 1;
    $scope.totalCount = 0;
    $scope.logResultyes = "";
    $scope.Details = "";
    $scope.disCIbtn = false;
    $scope.searchString = "";
    $scope.consType = 0;

    $scope.sort = function (keyname) {
        $scope.sortBy = keyname;   //set the sortBy to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    $scope.getSortClass = function (column) {
        if ($scope.sortBy === column) {
            return $scope.reverse ? 'feather feather-arrow-down' : 'feather feather-arrow-up';
        }
    };

    $scope.GetConsumers = function (pageNum, consType) {
        if (consType == null || consType=="") {
            consType = 0;
        }
        $http.get(serviceBasePath + "Consumer/GetConsumers/" + $scope.numPerPage + "/" + pageNum + "/" + $sessionStorage.UsrId + "/" + consType + "/" + $scope.searchString.replace("/", "@")).then(function success(response) {

            if (response.data.Status == true) {
                $scope.ConsumerList = response.data.Result.ConsumerList;
                $scope.totalCount = response.data.Result.totalCount;                
            }

        }, function error() {

        });
    };

    $scope.GetConsumers($scope.pageNum, $scope.consType);

    $scope.Search = function (type) {
        $scope.GetConsumers(1, type);
    };    

    $scope.InitView = function (Id) {

        $window.open(ridirectPath + '/Consumer/ConsumerDetails/' + Id, "_self");
    };

    $scope.msg = "";
    $scope.loadFile = function (files) {

        $scope.$apply(function () {

            $scope.selectedFile = files[0];

        });

    };

    $scope.GetConsumersData = function () {
        $scope.dLoadDisabled = true;
        $http.get(serviceBasePath + "Consumer/GetConsumerList").then(function success(response) {
            if (response.data.Status == true) {
                $scope.CIList = response.data.Result.ConsumerList;
                $scope.DownloadExcel($scope.CIList);
                $scope.dLoadDisabled = false;
            }

        }, function error() {
            swal("Something Went Wrong !");
        });
    }
    
    $scope.DownloadExcel = function (cidata) { // ex: '#my-table'
            //$scope.dLoadDisabled = true;

            var row = cidata;
            var Head = [[               

                'Consumernumber',
                'Address',
                'MobileNumber',                
                'Old Meternumber',
                'OldMeter_Reading',
                'NewMeter_Number',
                'Installed Date',
                'NewMeterImage',
                'Latest_Ele_BillImage',
                'Latitude',
                'Longitude',
                'Box Seal1',
                'Box Seal2',
                'Created Date',
                'Created By',                
                'Updated Date',
                'Updated By',
            ]];
            
            for (var item = 0; item < row.length; ++item) {

                var addr = row[item].Address;
                if (row[item].Address != null) {
                    addr = row[item].Address.replace(/,/g, '"');
                    addr = addr.replace(/T/g, ' ');
                    addr = addr.trim();
                    addr = addr.replace(/\n/g, ' ');
                }

                var oldMN = row[item].OldMeter_Number;
                if (row[item].OldMeter_Number != null) {
                    oldMN = row[item].OldMeter_Number.trim();
                }                

                var instDt = row[item].InstalledDate;
                if (row[item].InstalledDate != null) {
                    instDt = row[item].InstalledDate.replace(/T/g, ' ');
                }

                var crtDt = row[item].CrtDate;
                if (row[item].CrtDate != null) {
                    crtDt = row[item].CrtDate.replace(/T/g, ' ');
                }

                var BoxSeal1 = row[item].BoxSeal1;
                if (row[item].BoxSeal1 != null) {
                    BoxSeal1 = row[item].BoxSeal1.trim();
                    BoxSeal1 = BoxSeal1.replace(/,/g, '"');
                }

                var BoxSeal2 = row[item].BoxSeal2;
                if (row[item].BoxSeal2 != null) {
                    BoxSeal2 = row[item].BoxSeal2.trim();
                    BoxSeal2 = BoxSeal2.replace(/,/g, '"');
                }

                var updDt = row[item].UpdDate;
                if (row[item].UpdDate != null) {
                    updDt = row[item].UpdDate.replace(/T/g, ' ');
                }
                
                Head.push([
                    row[item].ConsumerNumber,
                    addr,
                    row[item].MobileNumber,
                    oldMN,
                    row[item].OldMeter_Reading,
                    row[item].NewMeter_Number,
                    instDt,
                    row[item].NewMeterImage,
                    row[item].Latest_Ele_BillImage,
                    row[item].Latitude,
                    row[item].Longitude,
                    BoxSeal1,
                    BoxSeal2,
                    crtDt,
                    row[item].CrtName,
                    updDt,
                    row[item].UpdName,
                ]);
            }

            var csvRows = [];
            for (var cell = 0; cell < Head.length; ++cell) {
                csvRows.push(Head[cell].join(','));
            }

            var csvString = csvRows.join("\n");
            let csvFile = new Blob([csvString], { type: "text/csv" });
            let downloadLink = document.createElement("a");

            downloadLink.download = 'ConsumerData.csv';
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            //$scope.dLoadDisabled = false;
        }   

}]);