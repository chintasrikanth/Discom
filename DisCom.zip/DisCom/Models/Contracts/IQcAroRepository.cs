﻿using DisCom.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.Contracts
{
    public interface IQcAroRepository
    {
     
        ResponseModel GetQcPendings_CI(string type);

        ResponseModel UpdateQc_CI(QcHistoryModel details,int UsrId);
     
    }
}
