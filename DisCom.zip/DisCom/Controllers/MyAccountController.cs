﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DisCom.Models.ViewModels;
using DisCom.Models.Contracts;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MyAccountController : ControllerBase
    {
        private IMyAccountRepository _myAccountRepository;

        public MyAccountController(IMyAccountRepository myAccountRepository)
        {
            _myAccountRepository = myAccountRepository;
        }

        [HttpPost,Route("ResetPwd")]
        public ActionResult ResetPwd(TbUserModel user)
        {
            try
            {
                ResponseModel result =  _myAccountRepository.ResetPwd(user);
                
                if(result.Status == true)
                {
                    return Ok(result);
                }
                else{

                    return BadRequest(result);
                }

            } catch(Exception ex)
            {
                return null;
            }
        }
    }
}