﻿
myApp.controller('EditUserCtr', ['$scope', '$http', '$window', '$rootScope', 'serviceBasePath', 'ridirectPath', '$sessionStorage', function ($scope, $http, $window, $rootScope, serviceBasePath, ridirectPath, $sessionStorage) {

    $scope.UEModel = { UserName: "", Email: "", Mobile: "", RoleId: "", CircleId: "", DivisionId: "", SubDivionId: "", SubStationId: "", FeederCodeList: "", DtrCodeList: "", ReportingManager: "", IsActive: "" };
    $scope.StatusList = [{ 'name': "Active", 'value': 1 }, { 'name': "IN-Active", 'value': 0 }];

    $scope.isDisabled = false;

    $scope.init = function (Id) {

        $scope.Id = Id;
 
        $scope.GetUserById = function (Id) {
           
            $http.get(serviceBasePath + "User/GetUserById/" + Id).then(function success(response) {

               
                if (response.data.Status == true) {
                                      
                    item = response.data.Result;

                    console.log(item);

                    $scope.UEModel.Id = item.Id;
                    $scope.UEModel.UserName = item.UserName;
                    $scope.UEModel.Email = item.Email;
                    $scope.UEModel.Mobile = item.Mobile;
                    $scope.UEModel.RoleId = item.RoleId;
                    //$scope.UEModel.ReportingManager = item.ReportingManager;                    
                    $scope.UEModel.IsActive = item.IsActive;                      
                }

                
            }, function error() {

            });
        };

        $scope.GetRoles = function () {
            $http.get(serviceBasePath + "user/GetActiveRoles").then(function success(response) {

                if (response.data.Status === true) {
                    $scope.RoleList = response.data.Result;
                }
            }, function error() {

            });
        };
        
        $scope.GetUserById($scope.Id);

        $scope.GetRoles();

        $scope.GetDiscom = function () {
            $scope.CircleList = null;
            $http.get(serviceBasePath + "Circle/GetDiscom").then(function success(response) {

                if (response.data.Status === true) {
                    $scope.DiscomList = response.data.Result;
                }

            }, function error() {

            });
        };        

        $scope.UpdateUser = function () {
            $scope.EditUserForm.$submitted = true;
            if ($scope.EditUserForm.$valid) {

                $http.post(serviceBasePath + "user/UpdateUser", $scope.UEModel).then(function success(response) {

                    if (response.data.Status == false) {

                        swal({ title: "", text: response.data.Messege, type: "error" },
                            function () {
                                return false;
                            }
                        );

                    } else {
                        swal({ title: "", text: response.data.Messege, type: "success" },
                            function () {
                                $window.location.href = ridirectPath + '/user/index';
                            }
                        );
                    }

                }, function error() {
                    swal("Something Went Wrong !");
                });
            }
        };
    };

}]);