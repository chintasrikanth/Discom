﻿
myApp.controller('RoleCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.numPerPageList = [{ 'name': "5", "value": 5 }, { 'name': "10", "value": 10 }, { 'name': "20", "value": 20 }];
    $scope.sortBy = 'CrtDt';
    $scope.reverse = true;
    $scope.numPerPage = 5;
    $scope.pageNum = 1;
    $resultsOnPage = "";

    $scope.sort = function (keyname) {
        $scope.sortBy = keyname;   //set the sortBy to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    $scope.getSortClass = function (column) {
        if ($scope.sortBy === column) {
            return $scope.reverse ? 'feather feather-arrow-down' : 'feather feather-arrow-up';
        }
    };

    $scope.RoleList = "";
    $scope.StatusList = [{ 'name': "Active", 'value': 1 }, { 'name': "IN-Active", 'value': 0 }];

    $scope.GetRoles = function () {

        $http.get(serviceBasePath + "role/GetRoles").then(function success(response) {
            $scope.RoleList = response.data.Result;
        }, function error() {

        });
    };

    $scope.GetRoles();


    $scope.ResetForm = function () {

        $scope.RoleForm.$setPristine();
        $scope.RoleForm.$setUntouched();

        $scope.EditRoleForm.$setPristine();
        $scope.EditRoleForm.$setUntouched();


        $scope.RModel = { Role: "", IsActive: "" };
        $scope.REModel = { Role: "",IsActive: "", Id : ""};

    };

    $scope.InitRole = function () {
        $scope.ResetForm();
        $("#AddRole").modal("show");
    };


    $scope.CreateRole = function () {
        $scope.RoleForm.$submitted = true;
        if ($scope.RoleForm.$valid) {

            $http.post(serviceBasePath + "role/CreateRole", $scope.RModel).then(function success(response) {


                if (response.data.Status == false) {

                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );

                } else {
                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {
                            $window.location.href = ridirectPath + '/role/index';
                        }
                    );
                }

            }, function error() {

            });
           
        }
    };


    $scope.InitEdit = function (item) {
       
        $scope.ResetForm();
        $("#EditRole").modal("show");
        $scope.REModel.Id = item.Id;
        $scope.REModel.Role = item.Role;
        $scope.REModel.ReportingRole = item.ReportingRole;
        $scope.REModel.IsActive = item.IsActive;
       

    };


    $scope.UpdateRole = function () {

        $scope.EditRoleForm.$submitted = true;
        if ($scope.EditRoleForm.$valid) {

            $http.post(serviceBasePath + "role/UpdateRole", $scope.REModel).then(function success(response) {

                if (response.data.Status == false) {

                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );

                } else {
                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {
                            $window.location.href = ridirectPath + '/role/index';
                        }
                    );
                }

            }, function error() {

            });
        }
    };


    $scope.start = 1;
    $scope.resultsOnPage = $scope.numPerPage;

    $scope.GetPageNumber = function (pageNum) {

        if (pageNum >= 2) {

            $scope.start = (pageNum - 1) * $scope.numPerPage;

            if ($scope.RoleList.length >= pageNum * $scope.numPerPage) {

                $scope.resultsOnPage = $scope.numPerPage;
            } else {
                $scope.resultsOnPage = ($scope.RoleList.length - $scope.numPerPage) + $scope.numPerPage;
            }

        }

    };


    $scope.GetPageNumber($scope.pageNum);


}]);