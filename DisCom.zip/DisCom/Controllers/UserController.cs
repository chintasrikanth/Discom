﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
    [ApiController, Authorize]
    public class UserController : ControllerBase
    {
        private IUserRepository _userRepository;
        private IRoleRepository _roleRepository;


        public UserController(IUserRepository userRepository, IRoleRepository roleRepository)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
        }

        [HttpGet, Route("GetUsers")]
        [Authorize(Roles = "1")]
        public ActionResult GetUsers()
        {
            try
            {

                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var RoleId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.Role)?.Value);
                var Id = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);


                ResponseModel result = _userRepository.GetUsers(Id, RoleId);

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost, Route("CreateUser")]
        [Authorize(Roles = "1")]
        public ActionResult CreateUser(TbUserModel user)
        {
            try
            {
                ResponseModel result = _userRepository.CreateUser(user);

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else if (result.Status == false && result.Messege != "Something Went Wrong !")
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost, Route("UpdateUser")]
        [Authorize(Roles = "1")]
        public ActionResult UpdateUser(TbUserModel user)
        {
            try
            {
                ResponseModel result = _userRepository.UpdateUser(user);

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else if (result.Status == false && result.Messege != "Something Went Wrong !")
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpGet, Route("GetActiveRoles")]
        public ActionResult GetActiveRoles()
        {
            try
            {
                ResponseModel result = _roleRepository.GetActiveRoles();

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

       
        [HttpGet, Route("GetReportingManegers/{RoleId}/{SubStationId}")]
        public ActionResult GetReportingManegers(int RoleId, int SubStationId)
        {
            try
            {
                var result = _userRepository.GetReportingManegers(RoleId, SubStationId);

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet, Route("GetUserById/{Id}")]
        public ActionResult GetUserById(int Id)
        {
            try
            {
                var result = _userRepository.GetUserById(Id);
                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }        
    }
}