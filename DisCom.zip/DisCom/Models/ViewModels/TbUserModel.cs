﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DisCom.Models.ViewModels
{
    public class TbUserModel
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string UserEnccryptedPassword { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public int RoleId { get; set; }
        public int? DiscomId { get; set; }
        public int? CircleId { get; set; }
        public int? DivisionId { get; set; }
        public int? SubDivionId { get; set; }
        public int? SubStationId { get; set; }
        public string FeederCode { get; set; }
        public string DtrCode { get; set; }
        public int? ReportingManager { get; set; }
        public byte? IsActive { get; set; }
        public string StatusDisp { get; set; }
        public DateTime? LastLogonTimeStamp { get; set; }
        public string Otp { get; set; }
        public DateTime? OtpCreatedOn { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public string[] DtrCodeList { get; set; }
        public string[] FeederCodeList { get; set; }

        public string  Role { get; set; }
        public string ReportingManagerName { get; set; }

        public string loadDB { get; set; }
        public int? wareHouseId { get; set; }
        public int Logincnt { get; set; }
        public string DiscomName { get; set; }
        public string CircleName { get; set; }
        public string DivName { get; set; }
        public string SubDivName { get; set; }
        public string SubStnName { get; set; }
    }

    public class SendSmsModel
    {
        public int clientId { get; set; }
        public string mobile { get; set; }
        public string message { get; set; }
    }

    public class SetPasswordModel {
        [Required]
        public string Mobile { get; set; }
        public string Otp { get; set; }
        public string UserEnccryptedPassword { get; set; }
        public DateTime? OtpCreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
    }

    public class ResetPasswordModel
    {
        [Required]
        public string Otp { get; set; }
        public string UserEnccryptedPassword { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
