﻿using System;
using System.Collections.Generic;

namespace DisCom.Models
{
    public partial class TbUser
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string UserEnccryptedPassword { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public int RoleId { get; set; }
        public int? CircleId { get; set; }
        public int? DivisionId { get; set; }
        public int? SubDivionId { get; set; }
        public int? SubStationId { get; set; }
        public string FeederCode { get; set; }
        public string DtrCode { get; set; }
        public int? ReportingManager { get; set; }
        public byte? IsActive { get; set; }
        public DateTime? LastLogonTimeStamp { get; set; }
        public string Otp { get; set; }
        public DateTime? OtpCreatedOn { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? DiscomId { get; set; }
        public int Logincnt { get; set; }
    }
}
