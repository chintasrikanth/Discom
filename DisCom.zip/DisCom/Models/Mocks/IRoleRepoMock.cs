﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class IRoleRepoMock : IRoleRepository
    {
        private readonly ILogger<IRoleRepoMock> _logger;
        public IRoleRepoMock(ILogger<IRoleRepoMock> logger)
        {
            _logger = logger;
        }
        public ResponseModel GetRoles()
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    List<TbRoleModel> result = (from item in db.TbRole
                                                
                                                select new TbRoleModel
                                                {
                                                    Id = item.Id,
                                                    Role = item.Role,
                                                    ReportingRole = item.ReportingRole,
                                                    CrtBy = item.CrtBy,
                                                    CrtDt = item.CrtDt,
                                                    IsActive = item.IsActive,
                                                    StatusDisp = item.IsActive == 1 ? "Active" : "IN-Acitve",
                                                    ReportingRoleName = db.TbRole.FirstOrDefault(x=>x.Id == item.ReportingRole).Role

                                                }).ToList();

                    ResponseModel ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "Role List",
                        Result = result
                    };

                    return ResObj;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IRoleRepoMock-GetRoles-" + ex.Message);
                CommonRepoMock.writeLog("IRoleRepoMock-GetRoles", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel CreateRole(TbRoleModel role)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {

                    var RoleCheck = db.TbRole.Where(x => x.Role == role.Role).Count();                 

                    if (RoleCheck >= 1)
                    {
                        ResponseModel ResObj = new ResponseModel
                        {
                            Status = false,
                            Messege = "Role Already Exist !",
                            Result = role
                        };

                        return ResObj;
                    }
                    else
                    {
                        TbRole RoleObj = new TbRole
                        {
                            Role = role.Role,                          
                            CrtDt = DateTime.Now,
                            CrtBy = role.CrtBy,
                            UpdDt = DateTime.Now,
                            UpdBy = role.UpdBy,
                            IsActive = role.IsActive,
                        };

                        db.TbRole.Add(RoleObj);
                        db.SaveChanges();

                        ResponseModel ResObj = new ResponseModel
                        {
                            Status = true,
                            Messege = "Role Added",
                            Result = role
                        };

                        return ResObj;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IRoleRepoMock-CreateRole-" + ex.Message);
                CommonRepoMock.writeLog("IRoleRepoMock-CreateRole", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel UpdateRole(TbRoleModel role)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    ResponseModel ResObj = new ResponseModel();
                    var RoleObj = db.TbRole.FirstOrDefault(x => x.Id == role.Id);

                    var UsrCheck = db.TbUser.Where(x => x.RoleId == role.Id).Count();
                    if (role.IsActive == 0 && UsrCheck >= 1)
                    {

                        ResObj.Status = false;
                        ResObj.Messege = "This Role Cannot Be IN-Active, With This Role : " + UsrCheck + " Users Exist !";
                        ResObj.Result = RoleObj;
                    
                        return ResObj;
                    }
                    else
                    {
                        RoleObj.Role = role.Role;                      
                        RoleObj.IsActive = role.IsActive;
                        RoleObj.UpdDt = DateTime.Now;
                        RoleObj.UpdBy = role.UpdBy;

                        ResObj.Status = true;
                        ResObj.Messege = "Role Updated Successfully !";
                        ResObj.Result = RoleObj;

                        db.SaveChanges();
                        return ResObj;
                    }


                  

                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IRoleRepoMock-UpdateRole-" + ex.Message);
                CommonRepoMock.writeLog("IRoleRepoMock-UpdateRole", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel GetActiveRoles()
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    List<TbRoleModel> result = (from item in db.TbRole
                                                where item.IsActive == 1
                                                select new TbRoleModel
                                                {
                                                    Id = item.Id,
                                                    Role = item.Role,
                                                    ReportingRole = item.ReportingRole,
                                                    CrtBy = item.CrtBy,
                                                    CrtDt = item.CrtDt,
                                                    IsActive = item.IsActive,
                                                    ReportingRoleName = db.TbRole.FirstOrDefault(x => x.Id == item.ReportingRole).Role

                                                }).ToList();

                    ResponseModel ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "Role List",
                        Result = result
                    };

                    return ResObj;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IRoleRepoMock-GetActiveRoles-" + ex.Message);
                CommonRepoMock.writeLog("IRoleRepoMock-GetActiveRoles", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }
    }
}
