﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DisCom.Models
{
    public partial class DiscomkarvyContext : DbContext
    {
        public DiscomkarvyContext()
        {
        }

        public DiscomkarvyContext(DbContextOptions<DiscomkarvyContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TbConsumerUpdateHistory> TbConsumerUpdateHistory { get; set; }
        public virtual DbSet<TbConsumerVisit> TbConsumerVisit { get; set; }
        public virtual DbSet<TbConsumers> TbConsumers { get; set; }
        public virtual DbSet<TbLastlogin> TbLastlogin { get; set; }
        public virtual DbSet<TbRole> TbRole { get; set; }
        public virtual DbSet<TbUser> TbUser { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseMySQL("server=localhost;Database=Discomkarvy;user id=username;password=password;");
                optionsBuilder.UseMySQL("server=192.168.83.57;Database=Discomkarvy;user id=username;password=password;");
                //optionsBuilder.UseMySQL("server=192.168.84.4;Database=Discomkarvy;user id=root;password=Dapos@479#C;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<TbConsumerUpdateHistory>(entity =>
            {
                entity.ToTable("tb_consumer_update_history", "discomkarvy");

                entity.Property(e => e.Address)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.BoxSeal1)
                    .HasColumnName("Box_Seal1")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.BoxSeal2)
                    .HasColumnName("Box_Seal2")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerNumber)
                    .IsRequired()
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CrtBy).HasDefaultValueSql("0");

                entity.Property(e => e.LatestEleBillImage)
                    .HasColumnName("Latest_Ele_Bill_Image")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Latitude)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .HasColumnName("Mobile_Number")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterImage)
                    .HasColumnName("New_MeterImage")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNumber)
                    .HasColumnName("New_Meter_Number")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterNumber)
                    .HasColumnName("Old_Meter_Number")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterReading)
                    .HasColumnName("Old_Meter_Reading")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbConsumerVisit>(entity =>
            {
                entity.ToTable("tb_consumer_visit", "discomkarvy");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks)
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbConsumers>(entity =>
            {
                entity.ToTable("tb_consumers", "discomkarvy");

                entity.HasIndex(e => e.ConsumerNumber)
                    .HasName("ind_cno")
                    .IsUnique();

                entity.Property(e => e.Address)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.BoxSeal1)
                    .HasColumnName("Box_Seal1")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.BoxSeal2)
                    .HasColumnName("Box_Seal2")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerNumber)
                    .IsRequired()
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CrtBy).HasDefaultValueSql("0");

                entity.Property(e => e.LatestEleBillImage)
                    .HasColumnName("Latest_Ele_Bill_Image")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Latitude)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .HasColumnName("Mobile_Number")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterImage)
                    .HasColumnName("New_MeterImage")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNumber)
                    .HasColumnName("New_Meter_Number")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterNumber)
                    .HasColumnName("Old_Meter_Number")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterReading)
                    .HasColumnName("Old_Meter_Reading")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.QcVerify).HasDefaultValueSql("0");
            });

            modelBuilder.Entity<TbLastlogin>(entity =>
            {
                entity.ToTable("tb_lastlogin", "discomkarvy");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbRole>(entity =>
            {
                entity.ToTable("tb_role", "discomkarvy");

                entity.Property(e => e.Role)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbUser>(entity =>
            {
                entity.ToTable("tb_user", "discomkarvy");

                entity.Property(e => e.CircleId).HasColumnName("Circle_Id");

                entity.Property(e => e.CreatedOn).HasColumnName("Created_On");

                entity.Property(e => e.DivisionId).HasColumnName("Division_Id");

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .HasColumnName("Is_Active")
                    .HasColumnType("tinyint(1)");

                entity.Property(e => e.LastLogonTimeStamp).HasColumnName("LastLogon_TimeStamp");

                entity.Property(e => e.Logincnt).HasDefaultValueSql("0");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Otp)
                    .HasColumnName("OTP")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OtpCreatedOn).HasColumnName("OTP_CreatedOn");

                entity.Property(e => e.ReportingManager).HasColumnName("Reporting_Manager");

                entity.Property(e => e.RoleId).HasColumnName("Role_Id");

                entity.Property(e => e.SubStationId).HasColumnName("SubStation_id");

                entity.Property(e => e.UpdatedOn).HasColumnName("Updated_On");

                entity.Property(e => e.UserEnccryptedPassword)
                    .IsRequired()
                    .HasColumnName("User_Enccrypted_Password")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasColumnName("User_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });
        }
    }
}
