﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.ViewModels
{
    public class TbConsumerUpdateHistoryModel
    {
        public int Id { get; set; }
        public int? ConsumerId { get; set; }
        public string OldMeterNumber { get; set; }
        public string OldMeterManufacturer { get; set; }
        public string OldMeterReading { get; set; }
        public string ConsumerBillingType { get; set; }
        public string Phase { get; set; }
        public string OldMeterCurrentKwh { get; set; }
        public string OldMeterCurrentKvah { get; set; }
        public string OldMeterCurrentKva { get; set; }
        public string FeederCode { get; set; }
        public string DtrCode { get; set; }
        public DateTime? CreatedAt { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedBy { get; set; }
    }
}
