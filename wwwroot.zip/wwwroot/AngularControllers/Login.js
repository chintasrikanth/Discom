﻿
myApp.controller('AdminLoginCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.LoginModel = { Mobile: "", UserEnccryptedPassword: "" };


    $scope.LoginForm = function () {



        $scope.loginForm.$submitted = true;

        if ($scope.loginForm.$valid) {

            $http.post(serviceBasePath + "auth/login", $scope.LoginModel).then(function success(response) {

                if (response.data.Status === true && response.data.Result.RoleId != 2) {
                    userService.SetCurrentUser(response.data.Result.Token);
                    $sessionStorage.UserName = response.data.Result.UserName;
                    $sessionStorage.UsrId = response.data.Result.UsrId;
                    $sessionStorage.RoleId = response.data.Result.RoleId;
                    $sessionStorage.Role = response.data.Result.Role;

                    //if (response.data.Result.RoleId == 1) {
                    //    $window.location.href = ridirectPath + '/Consumer/Index';
                    //}
                    $window.location.href = ridirectPath + '/Consumer/Index';
                }                

                if (response.data.Status == true && response.data.Result.RoleId == 2) {

                    swal({
                        title: "", text: " Field Enineer Cannot Login To Web Application!", type: "error"
                    },
                        function () {
                            return false;
                        }
                    );
                }

                if (response.data.Status == false) {

                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );
                }

            }, function error() {

            });
        }
    };

    $scope.logOut = function () {
        $sessionStorage.user = null;
        $window.location.href = ridirectPath;
    };

    $scope.ResetForm = function () {
        $scope.forgotPwdSendOtpForm.$setPristine();
        $scope.forgotPwdSendOtpForm.$setUntouched();
        $scope.FPModel = { Mobile: "" };
    };

    $scope.InitFPass = function () {
        $scope.ResetForm();
        $("#AddForgotPwd").modal("show");
    };



    $scope.ForgotPwdSendOtp = function () {
        $scope.forgotPwdSendOtpForm.$submitted = true;
        if ($scope.forgotPwdSendOtpForm.$valid) {
            $http.post(serviceBasePath + 'auth/SendOtpForSetPwd', $scope.FPModel).then(function success(response) {

                if (response.data.Status == true) {
                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {
                            $window.location.href = ridirectPath + '/MyAccount/ForgotPassword';
                        }
                    );
                }

                if (response.data.Status == false) {
                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );
                }


            }, function error() {
            });
        }
    };

    $scope.FPCModel = { Otp: "", UserEnccryptedPassword: "" };

    $scope.ForgotPwdSend = function () {
        $scope.forgotPwdForm.$submitted = true;
        if ($scope.forgotPwdForm.$valid) {
            $http.post(serviceBasePath + 'auth/ResetPwd', $scope.FPCModel).then(function success(response) {


                if (response.data.Status == true) {
                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {

                            $window.location.href = ridirectPath;
                        }
                    );
                }

                if (response.data.Status == false) {
                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );
                }


            }, function error() {
            });
        }
    };



}]);
