﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.ViewModels
{
    public class ResponseModel
    {
        public bool Status { get; set; }
        public Object Result { get; set; }
        public string Messege { get; set; }
    }
}
