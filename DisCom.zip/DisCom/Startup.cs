﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.Mocks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;
using DisCom.AppConfig;
using HealthChecks.UI.Client;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;

namespace DisCom
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

       //  This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //For storring log files in azure
            services.AddApplicationInsightsTelemetry(options =>
            {
                Configuration.Bind("ApplicationInsights", options);
            });
            //
            services.AddHealthChecks().AddUrlGroup(new Uri("https://testkarvy.smart-energymeters.co.in/"),
                                    name: "Base URL",
                                    failureStatus: HealthStatus.Degraded)
                    .AddApplicationInsightsPublisher("dcacbdfd-8028-4245-ad89-5b42769be571");

            services.AddHealthChecksUI(setupSettings: setup =>
            {
                setup.AddHealthCheckEndpoint("Basic healthcheck", "https://testkarvyapi.smart-energymeters.co.in/healthcheck");
            });
            //

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).
            AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
                

            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
              {
                  options.TokenValidationParameters = new TokenValidationParameters
                  {
                      ValidateIssuer = true,
                      ValidateAudience = true,
                      ValidateLifetime = true,
                      ValidateIssuerSigningKey = true,
                      ValidIssuer = "http://localhost:60487",
                      ValidAudience = "http://localhost:60487",
                      IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret@1234"))
                  };
              });

            services.AddSingleton<IUserRepository, UserRepoMock>();
            services.AddSingleton<IConsumerRepository, ConsumerRepMock>();
            services.AddSingleton<ICommonRepository, CommonRepoMock>();
            services.AddSingleton<IRoleRepository, IRoleRepoMock>();
            services.AddSingleton<IMyAccountRepository, MyAccountRepoMock>();
            services.AddSingleton<IQcAroRepository, IQcAroRepoMock>();
        }

        //This method gets called by the runtime. Use this method to configure the http request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHealthChecks("/healthcheck", new HealthCheckOptions
            {
                Predicate = _ => true,
                ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
            });
            //.UseHealthChecksUI(setup =>
            //{
            //    setup.AddCustomStylesheet(@"wwwroot\css\dotnet.css");
            //});

            app.UseHealthChecksUI();
            app.UsePathBase($"/{env.EnvironmentName}");           

            //app.UseStaticFiles(new StaticFileOptions()
            //{
            //    FileProvider = new PhysicalFileProvider(
            //   Path.Combine(Directory.GetCurrentDirectory(), @"Resources/Images")),
            //    RequestPath = new PathString("/Resources/Images")
            //});

            app.UseCors(options => options.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            app.UseAuthentication();
            app.UseMvcWithDefaultRoute();

            AppConfiguration.SetConfig(Configuration);
        }
    }
}
