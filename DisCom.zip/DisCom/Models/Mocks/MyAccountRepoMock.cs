﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models.ViewModels;
using DisCom.Models;
using DisCom.Models.Contracts;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class MyAccountRepoMock : IMyAccountRepository
    {
        private readonly CustomPasswordHasher CstmPwdHshrObj;
        private readonly ILogger<MyAccountRepoMock> _logger;

        public MyAccountRepoMock(ILogger<MyAccountRepoMock> logger)
        {
            this.CstmPwdHshrObj = new CustomPasswordHasher();
            _logger = logger;
        }

        public ResponseModel ResetPwd(TbUserModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    TbUser UsrObj = db.TbUser.FirstOrDefault(x => x.Id == user.Id);
                    UsrObj.UserEnccryptedPassword = CstmPwdHshrObj.GetMd5Hash(user.UserEnccryptedPassword);
                    db.SaveChanges();

                    ResponseModel ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "Password Changed Successfully !",

                    };

                    return ResObj;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "MyAccountRepoMock-ResetPwd-" + ex.Message);
                CommonRepoMock.writeLog("MyAccountRepoMock-ResetPwd", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !"
                };

                return ResObj;
            }
        }
    }
}
