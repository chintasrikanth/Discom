﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class UserRepoMock : IUserRepository
    {
        private ICommonRepository _commonRepository;
        private readonly CustomPasswordHasher CstmPwdHshrObj;
        private readonly ILogger<UserRepoMock> _logger;
        
        public UserRepoMock(ICommonRepository commonRepository, ILogger<UserRepoMock> logger)
        {
            _commonRepository = commonRepository;
            _logger = logger;
            this.CstmPwdHshrObj = new CustomPasswordHasher();
        }

        public TbUserModel GetUser(TbUserModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var HashedPassword = CstmPwdHshrObj.HashPassword(user.UserEnccryptedPassword);

                    TbUserModel result = (from item in db.TbUser
                                          where item.Mobile == user.Mobile && item.UserEnccryptedPassword == HashedPassword && item.Logincnt < 4
                                          select new TbUserModel
                                          {
                                              Id = item.Id,
                                              UserName = item.UserName,
                                              UserEnccryptedPassword = item.UserEnccryptedPassword,
                                              Email = item.Email,
                                              Mobile = item.Mobile,
                                              RoleId = item.RoleId,
                                              CircleId = item.CircleId,
                                              DivisionId = item.DivisionId,
                                              SubDivionId = item.SubDivionId,
                                              SubStationId = item.SubStationId,
                                              FeederCode = item.FeederCode,
                                              DtrCode = item.DtrCode,
                                              ReportingManager = item.ReportingManager,
                                              IsActive = item.IsActive,
                                              LastLogonTimeStamp = item.LastLogonTimeStamp,
                                              Otp = item.Otp,
                                              OtpCreatedOn = item.OtpCreatedOn,
                                              CreatedOn = item.CreatedOn,
                                              UpdatedOn = item.UpdatedOn,
                                              Role = db.TbRole.FirstOrDefault(x => x.Id == item.RoleId).Role,
                                              //wareHouseId = db.TbWarehouse.FirstOrDefault(x => x.WhManeger == item.Id).Id,

                                          }).FirstOrDefault();
                    int cnt = db.TbUser.Where(x => x.Mobile == user.Mobile && x.UserEnccryptedPassword == HashedPassword && x.Logincnt < 4).Count();
                    if (cnt == 1)
                    {
                        var usrobj = db.TbUser.Where(x => x.Mobile == user.Mobile && x.UserEnccryptedPassword == HashedPassword).Select(x => x).FirstOrDefault();
                        usrobj.Logincnt = 1;
                        usrobj.LastLogonTimeStamp = DateTime.Now;
                        db.SaveChanges();

                        TbLastlogin objLL = new TbLastlogin();
                        objLL.UserId = usrobj.Id;
                        objLL.UserName = usrobj.UserName;
                        objLL.Mobile = usrobj.Mobile;
                        objLL.LastLogin = DateTime.Now;
                        db.TbLastlogin.Add(objLL);
                        db.SaveChanges();
                        //result.Logincnt = usrobj.Logincnt;
                    }
                    else
                    {
                        int cntuser = db.TbUser.Where(x => x.Mobile == user.Mobile).Count();
                        if (cntuser == 1)
                        {
                            var usrobj = db.TbUser.Where(x => x.Mobile == user.Mobile).Select(x => x).FirstOrDefault();
                            usrobj.Logincnt = usrobj.Logincnt + 1;
                            db.SaveChanges();
                            if (usrobj.Logincnt > 3)
                            {
                                usrobj.IsActive = 0;
                                db.SaveChanges();
                            }
                            result = (from item in db.TbUser
                                      where item.Mobile == user.Mobile
                                      select new TbUserModel
                                      {

                                          Logincnt = item.Logincnt,
                                      }).FirstOrDefault();
                        }
                    }
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-GetUser" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-GetUser", "", ex.Message);
                return null;
            }
        }

        public ResponseModel GetUsers(int Id, int RoleId)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    if (RoleId != 1)
                    {
                        List<TbUserModel> result = (from item in db.TbUser
                                                    where item.ReportingManager == Id
                                                    select new TbUserModel
                                                    {
                                                        Id = item.Id,
                                                        UserName = item.UserName,
                                                        UserEnccryptedPassword = item.UserEnccryptedPassword,
                                                        Email = item.Email,
                                                        Mobile = item.Mobile,
                                                        RoleId = item.RoleId,
                                                        CircleId = item.CircleId,
                                                        DivisionId = item.DivisionId,
                                                        SubStationId = item.SubStationId,
                                                        FeederCode = item.FeederCode,
                                                        DtrCode = item.DtrCode,
                                                        ReportingManager = item.ReportingManager,
                                                        StatusDisp = item.IsActive == 1 ? "Active" : "IN-Active",
                                                        LastLogonTimeStamp = item.LastLogonTimeStamp,
                                                        Otp = item.Otp,
                                                        OtpCreatedOn = item.OtpCreatedOn,
                                                        CreatedOn = item.CreatedOn,
                                                        UpdatedOn = item.UpdatedOn,
                                                        Role = db.TbRole.FirstOrDefault(x => x.Id == item.RoleId).Role,
                                                        ReportingManagerName = db.TbUser.FirstOrDefault(x => x.Id == item.ReportingManager).UserName


                                                    }).OrderByDescending(x => x.CreatedOn).ToList();

                        ResponseModel res = new ResponseModel
                        {
                            Status = true,
                            Messege = "Users List",
                            Result = result
                        };

                        return res;

                    }
                    else
                    {
                        List<TbUserModel> result = (from item in db.TbUser
                                                    select new TbUserModel
                                                    {
                                                        Id = item.Id,
                                                        UserName = item.UserName,
                                                        UserEnccryptedPassword = item.UserEnccryptedPassword,
                                                        Email = item.Email,
                                                        Mobile = item.Mobile,
                                                        RoleId = item.RoleId,
                                                        CircleId = item.CircleId,
                                                        DivisionId = item.DivisionId,
                                                        SubStationId = item.SubStationId,
                                                        FeederCode = item.FeederCode,
                                                        DtrCode = item.DtrCode,
                                                        ReportingManager = item.ReportingManager,
                                                        StatusDisp = item.IsActive == 1 ? "Active" : "IN-Active",
                                                        IsActive = item.IsActive,
                                                        LastLogonTimeStamp = item.LastLogonTimeStamp,
                                                        Otp = item.Otp,
                                                        OtpCreatedOn = item.OtpCreatedOn,
                                                        CreatedOn = item.CreatedOn,
                                                        UpdatedOn = item.UpdatedOn,
                                                        Role = db.TbRole.FirstOrDefault(x => x.Id == item.RoleId).Role,
                                                        ReportingManagerName = db.TbUser.FirstOrDefault(x => x.Id == item.ReportingManager).UserName
                                                    }).OrderByDescending(x => x.CreatedOn).ToList();

                        ResponseModel res = new ResponseModel
                        {
                            Status = true,
                            Messege = "Users List",
                            Result = result
                        };

                        return res;
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-GetUsers" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-GetUsers", "", ex.Message);
                ResponseModel res = new ResponseModel
                {
                    Status = true,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };
                return res;
            }
        }

        public ResponseModel SendOtpForSetPwd(SetPasswordModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var UsrObj = db.TbUser.FirstOrDefault(x => x.Mobile == user.Mobile);
                    ResponseModel ResObj = new ResponseModel();

                    if (UsrObj == null)
                    {
                        ResObj.Status = false;
                        ResObj.Messege = "User Does Not Exists!";
                        return ResObj;
                    }


                    else
                    {
                        string otp = _commonRepository.Otp();

                        UsrObj.Otp = otp;
                        UsrObj.OtpCreatedOn = DateTime.Now;
                        db.SaveChanges();


                        SendSmsModel Obj = new SendSmsModel
                        {
                            mobile = UsrObj.Mobile,
                            message = otp + " is OTP for Set Password"
                        };

                        var result = _commonRepository.SendSms(Obj);

                        ResObj.Status = true;
                        ResObj.Messege = "Otp Sent Succesfully!";
                        return ResObj;

                    }


                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-SendOtpForSetPwd-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-SendOtpForSetPwd", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong!",
                    Result = ex

                };
                return ResObj;
            }
        }

        public ResponseModel ResetPwd(ResetPasswordModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var UsrObj = db.TbUser.FirstOrDefault(x => x.Otp == user.Otp);

                    if (UsrObj != null)
                    {
                        UsrObj.UserEnccryptedPassword = CstmPwdHshrObj.GetMd5Hash(user.UserEnccryptedPassword);
                        UsrObj.UpdatedOn = DateTime.Now;
                        db.SaveChanges();

                        ResponseModel ResObj = new ResponseModel
                        {
                            Status = true,
                            Messege = "Password Changed Successfully !"
                        };

                        return ResObj;

                    }
                    else
                    {

                        ResponseModel ResObj = new ResponseModel
                        {
                            Status = false,
                            Messege = "Have Entered A Wrong Otp !"
                        };

                        return ResObj;
                    }


                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-ResetPwd-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-ResetPwd", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex

                };

                return ResObj;
            }
        }

        public ResponseModel CreateUser(TbUserModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var EmailCheck = db.TbUser.Where(x => x.Email == user.Email).Count();
                    var MobileCheck = db.TbUser.Where(x => x.Mobile == user.Mobile).Count();
                    ResponseModel ResObj = new ResponseModel();


                    if (EmailCheck == 1)
                    {

                        ResObj.Status = false;
                        ResObj.Messege = "Email Address Already Registered !";
                        return ResObj;
                    }
                    else if (MobileCheck == 1)
                    {
                        ResObj.Status = false;
                        ResObj.Messege = "Mobile Already Registered !";
                        return ResObj;
                    }
                    else
                    {

                        string dtr = null;
                        string FeederCode = null;

                        if (user.FeederCodeList != null)
                        {
                            FeederCode = string.Join(",", user.FeederCodeList);
                        }

                        if (user.DtrCodeList != null)
                        {
                            dtr = string.Join(",", user.DtrCodeList);
                        }                       

                        TbUser Obj = new TbUser
                        {
                            UserName = user.UserName,
                            Email = user.Email,
                            Mobile = user.Mobile,
                            RoleId = user.RoleId,
                            DiscomId = user.DiscomId,
                            CircleId = user.CircleId,
                            DivisionId = user.DivisionId,
                            SubDivionId = user.SubDivionId,
                            SubStationId = user.SubStationId,
                            FeederCode = FeederCode,
                            DtrCode = dtr,
                            ReportingManager = user.ReportingManager,
                            UserEnccryptedPassword = CstmPwdHshrObj.GetMd5Hash("Rock@579"),
                            IsActive = user.IsActive,
                            CreatedOn = DateTime.Now,
                            UpdatedOn = DateTime.Now
                        };

                        db.TbUser.Add(Obj);
                        db.SaveChanges();

                        ResObj.Status = true;
                        ResObj.Messege = "User Added Successfully !";
                        ResObj.Result = Obj;
                        return ResObj;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-CreateUser-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-CreateUser", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = true,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel UpdateUser(TbUserModel user)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {

                    var MobileCheck = db.TbUser.Where(x => x.Mobile == user.Mobile && x.Id != user.Id).Count();
                    ResponseModel ResObj = new ResponseModel();

                    if (MobileCheck == 1)
                    {
                        ResObj.Status = false;
                        ResObj.Messege = "Mobile Number Already Registered !";
                    }
                    else
                    {
                        string dtr = null;
                        string FeederCode = null;

                        if (user.FeederCodeList != null)
                        {
                            FeederCode = string.Join(",", user.FeederCodeList);
                        }

                        if (user.DtrCodeList != null)
                        {
                            dtr = string.Join(",", user.DtrCodeList);
                        }

                        TbUser Obj = db.TbUser.FirstOrDefault(x => x.Id == user.Id);
                        if (Obj.Logincnt > 3)
                        {
                            Obj.UserEnccryptedPassword = CstmPwdHshrObj.GetMd5Hash("Rock@579");
                        }
                        Obj.UserName = user.UserName;
                        Obj.Mobile = user.Mobile;
                        Obj.RoleId = user.RoleId;
                        Obj.DiscomId = user.DiscomId;
                        Obj.CircleId = user.CircleId;
                        Obj.DivisionId = user.DivisionId;
                        Obj.SubDivionId = user.SubDivionId;
                        Obj.SubStationId = user.SubStationId;
                        Obj.FeederCode = FeederCode;
                        Obj.DtrCode = dtr;
                        Obj.ReportingManager = user.ReportingManager;
                        Obj.IsActive = user.IsActive;
                        Obj.UpdatedOn = DateTime.Now;
                        Obj.Logincnt = 0;

                        if (user.RoleId == 1 || user.RoleId == 5 || user.RoleId == 6)
                        {
                            Obj.CircleId = null;
                            Obj.DivisionId = null;
                            Obj.SubDivionId = null;
                            Obj.SubStationId = null;
                            Obj.FeederCode = null;
                            Obj.DtrCode = null;
                            Obj.ReportingManager = null;
                        }

                        if (user.RoleId == 2)
                        {
                            Obj.DivisionId = null;
                            Obj.SubDivionId = null;
                            Obj.SubStationId = null;
                            Obj.FeederCode = null;
                            Obj.DtrCode = null;
                            Obj.ReportingManager = null;
                        }


                        if (user.RoleId == 3)
                        {

                            Obj.SubDivionId = null;
                            Obj.SubStationId = null;
                            Obj.FeederCode = null;
                            Obj.DtrCode = null;
                            Obj.ReportingManager = null;
                        }


                        if (user.RoleId == 4)
                        {

                            Obj.SubStationId = null;
                            Obj.FeederCode = null;
                            Obj.DtrCode = null;
                            Obj.ReportingManager = null;
                        }



                        if (user.RoleId == 7)
                        {
                            List<TbUser> MyFes = (db.TbUser.Where(x => x.ReportingManager == user.Id).Select(x => new TbUser
                            {
                                Id = x.Id,
                                CircleId = x.CircleId,
                                DivisionId = x.DivisionId,
                                SubDivionId = x.SubDivionId,
                                SubStationId = x.SubStationId
                            })).ToList();

                            foreach (TbUser item in MyFes)
                            {
                                TbUser MyFe = db.TbUser.FirstOrDefault(x => x.Id == item.Id);
                                MyFe.CircleId = user.CircleId;
                                MyFe.DivisionId = user.DivisionId;
                                MyFe.SubDivionId = user.SubDivionId;
                                MyFe.SubStationId = user.SubStationId;
                                db.SaveChanges();
                            }



                            Obj.ReportingManager = null;
                        }


                        if (user.RoleId == 8)
                        {

                            Obj.DtrCode = null;
                        }

                        db.SaveChanges();



                        ResObj.Status = true;
                        ResObj.Messege = "User Updated Successfully !";
                        ResObj.Result = Obj;

                    }


                    return ResObj;


                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-UpdateUser-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-UpdateUser", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Something Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel GetReportingManegers(int RoleId, int SubStationId)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var ReportingRole = db.TbRole.FirstOrDefault(x => x.Id == RoleId).ReportingRole;

                    var result = (from item in db.TbUser
                                  where item.RoleId == ReportingRole && item.IsActive == 1 && item.SubStationId == SubStationId

                                  select new TbUserModel
                                  {
                                      Id = item.Id,
                                      UserName = item.UserName


                                  }).ToList();

                    ResponseModel ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "Reporting Managers",
                        Result = result
                    };

                    return ResObj;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-GetReportingManegers-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-GetReportingManegers", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = false,
                    Messege = "Somthing Went Wrong !",
                    Result = ex
                };

                return ResObj;
            }
        }

        public ResponseModel GetUserById(int Id)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    var result = (from item in db.TbUser
                                  where item.Id == Id
                                  select new TbUserModel
                                  {
                                      Id = item.Id,
                                      UserName = item.UserName,
                                      UserEnccryptedPassword = item.UserEnccryptedPassword,
                                      Email = item.Email,
                                      Mobile = item.Mobile,
                                      RoleId = item.RoleId,
                                      DiscomId=item.DiscomId,
                                      CircleId = item.CircleId,
                                      DivisionId = item.DivisionId,
                                      SubDivionId = item.SubDivionId,
                                      SubStationId = item.SubStationId,
                                      FeederCode = item.FeederCode,
                                      DtrCode = item.DtrCode,
                                      ReportingManager = item.ReportingManager,
                                      IsActive = item.IsActive,
                                      LastLogonTimeStamp = item.LastLogonTimeStamp,
                                      Otp = item.Otp,
                                      OtpCreatedOn = item.OtpCreatedOn,
                                      CreatedOn = item.CreatedOn,
                                      UpdatedOn = item.UpdatedOn,
                                      Role = db.TbRole.FirstOrDefault(x => x.Id == item.RoleId).Role,
                                      

                                  }).FirstOrDefault();

                    ResponseModel ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "User Details",
                        Result = result
                    };

                    return ResObj;

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserRepoMock-GetUserById-" + ex.Message);
                CommonRepoMock.writeLog("UserRepoMock-GetUserById", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = true,
                    Messege = "User Details",
                    Result = ex
                };

                return ResObj;
            }
        }
    }
}
