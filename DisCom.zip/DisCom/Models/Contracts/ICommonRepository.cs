﻿using System;
using Microsoft.AspNetCore.Http;
using DisCom.Models.ViewModels;

namespace DisCom.Models.Contracts
{
    public interface ICommonRepository
    {
        string ImageUpload(IFormFile file,string path);
        string SendSms(SendSmsModel Obj);
        string Otp();

        string ImageUploadStringToSteam(string filebytes, string filename, string path);

    }
}
