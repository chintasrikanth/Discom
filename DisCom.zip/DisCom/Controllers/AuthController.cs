﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DisCom.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using Microsoft.Extensions.Logging;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {

        private readonly CustomPasswordHasher CstmPwdHshrObj;
        private IUserRepository _userRepository;
        private ICommonRepository _commonRepository;
        private readonly ILogger<AuthController> _logger;

        public AuthController(IUserRepository userRepository, ICommonRepository commonRepository, ILogger<AuthController> logger)
        {
            _userRepository = userRepository;
            _commonRepository = commonRepository;
            _logger = logger;
            this.CstmPwdHshrObj = new CustomPasswordHasher();
        }

        [HttpPost, Route("login")]
        public ActionResult Login(TbUserModel user)
        {
            try
            {
                ResponseModel ResObj = new ResponseModel();
                TbUserModel MyUser = _userRepository.GetUser(user);

                if (MyUser == null)
                {
                    ResObj.Status = false;
                    ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                    ResObj.Messege = "Invalid Credentials!";
                    return Ok(ResObj);
                }

                if (user.UserEnccryptedPassword == "" || user.Mobile == "" )
                {
                    ResObj.Status = false;
                    ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                    ResObj.Messege = "Mobile And Password Fields Cannot Be Left Blank";
                    return Ok(ResObj);
                }
                else if (MyUser.Id == 0 && MyUser.Logincnt < 4)
                {
                    ResObj.Status = false;
                    ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                    ResObj.Messege = "Invalid Credentials!";
                    return Ok(ResObj);
                }
                else if (MyUser.Logincnt > 3)
                {
                    ResObj.Status = false;
                    ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                    _logger.LogCritical("User Blocked Due to Multiple Password Failure for " + user.Mobile);
                    ResObj.Messege = "User Blocked!";
                    return Ok(ResObj);
                }
                else if (MyUser != null && MyUser.IsActive != 1)
                {
                    ResObj.Status = false;
                    ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                    ResObj.Messege = "Your Account is IN-Active, Please Contact to Admin !";

                    return Ok(ResObj);
                }

                else if (MyUser != null && MyUser.IsActive == 1)
                {
                    if (MyUser.RoleId == 13 && MyUser.wareHouseId==null)
                    {
                        ResObj.Status = false;
                        ResObj.Result = new { Token = "", UsrId = "", UserName = "", Email = "", Role = "" };
                        ResObj.Messege = "Cannot be logged as your account is not mapped to any Warehouse!";

                        return Ok(ResObj);
                    }

                    var claims = new[] {
                     new Claim(ClaimTypes.NameIdentifier, MyUser.Id.ToString()),
                     new Claim(ClaimTypes.Role, MyUser.RoleId.ToString())
                    };


                    var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret@1234"));
                    var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                    var tokeOptions = new JwtSecurityToken(
                    issuer: "http://localhost:60487",
                    audience: "http://localhost:60487",
                    claims: claims,
                    expires: DateTime.Now.AddDays(1),
                    signingCredentials: signinCredentials
                    );

                    var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                    var LoginObject = new { Token = tokenString, UsrId = MyUser.Id, UserName = MyUser.UserName, Email = MyUser.Email, RoleId = MyUser.RoleId, Role = MyUser.Role };
                    
                    ResObj.Status = true;
                    ResObj.Result = LoginObject;
                    ResObj.Messege = "Successfully Logged In!";
                    return Ok(ResObj);
                }
                else
                {
                    return BadRequest("Something Went Wrong !");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Login-" + ex.Message);
                return null;
            }
        }


        [HttpPost, Route("SendOtpForSetPwd")]
        public ActionResult SendOtpForSetPwd(SetPasswordModel user)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var result = _userRepository.SendOtpForSetPwd(user);
                    if (result.Status == true)
                    {
                        return Ok(result);
                    }
                    else if (result.Status == false && result.Messege != "Something Went Wrong!")
                    {
                        return Ok(result);
                    }
                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Set Password !" };
                    return BadRequest(ResObj);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SendOtpForSetPwd-" + ex.Message);
                return null;
            }

        }

        [HttpPost, Route("ResetPwd")]
        public ActionResult ResetPwd(ResetPasswordModel user)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var result = _userRepository.ResetPwd(user);
                    if (result.Status == true)
                    {
                        return Ok(result);
                    }

                    if (result.Status == false && result.Messege == "Have Entered A Wrong Otp !")
                    {
                        return Ok(result);
                    }

                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Reset Password !" };
                    return BadRequest(ResObj);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ResetPwd-" + ex.Message);
                return null;
            }
        }

    }
}