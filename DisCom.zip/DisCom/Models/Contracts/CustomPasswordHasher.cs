﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace DisCom.Models.Contracts
{
    public class CustomPasswordHasher
    {



        public string GetMd5Hash(string input)
        {
            try
            {
                using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
                {
                    byte[] b = System.Text.Encoding.UTF8.GetBytes(input);
                    b = md5.ComputeHash(b);
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    foreach (byte x in b)
                        sb.Append(x.ToString("x2"));
                    return sb.ToString();

                }
            }
            catch (Exception ex)
            {
                return null;
            }


        }

        public string HashPassword(string password)
        {
            try
            {
                return this.GetMd5Hash(password);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public PasswordVerificationResult VerifyHashedPassword(string HashedPassword, string ProvidedPassword)
        {
            try
            {
                var ProvidedPasswordHash = this.HashPassword(ProvidedPassword);

                if (HashedPassword == ProvidedPasswordHash)

                    return PasswordVerificationResult.Success;
                else
                    return PasswordVerificationResult.Failed;
            }
            catch (Exception ex)
            {
                return PasswordVerificationResult.Failed;
            }
        }
    }
}
