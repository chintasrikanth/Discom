﻿
// This code returns the token

myApp.factory('userService', ['$sessionStorage', function ($sessionStorage) {
    var fac = {};
    fac.CurrentUser = null;
    fac.SetCurrentUser = function (user) {
        fac.CurrentUser = user;
        $sessionStorage.user = user;
    };
    fac.GetCurrentUser = function () {
        if ($sessionStorage === null || $sessionStorage.user === null || $sessionStorage.user === 'undefined') {
            return null;
        }
        else {
            fac.CurrentUser = $sessionStorage.user;
            return fac.CurrentUser;
        }
    };
    return fac;
}]);



myApp.config(['$httpProvider', function ($httpProvider) {
  
    var interceptor = function (userService, $q, $location, $window) {
        return {
            request: function (config) {
                var currentUser = userService.GetCurrentUser();
                if (currentUser != null) {
                    config.headers['Authorization'] = 'Bearer ' + currentUser;
                }
                return config;
            },
            responseError: function (rejection) {
                if (rejection.status === 401) {

                    userService.SetCurrentUser(null);

                    $window.location.href = '/account/login';

                    return $q.reject(rejection);
                }
                if (rejection.status === 403) {
                    userService.SetCurrentUser(null);
                   $window.location.href = '/account/login';
                    return $q.reject(rejection);
                }
                return $q.reject(rejection);
            }

        };
    };

    var params = ['userService', '$q', '$location', '$window'];
    interceptor.$inject = params;
    $httpProvider.interceptors.push(interceptor);
}]);


myApp.directive('passwordVerify', ['$parse', function ($parse) {
    return {
        restrict: 'A', // only activate on element attribute
        require: '?ngModel', // get a hold of NgModelController
        link: function (scope, elem, attrs, ngModel) {
            if (!ngModel)
                return; // do nothing if no ng-model

            // watch own value and re-validate on change
            scope.$watch(attrs.ngModel, function () {
                validate();
            });

            // observe the other value and re-validate on change
            attrs.$observe('passwordVerify', function (val) {
                validate();
            });

            var validate = function () {
                // values
                var val1 = ngModel.$viewValue;
                var val2 = attrs.passwordVerify;

                // set validity
                ngModel.$setValidity('passwordVerify', val1 === val2);
            };
        }
    };
}]);


myApp.directive('ngEnter', function () { //a directive to 'enter key press' in elements with the "ng-enter" attribute

    return function (scope, element, attrs) {

        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
});

myApp.factory('Excel', function ($window) {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
        base64 = function (s) { return $window.btoa(unescape(encodeURIComponent(s))); },
        format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
    return {
        tableToExcel: function (tableId, worksheetName) {
            var table = $(tableId),
                ctx = { worksheet: worksheetName, table: table.html() },
                href = uri + base64(format(template, ctx));
            return href;
        }
    };
})

myApp.directive('lightgallery', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                if (scope.$last) {

                    // ng-repeat is completed
                    element.parent().lightGallery();
                }
            }
        };
    });









