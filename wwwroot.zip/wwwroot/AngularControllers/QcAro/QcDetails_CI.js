﻿
myApp.controller('QcDetailsCICtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {


    $scope.QCEModel = { Id: "", ConsumerNumber: "", ConsumerBillingType: "", NewMeter_Number: "", MobileNumber: "", Address: "", OldMeter_Number: "", OldMeter_Reading: "", BoxSeal1: "", BoxSeal2: "", Latitude: "", Longitude: "", InstalledDate: "", fileUploadList: "", fileUploadListOld: "" };

    $scope.init = function (ConsumerId) {
        
        $scope.CnsmrOldNewMtrDetailsByCnsmr = function (ConsumerId) {
            $http.get(serviceBasePath + "Consumer/CnsmrOldNewMtrDetailsByCnsmr/" + ConsumerId).then(function success(response) {
                $scope.CnsmrOldNewMtrDetails = response.data.Result;
                
                /* Oldmeter Image Section*/
                $(".NewMeterImage li").attr('data-src', $scope.CnsmrOldNewMtrDetails.ConsumerObj.NewMeterImage);
                $(".Latest_Ele_BillImage li").attr('data-src', $scope.CnsmrOldNewMtrDetails.ConsumerObj.Latest_Ele_BillImage);

                $scope.QCEModel.Id = $scope.CnsmrOldNewMtrDetails.ConsumerObj.Id;
                $scope.QCEModel.ConsumerNumber = $scope.CnsmrOldNewMtrDetails.ConsumerObj.ConsumerNumber;
                $scope.QCEModel.NewMeter_Number = $scope.CnsmrOldNewMtrDetails.ConsumerObj.NewMeter_Number;

                $scope.QCEModel.MobileNumber = $scope.CnsmrOldNewMtrDetails.ConsumerObj.MobileNumber;
                $scope.QCEModel.Address = $scope.CnsmrOldNewMtrDetails.ConsumerObj.Address;

                $scope.QCEModel.OldMeter_Number = $scope.CnsmrOldNewMtrDetails.ConsumerObj.OldMeter_Number;
                $scope.QCEModel.OldMeter_Reading = $scope.CnsmrOldNewMtrDetails.ConsumerObj.OldMeter_Reading;
                $scope.QCEModel.BoxSeal1 = $scope.CnsmrOldNewMtrDetails.ConsumerObj.BoxSeal1;
                $scope.QCEModel.BoxSeal2 = $scope.CnsmrOldNewMtrDetails.ConsumerObj.BoxSeal2;
                $scope.QCEModel.Latitude = $scope.CnsmrOldNewMtrDetails.ConsumerObj.Latitude;
                $scope.QCEModel.Longitude = $scope.CnsmrOldNewMtrDetails.ConsumerObj.Longitude;
                
                if ($scope.CnsmrOldNewMtrDetails.ConsumerObj.InstalledDate != null) {
                    $scope.QCEModel.InstalledDate = ((new Date($scope.CnsmrOldNewMtrDetails.ConsumerObj.InstalledDate).getMonth() + 1) + '/' + ((new Date($scope.CnsmrOldNewMtrDetails.ConsumerObj.InstalledDate)).getDate()) + '/' + (new Date($scope.CnsmrOldNewMtrDetails.ConsumerObj.InstalledDate)).getFullYear());
                    //alert(((new Date($scope.CnsmrOldNewMtrDetails.NewMeterObj.InstallationDate).getDate()) + '/' + ((new Date($scope.CnsmrOldNewMtrDetails.NewMeterObj.InstallationDate)).getMonth() + 1) + '/' + (new Date($scope.CnsmrOldNewMtrDetails.NewMeterObj.InstallationDate)).getFullYear()));
                }
                
            }, function error() {


            });
        };

        $scope.CnsmrOldNewMtrDetailsByCnsmr(ConsumerId);
    };

    $scope.goBack = function () {
        $window.history.back(-1);
    };    

    var FixedFileSize = 500000;
    var fileSizeAdd = 0;
    $scope.fileName = null;
    $scope.fileName1 = null;
    $scope.filestat = null;
    $scope.fileUploadList = [];
    $scope.fileUploadListOld = [];
    
    $scope.getFileDetails = function ($files, fname) {
        if ($files[0].name != $scope.fileName1) {
            $scope.filestat = null;
            $scope.fileUpload = "";
            $scope.fName = false;
        }
        $scope.uploadFile = $files;
        var allowedFileFormats = ["png"];
        if ($files[0].size > FixedFileSize) {
            if ($scope.filestat == null) {
                alert("File Limit Exceeded 500 KB, please check");
                //$scope.uploadFile = "";
                $scope.fName = true;
                $scope.fileName1 = $files[0].name;
                $scope.filestat = "err";
                //if (fname == 'New') {
                //    $scope.fileUploadList = [];                    
                //}
                //else if (fname == 'LEB') {
                //    $scope.fileUploadListOld = [];                    
                //}
            }
        }
        else if (!(allowedFileFormats.indexOf($files[0].name.split(".").pop().toLowerCase()) > -1)) {
            alert("Only png files are allowed!");
            $scope.filestat = "err";
        }
        else {
            // STORE THE FILE OBJECT IN AN ARRAY.
            for (var i = 0; i < $files.length; i++) {
                //$scope.fileUploadList.push($files[i])
                setupReader($files[i]);
            }
            function setupReader(file) {
                $scope.fileName = file.name;
                var reader = new FileReader();
                reader.onload = function (e) {
                    if (fname == 'New') {
                        $scope.fileUploadList = [];
                        $scope.fileUploadList.push({ "fileBytes": (e.target.result).substring((e.target.result).indexOf("base64,") + 7), "name": file.name });
                    }
                    else if (fname == 'LEB') {
                        $scope.fileUploadListOld = [];
                        $scope.fileUploadListOld.push({ "fileBytes": (e.target.result).substring((e.target.result).indexOf("base64,") + 7), "name": file.name });
                    }                    
                    $scope.fName = false;
                }
                reader.readAsDataURL(file);
            }
        }
    };

    /* CI */
    $scope.UpdateQc_CI = function (type,updType) {
        $scope.EditQcForm.$submitted = true;
        $scope.QCEModel.fileUploadList = $scope.fileUploadList;
        $scope.QCEModel.fileUploadListOld = $scope.fileUploadListOld;

        if ($scope.EditQcForm.$valid) {
            $scope.QCEModel.type = type;
            $scope.QCEModel.updType = updType;
            swal({
                title: "Are you sure?",
                text: "You want to perform this action !",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes",
                closeOnConfirm: false
            }, function (isConfirm) {
                if (!isConfirm)
                    return;

                $http.post(serviceBasePath + "QcAro/UpdateQc_CI", $scope.QCEModel).then(function success(response) {

                    if (response.data.Status == false) {

                        swal({ title: "", text: response.data.Messege, type: "error" },
                            function () {
                                return false;
                            }
                        );

                    } else {
                        swal({ title: "", text: response.data.Messege, type: "success" },
                            function () {
                                if (updType == "QC" || updType == "QCS") {
                                    $window.location.href = ridirectPath + '/QcAro/QcCI';
                                }
                            }
                        );
                    }

                }, function error() {
                    swal("Something Went Wrong !");
                });

            });
        }
        
    };

    $scope.instDate = function (instDt) {
        if (instDt != undefined) {
            var dateOne = new Date(); //Year, Month, Date    
            var dateTwo = new Date(instDt); //Year, Month, Date
            if (dateTwo > dateOne) {
                alert("Installed date cannot be greater than Today, please check!");
                $scope.QCEModel.InstalledDate = '';
                return false;
            }
        }
    }

    $scope.updBtn = function (item) {
        if (item == '' || item == undefined) {
            $scope.updDisabled = false;
        }
        else
            $scope.updDisabled = true;
    }

    /* Image View Code */
    $scope.MeterImage = "";
    $scope.MeterImageView = function (MeterImage) {

        console.log(MeterImage);

        $scope.MeterImage = MeterImage;
        $("#MeterImage").modal("show");
    };

    $scope.MeterImageClose = function () {

        $scope.MeterImage = "";
        $("#MeterImage").modal("hide");
    };
    /* Image View Code Ends */
    
}]);

myApp.directive('ngFiles', ['$parse', function ($parse) {

    function fn_link(scope, element, attrs) {

        var onChange = $parse(attrs.ngFiles);

        element.on('change', function (event) {
            onChange(scope, { $files: event.target.files });
        });
    };
    return {
        link: fn_link

    }
}]);