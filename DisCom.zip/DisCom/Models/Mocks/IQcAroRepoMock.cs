﻿using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class IQcAroRepoMock : IQcAroRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<IQcAroRepoMock> _logger;
        private ICommonRepository _commonRepository;

        public IQcAroRepoMock(ICommonRepository commonRepository, IConfiguration config, ILogger<IQcAroRepoMock> logger)
        {
            _configuration = config;
            _logger = logger;
            _commonRepository = commonRepository;
        }

        public ResponseModel GetQcPendings_CI(string type)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    //var BasePathNewmeter = Convert.ToString(_configuration.GetSection("BasePath").GetSection("api").Value + "Resources/Images/Newmeter/");
                    
                    ResponseModel ResObj = new ResponseModel();
                    List<ConsumerDataModel> list = new List<ConsumerDataModel>();

                    list = (from item in db.TbConsumers
                            where item.QcVerify == 0
                            select new ConsumerDataModel
                            {
                                Id = item.Id,
                                ConsumerNumber = item.ConsumerNumber,
                                Address = item.Address,
                                MobileNumber = item.MobileNumber,
                                OldMeter_Number = item.OldMeterNumber,
                                OldMeter_Reading = item.OldMeterReading,
                                NewMeter_Number = item.NewMeterNumber,
                                InstalledDate = item.InstalledDate,
                                NewMeterImage = item.NewMeterImage,
                                Latest_Ele_BillImage = item.LatestEleBillImage,
                                Latitude = item.Latitude,
                                Longitude = item.Longitude,
                                BoxSeal1 = item.BoxSeal1,
                                BoxSeal2 = item.BoxSeal2,
                                CrtDate = item.CrtDate,
                                CrtName = db.TbUser.FirstOrDefault(x => x.Id == item.CrtBy).UserName,
                            }).ToList();

                    ResObj.Status = true;
                    ResObj.Result = list;
                    ResObj.Messege = "Qc Pending List !";

                    return ResObj;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IQcAroRepoMock-GetQcPendings_CI-" + ex.Message);
                CommonRepoMock.writeLog("IQcAroRepoMock-GetQcPendings_CI", "", ex.Message);
                ResponseModel ResObj = new ResponseModel()
                {
                    Status = false,
                    Result = ex,
                    Messege = "Something Went Wrong !"
                };

                return ResObj;
            }
        }
        
        public ResponseModel UpdateQc_CI(QcHistoryModel details, int UsrId)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    ResponseModel ResObj = new ResponseModel();
                    TbConsumers cnsObj = db.TbConsumers.FirstOrDefault(x => x.Id == details.Id);

                    if (cnsObj != null)
                    {
                        TbConsumers CnsumerObj = db.TbConsumers.Where(x => x.Id == details.Id).Select(x => x).FirstOrDefault();
                        if (details.type == "1")
                        {
                            if (details.updType.ToUpper() == "QC" || details.updType.ToUpper() == "SQC" || details.updType.ToUpper() == "QCS")
                            {
                                CnsumerObj.MobileNumber = details.MobileNumber;
                                CnsumerObj.Address = details.Address;
                                CnsumerObj.OldMeterNumber = details.OldMeter_Number;
                                CnsumerObj.OldMeterReading = details.OldMeter_Reading;
                                CnsumerObj.NewMeterNumber = details.NewMeter_Number;
                                CnsumerObj.InstalledDate = details.InstalledDate;
                                CnsumerObj.Latitude = details.Latitude;
                                CnsumerObj.Longitude = details.Longitude;
                                CnsumerObj.BoxSeal1 = details.BoxSeal1;
                                CnsumerObj.BoxSeal2 = details.BoxSeal2;
                                CnsumerObj.UpdBy = UsrId;
                                CnsumerObj.UpdDate = DateTime.Now;
                                if (details.updType.ToUpper() != "QCS")
                                {
                                    CnsumerObj.QcVerify = 1;
                                }
                                    
                                if (details.fileUploadList.Count > 0)
                                {
                                    CnsumerObj.NewMeterImage = _commonRepository.ImageUploadStringToSteam(Convert.ToString(details.fileUploadList[0].fileBytes), Convert.ToString(details.fileUploadList[0].name), "Oldmeter1");
                                }
                                if (details.fileUploadListOld.Count > 0)
                                {
                                    CnsumerObj.LatestEleBillImage = _commonRepository.ImageUploadStringToSteam(Convert.ToString(details.fileUploadListOld[0].fileBytes), Convert.ToString(details.fileUploadListOld[0].name), "Oldmeter1");
                                }

                                TbConsumerUpdateHistory HistoryObj = new TbConsumerUpdateHistory()
                                {
                                    ConsumerNumber = details.ConsumerNumber,
                                    NewMeterNumber = details.NewMeter_Number,
                                    OldMeterNumber = details.OldMeter_Number,
                                    OldMeterReading = details.OldMeter_Reading,
                                    BoxSeal1 = details.BoxSeal1,
                                    BoxSeal2 = details.BoxSeal2,
                                    Address = details.Address,
                                    MobileNumber = details.MobileNumber,
                                    Latitude = details.Latitude,
                                    Longitude = details.Longitude,
                                    InstalledDate = details.InstalledDate != null ? details.InstalledDate : null,
                                    NewMeterImage = CnsumerObj.NewMeterImage != null ? CnsumerObj.NewMeterImage : details.NewMeterImage,
                                    LatestEleBillImage = CnsumerObj.LatestEleBillImage != null ? CnsumerObj.LatestEleBillImage : details.Latest_Ele_BillImage,
                                    CrtDate = DateTime.Now,
                                    CrtBy = UsrId,
                                };
                                db.TbConsumerUpdateHistory.Add(HistoryObj);
                            }
                            db.SaveChanges();

                            ResObj.Status = true;
                            if (details.updType.ToUpper() == "QCS")
                                ResObj.Messege = "Details Saved!";
                            else
                                ResObj.Messege = details.updType + " Process Completed!";
                        }
                        else
                        {
                            db.TbConsumers.Remove(CnsumerObj);
                            db.SaveChanges();
                            ResObj.Status = true;
                            ResObj.Messege = details.updType + " Rejected Successfully!";
                        }
                    }
                    else
                    {
                        ResObj.Status = false;
                        ResObj.Messege = "Please check!";
                    }

                    return ResObj;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IQcAroRepoMock-UpdateQc_CI-" + ex.Message);
                CommonRepoMock.writeLog("IQcAroRepoMock-UpdateQc_CI", "", ex.Message);
                ResponseModel ResObj = new ResponseModel()
                {
                    Status = false,
                    Result = ex,
                    Messege = "Something Went Wrong !"
                };

                return ResObj;
            }
        }
    }
}
