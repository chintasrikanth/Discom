﻿using System;
using System.IO;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using DisCom.AppConfig;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class CommonRepoMock : ICommonRepository
    {
        //private readonly ILogger<CommonRepoMock> _logger;
        //public CommonRepoMock(ILogger<CommonRepoMock> logger)
        //{
        //    _logger = logger;
        //}

        public static void writeLog(string methodName, string userId, string strMessage)
        {
            try
            {
                string URL = AppDomain.CurrentDomain.BaseDirectory;
                //string newPath = Path.GetFullPath(Path.Combine(URL, @"..\")) + "KarvyClick-LogFiles";
                string newPath = @"C:\" + "SmartMeter_LogFiles";

                if (!Directory.Exists(newPath))
                {
                    // Try to create a directory.
                    Directory.CreateDirectory(newPath);
                }

                var fileName = "LogFile" + "-" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                var logFile = newPath + "\\" + fileName;

                using (StreamWriter writer = new StreamWriter(logFile, true))
                {
                    writer.WriteLine("Error at method " + methodName + " on " + DateTime.Now);
                    writer.WriteLine(strMessage);
                    writer.WriteLine("");
                }

            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("Common-writeLog", userId, ex.Message);
            }
        }
        public string ImageUpload_old(IFormFile file, string path)
        {
            try
            {
                var folderName = Path.Combine("Resources", path);

                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                var extension = "";

                if (file.Length > 0)
                {
                    var fileName1 = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

                    extension = Path.GetExtension(fileName1);

                    var fileName = DateTime.Now.ToFileTime() + extension;


                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = fileName;

                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    return dbPath;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string ImageUpload(IFormFile file, string path)
        {
            try
            {
                var folderName = Path.Combine("Resources", path);

                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                var extension = "";

                if (file.Length > 0)
                {
                    var fileName1 = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

                    extension = Path.GetExtension(fileName1);

                    var fileName = DateTime.Now.ToFileTime() + extension;
                    string mimeType = fileName1;

                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = fileName;

                    using (Stream stream = file.OpenReadStream())
                    {
                        stream.Seek(0, SeekOrigin.Begin);
                        BlobStorageService objBlobService = new BlobStorageService();

                        dbPath = objBlobService.UploadFileToBlob(fileName, stream, path);
                    }

                    return dbPath;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("CommonRepoMock-ImageUpload", "", ex.Message);
                return null;
            }
        }

        public string SendSms(SendSmsModel Obj)
        {
            string SmsResponse = "";

            try
            {
                string APIURL = "https://communications.karvynext.com/communication/api/sms/single_sms";
                var request = (HttpWebRequest)HttpWebRequest.Create(APIURL);


                Obj.clientId = 1;
                request.Method = "POST";
                string RequestBody = JsonConvert.SerializeObject(Obj);
                byte[] byteArray = Encoding.UTF8.GetBytes(RequestBody);
                request.ContentType = "application/json";
                request.ContentLength = byteArray.Length;

                Stream dataStream = request.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);

                using (WebResponse response = request.GetResponse())
                {
                    string successData = ((HttpWebResponse)response).StatusDescription.ToString();
                    if (successData.ToUpper() == "OK")
                    {
                        dataStream = response.GetResponseStream();
                        using (StreamReader reader = new StreamReader(dataStream, Encoding.Default))
                        {
                            SmsResponse = reader.ReadToEnd();

                            return SmsResponse;
                        }
                    }
                    else
                    {
                        return SmsResponse;
                    }
                }

            }
            catch (Exception ex)
            {

                return null;
            }
        }

        public string Otp()
        {
            try
            {
                //Here Specify your OTP Characters
                //allowedChars = "1,2,3,4,5,6,7,8,9,0";
                //If you Need more secure OTP then uncomment Below Lines 
                //  allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";        
                // allowedChars += "~,!,@,#,$,%,^,&,*,+,?";
                string[] saAllowedCharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
                string sOTP = String.Empty;
                string sTempChars = String.Empty;
                Random rand = new Random();

                int iOTPLength = 6;
                for (int i = 0; i < iOTPLength; i++)
                {
                    int p = rand.Next(0, saAllowedCharacters.Length);
                    sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];
                    sOTP += sTempChars;
                }
                return sOTP;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string ImageUploadStringToSteam(string filebytes, string filename, string path)
        {
            try
            {
                var folderName = Path.Combine("Resources", path);

                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                var extension = "";

                if (filebytes.Length > 0)
                {
                    var fileName1 = filename;

                    extension = Path.GetExtension(fileName1);

                    var fileName = DateTime.Now.ToFileTime() + extension;
                    string mimeType = fileName1;

                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = fileName;

                    var byteArray = Convert.FromBase64String(filebytes);
                    using (Stream stream = new MemoryStream(byteArray))
                    {
                        stream.Seek(0, SeekOrigin.Begin);
                        BlobStorageService objBlobService = new BlobStorageService();

                        dbPath = objBlobService.UploadFileToBlob(fileName, stream, path);
                    }

                    return dbPath;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("CommonRepoMock-ImageUpload", "", ex.Message);
                return null;
            }
        }
    }
}
