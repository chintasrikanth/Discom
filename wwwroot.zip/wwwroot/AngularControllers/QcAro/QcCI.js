﻿myApp.controller('QcCICtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.numPerPageList = [{ 'name': "5", "value": 5 }, { 'name': "10", "value": 10 }, { 'name': "20", "value": 20 }];
    $scope.sortBy = 'IndexedDt';
    $scope.reverse = true;
    $scope.numPerPage = 5;
    $scope.pageNum = 1;
    $resultsOnPage = "";

    $scope.sort = function (keyname) {
        $scope.sortBy = keyname;   //set the sortBy to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };


    $scope.getSortClass = function (column) {
        if ($scope.sortBy === column) {
            return $scope.reverse ? 'feather feather-arrow-down' : 'feather feather-arrow-up';
        }
    };

    $scope.StatusList = [{ 'name': "Active", 'value': 1 }, { 'name': "IN-Active", 'value': 0 }];

    $scope.dLoadDisabled = false;
    $scope.dtFrom = "01-Jan-2020";
    $scope.dtTo = "31-Dec-2040";
    $scope.PendingQcList = "";
    $scope.GetQcPendings = function () {

        $http.get(serviceBasePath + "QcAro/GetQcPendings_CI/QC").then(function success(res) {

            if (res.data.Status == true) {
                $scope.PendingQcList = res.data.Result;
            }

        }, function errro() {

            swal("Something Went Wrong !");
        });
    };

    $scope.GetQcPendings();

    $scope.InitView = function (ConsumerId) {
        $window.open(ridirectPath + '/QcAro/QcDetails_CI/' + ConsumerId, "_self");
    };    

    $scope.DownloadExcel = function () { // ex: '#my-table'
        $scope.dLoadDisabled = true;

        var row = $scope.PendingQcList;
        var Head = [[

            'Consumernumber',
            'Address',
            'MobileNumber',
            'Old Meternumber',
            'OldMeter_Reading',
            'NewMeter_Number',
            'Installed Date',
            'NewMeterImage',
            'Latest_Ele_BillImage',
            'Latitude',
            'Longitude',
            'Box Seal1',
            'Box Seal2',
            'Created Date',
            'Created By',

        ]];

        for (var item = 0; item < row.length; ++item) {

            var addr = row[item].Address;
            if (row[item].Address != null) {
                addr = row[item].Address.replace(/,/g, '"');
                addr = addr.replace(/T/g, ' ');
                addr = addr.trim();
                addr = addr.replace(/\n/g, ' ');
            }

            var oldMN = row[item].OldMeter_Number;
            if (row[item].OldMeter_Number != null) {
                oldMN = row[item].OldMeter_Number.trim();
            }

            var instDt = row[item].InstalledDate;
            if (row[item].InstalledDate != null) {
                instDt = row[item].InstalledDate.replace(/T/g, ' ');
            }

            var crtDt = row[item].CrtDate;
            if (row[item].CrtDate != null) {
                crtDt = row[item].CrtDate.replace(/T/g, ' ');
            }

            var BoxSeal1 = row[item].BoxSeal1;
            if (row[item].BoxSeal1 != null) {
                BoxSeal1 = row[item].BoxSeal1.trim();
                BoxSeal1 = BoxSeal1.replace(/,/g, '"');
            }

            var BoxSeal2 = row[item].BoxSeal2;
            if (row[item].BoxSeal2 != null) {
                BoxSeal2 = row[item].BoxSeal2.trim();
                BoxSeal2 = BoxSeal2.replace(/,/g, '"');
            } 

            Head.push([
                row[item].ConsumerNumber,
                addr,
                row[item].MobileNumber,
                oldMN,
                row[item].OldMeter_Reading,
                row[item].NewMeter_Number,
                instDt,
                row[item].NewMeterImage,
                row[item].Latest_Ele_BillImage,
                row[item].Latitude,
                row[item].Longitude,
                BoxSeal1,
                BoxSeal2,
                crtDt,
                row[item].CrtName,

            ]);
        }

        var csvRows = [];
        for (var cell = 0; cell < Head.length; ++cell) {
            csvRows.push(Head[cell].join(','));
        }

        var csvString = csvRows.join("\n");
        let csvFile = new Blob([csvString], { type: "text/csv" });
        let downloadLink = document.createElement("a");

        downloadLink.download = 'ConsumerData.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = "none";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        $scope.dLoadDisabled = false;        
    }   

    /* Image View Code */
    $scope.MeterImage = "";
    $scope.MeterImageView = function (MeterImage) {

        console.log(MeterImage);

        $scope.MeterImage = MeterImage;
        $("#MeterImage").modal("show");
    };

    $scope.MeterImageClose = function () {

        $scope.MeterImage = "";
        $("#MeterImage").modal("hide");
    };

    /* Image View Code Ends */

}]);