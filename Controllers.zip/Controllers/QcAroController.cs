﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace smartmeter.Controllers
{
    public class QcAroController : Controller
    {
        public ActionResult QcCI()
        {
            return View();
        }
        
        [HttpGet,Route("QcAro/QcDetails/{ConsumerId}")]
        public ActionResult QcDetails(int ConsumerId)
        {
            ViewBag.ConsumerId = ConsumerId;
            return View();
        }

        [HttpGet, Route("QcAro/QcDetails_CI/{ConsumerId}")]
        public ActionResult QcDetails_CI(int ConsumerId)
        {
            ViewBag.ConsumerId = ConsumerId;
            return View();
        }        
    }
}