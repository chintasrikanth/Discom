﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models.ViewModels;


namespace DisCom.Models.Contracts
{
    public interface IMyAccountRepository
    {
        ResponseModel ResetPwd(TbUserModel user);
    }
}
