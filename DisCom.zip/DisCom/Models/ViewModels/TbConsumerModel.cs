﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace DisCom.Models.ViewModels
{
    public class ConsumerDataModel
    {
        public int Id { get; set; }
        public string ConsumerNumber { get; set; }
        public string NewMeter_Number { get; set; }
        public string OldMeter_Number { get; set; }
        public string OldMeter_Reading { get; set; }
        public string BoxSeal1 { get; set; }
        public string BoxSeal2 { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public IFormFile newMeterImage { get; set; }
        public IFormFile latest_Ele_BillImage { get; set; }
        public string NewMeterImage { get; set; }
        public string Latest_Ele_BillImage { get; set; }
        public DateTime? InstalledDate { get; set; }
        public DateTime? CrtDate { get; set; }
        public int? CrtBy { get; set; }
        public string CrtName { get; set; }
        public DateTime? UpdDate { get; set; }
        public int? UpdBy { get; set; }
        public string UpdName { get; set; }
    }

    public class ConsumerModel
    {
        public int Id { get; set; }
        public string ConsumerName { get; set; }
        public string ConsumerNumber { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string ContractedLoad { get; set; }
        public string ConnectedLoad { get; set; }
        public DateTime? SupplyReleaseDate { get; set; }
        public string Category { get; set; }
        public string CategoryCode { get; set; }
        public string LoadUnit { get; set; }
        public string ConsumerType { get; set; }
        public int? DiscomId { get; set; }

        [Required]
        public int? CircleId { get; set; }
        [Required]
        public int? DivisionId { get; set; }
        [Required]
        public int? SubStationId { get; set; }

        [Required]
        public string FeederCode { get; set; }
        [Required]
        public string DtrCode { get; set; }

        
        public string FeederName { get; set; }
        
        public string DtrName { get; set; }


        public byte? IsIndexed { get; set; }
        public string MeterImage { get; set; }
        public string MeterImage1 { get; set; }
        public string IdProofImage { get; set; }
        public DateTime? IndexedDate { get; set; }
        public DateTime? InstalledDate { get; set; }



        public string Discom { get; set; }

        public string Circle { get; set; }

        public string Division { get; set; }
        public string SubDivision { get; set; }

        public string SubStation { get; set; }

        public string TariffCode { get; set; }
        public string ConsumerTownName { get; set; }
        public string ConsumerBillingType { get; set; }
        public int? AccountNo { get; set; }
        public int? BinderNo { get; set; }
        public string ConsumerArea { get; set; }
        public string QcStatus { get; set; }
        public string AroStatus { get; set; }
        public byte? IsWired { get; set; }

        public string signalStrength { get; set; }
        public int? signalLevel { get; set; }
        public string networkProvider { get; set; }
        public string EeslStatus { get; set; }
        public string remarks { get; set; }
        public string signalCategory { get; set; }

        public string cIQcStatus { get; set; }
        public string cIAroStatus { get; set; }
        public string cIEeslStatus { get; set; }
    }

    public class ConsumerListModelParam
    {       
        public int UserId { get; set; }
       
        public int RoleId { get; set; }       

        [Required]
        public byte IsIndexed { get; set; }

        public string SearchString { get; set; }
        public string Phase { get; set; }

    }

}
