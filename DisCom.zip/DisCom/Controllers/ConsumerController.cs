﻿using System;
using System.Linq;
using DisCom.Models.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DisCom.Models.ViewModels;
using System.Security.Claims;
using System.Collections.Generic;
//using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
    [ApiController, Authorize]
    public class ConsumerController : ControllerBase
    {
        private IConsumerRepository _consumerRepository;
        //private readonly IHostingEnvironment _env;

        public ConsumerController(IConsumerRepository consumerRepository)
        {
            _consumerRepository = consumerRepository;
            //_env = env;
            //if (string.IsNullOrWhiteSpace(_env.WebRootPath))
            //{
            //    _env.WebRootPath = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Resources");
            //}
        }
        
        [HttpGet, Route("GetConsumers/{numPerPage}/{pageNum}/{uId}/{consType}/{searchString?}")]
        public ActionResult GetConsumers(int numPerPage, int pageNum, int uId, int consType, string searchString)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var claimsIdentity = this.User.Identity as ClaimsIdentity;
                    var roleId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.Role)?.Value);
                    var result = _consumerRepository.GetConsumers(numPerPage, pageNum, searchString, uId, roleId,consType);

                    ResponseModel ResObj = new ResponseModel { Status = true, Result = result, Messege = "Consumer List" };
                    if (result.Status == true)
                    {
                        return Ok(result);
                    }
                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Consumer List" };
                    return BadRequest(ResObj);
                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet, Route("GetConsumerList")]
        public ActionResult GetConsumerList()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var claimsIdentity = this.User.Identity as ClaimsIdentity;
                    var roleId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.Role)?.Value);
                    var result = _consumerRepository.GetConsumerList(roleId);

                    ResponseModel ResObj = new ResponseModel { Status = true, Result = result, Messege = "Consumer List" };
                    if (result.Status == true)
                    {
                        return Ok(result);
                    }
                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Consumer List" };
                    return BadRequest(ResObj);
                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /* Code For Listing Consumers For Mobile For FE And Supervisior Login */
        [HttpPost, Route("GetConsumersByStatOffLine")]
        public ActionResult GetConsumersByStatOffLine(ConsumerListModelParam Filterpamrams)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var claimsIdentity = this.User.Identity as ClaimsIdentity;
                    var RoleId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.Role)?.Value);
                    var UsrId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);

                    Filterpamrams.RoleId = RoleId;
                    Filterpamrams.UserId = UsrId;

                    var result = _consumerRepository.GetConsumersByStatOffLine(Filterpamrams);

                    ResponseModel ResObj = new ResponseModel { Status = true, Result = result, Messege = "Consumer List" };
                    if (result.Status == true)
                    {
                        return Ok(result);
                    }
                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Something Went Wrong ! " };
                    return BadRequest(ResObj);
                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost, Route("UpdateConsumerData")]
        public ActionResult UpdateConsumerData([FromForm] ConsumerDataModel consumer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var claimsIdentity = this.User.Identity as ClaimsIdentity;
                    var UsrId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);
                    
                    var result = _consumerRepository.UpdateConsumerData(consumer, UsrId);

                    var ResObj = new ResponseModel
                    {
                        Status = true,
                        Messege = "Meter and Consumer Details Updated Successfully !"
                    };

                    if (result.Status == true)
                    {
                        return Ok(result);
                    }
                    else
                    {
                        return BadRequest(result);
                    }

                }
                else
                {
                    ResponseModel ResObj = new ResponseModel { Status = false, Result = ModelState.Values.SelectMany(v => v.Errors), Messege = "Something Went Wrong ! " };
                    return BadRequest(ResObj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        [HttpGet, Route("CnsmrOldNewMtrDetailsByCnsmr/{Id}")]
        public ActionResult CnsmrOldNewMtrDetailsByCnsmr(int Id)
        {
            try
            {
                var result = _consumerRepository.CnsmrOldNewMtrDetailsByCnsmr(Id);

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            }
            catch (Exception ex)
            {
                return null;
            }

        }

        //[HttpPost, Route("ConsumerUpdateUpload")]
        //[Authorize(Roles = "1")]
        //public ActionResult ConsumerUpdateExcel(UploadConsumerUpdateModelTest MasterList)
        //{
        //    var claimsIdentity = this.User.Identity as ClaimsIdentity;
        //    var UsrId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);

        //    var createdBy = UsrId;

        //    var res = _consumerRepository.ConsumerUpdateUpload(MasterList, createdBy);
        //    if (res.Status == true)
        //    {
        //        return Ok(res);
        //    }
        //    else if (res.Status == false && res.Messege != "Something went wrong")
        //    {
        //        return Ok(res);
        //    }
        //    else
        //    {
        //        return BadRequest(res);
        //    }
        //}

        //[HttpGet, Route("GetUploadLogs_CDUpate")]
        //public ActionResult GetUploadLogs_CDUpate()
        //{
        //    try
        //    {
        //        var res = _consumerRepository.GetUploadLogs_CDUpate();
        //        return Ok(res);
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}

    }
}