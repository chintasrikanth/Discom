using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.ViewModels
{
    public class UploadModel
    {
        public string Discom { get; set; }

        public int CircleId { get; set; }
        public string CircleName { get; set; }
        public int DivisionId { get; set; }
        public string DivisionName { get; set; }
        public int SubDivisionId { get; set; }
        public string SubDivisionName { get; set; }
        public int SubStationId { get; set; }
        public string SubStationName { get; set; }
        public string TownName { get; set; }

        public string SubStationCode { get; set; }
        public int? FeederId { get; set; }
        public string FeederName { get; set; }
        public string FeederCode { get; set; }
        public int? DtrId { get; set; }
        public string DtrCode { get; set; }
        public string DtrName { get; set; }
        public int OldMeterId { get; set; }
        public string TariffCode { get; set; }                           

        public int? ConsumerId { get; set; }
        public string OldMeterNumber { get; set; }
        public string OldMeterManufacturer { get; set; }
        public string MeterType { get; set; }
        public string OldMeterPhase { get; set; }
        public DateTime InstallationDate { get; set; }
        public string Mf { get; set; }
        public string MeterLatitude { get; set; }
        public string MeterLongitude { get; set; }
        public DateTime CommisioningDate { get; set; }
        public byte? IsActive { get; set; }

        public string OldMeterReading { get; set; }
        public string PoleId { get; set; }
        public string PoleLatitude { get; set; }
        public string PoleLongitude { get; set; }

        public string OldMeterImage { get; set; }
        public string OldMeterImage1 { get; set; }
        public string OldMeterStatusCode { get; set; }
        public DateTime? OldMeterPrevReadingDate { get; set; }
        public DateTime? OldMeterCurrentReadingDate { get; set; }
        public string OldMeterPrevKWH { get; set; }
        public string OldMeterPrevKVAH { get; set; }
        public string OldMeterPrevKVA { get; set; }
        public string OldMeterCurrentKWH { get; set; }
        public string OldMeterCurrentKVAH { get; set; }
        public string OldMeterCurrentKVA { get; set; }
        public string OldMeterPF { get; set; }
        public string OldMeterNetCons { get; set; }
        public string OldMeterNetMDI { get; set; }
        public DateTime? OldMeterFinalizationDate { get; set; }
        public DateTime? OldMeterOrderDate { get; set; }
        public string OldMeterCurrentStatus { get; set; }

        public string ConsumerName { get; set; }
        public string OfficeName { get; set; }

        public string ConsumerNumber { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Remarks { get; set; }

        public string ContractedLoad { get; set; }
        public string ConnectedLoad { get; set; }
        public DateTime? SupplyReleaseDate { get; set; }
        public string Category { get; set; }
        public string CategoryCode { get; set; }

        public string LoadUnit { get; set; }
        public string ConsumerBillingType { get; set; }

        public decimal DiscomId { get; set; }

        public byte? IsIndexed { get; set; }
        public string MeterImage { get; set; }
        public string MeterImage1 { get; set; }
        public string IdProofImage { get; set; }
        public DateTime? IndexedDate { get; set; }
        public DateTime? InstalledDate { get; set; }

        public DateTime? CreatedAt { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedBy { get; set; }

        public string BinderNo { get; set; }
        public string AccountNo { get; set; }
        public string CONSUMER_AREA { get; set; }
        public string CONSUMER_TYPE { get; set; }
        public string RentCode { get; set; }
        public string isAndaman { get; set; }
    }
    public class UploadCIModel
    {
        public string ConsumerNumber { get; set; }
        public string Remarks { get; set; }
    }
    public class UploadConsumerUpdateModel
    {
        public string ConsumerNumber { get; set; }
        public string Mobile_Number { get; set; }
        public string Email { get; set; }

        public string Meter_Number { get; set; }
        public string Meter_Manufacturer { get; set; }
        public string Meter_Reading { get; set; }
        public string Current_KWH { get; set; }
        public string Current_KVAH { get; set; }
        public string Current_KVA { get; set; }

        public string oldMeterReading { get; set; }
        public string NewMeter_Previous_KWH { get; set; }
        public string NewMeter_Current_KVAH { get; set; }

        public string ExistMeterSealStatus { get; set; }
        public string SealingStatus { get; set; }
        public string StatusofServicecable { get; set; }
        public string NoofJointsInServiceCable { get; set; }
        public string ServiceLineStatus { get; set; }
        public string signalStrength { get; set; }
        public int? signalLevel { get; set; }
        public string signalCategory { get; set; }
        public int? IsWired { get; set; }
        public string Address { get; set; }

        //public string columnName { get; set; }
        public string Remarks { get; set; }
        public string QueryEditor { get; set; }
        public string QueryEditor1 { get; set; }
    }
    public class UploadConsumerUpdateModelTest
    {
        public List<UploadConsumerUpdateModel> UploadConsumerUpdate { get; set; }
        public string columnName { get; set; }

    }
}
