﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
   // [ApiController, Authorize]
    [ApiController, Authorize(Roles = "1")]
    public class RoleController : ControllerBase
    {
        private IRoleRepository _roleRepository;

        public RoleController(IRoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }

        [HttpGet, Route("GetRoles")]
        public ActionResult GetRoles()
        {
            try
            {
                ResponseModel result = _roleRepository.GetRoles();

                if (result.Status == true)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost,Route("CreateRole")]
        public ActionResult CreateRole(TbRoleModel role)
        {
            try
            {
                var claimsIdentity = this.User.Identity as ClaimsIdentity;              
                var Id = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);
                role.CrtBy = Id;
                role.UpdBy = Id;

                ResponseModel result =  _roleRepository.CreateRole(role);

                if(result.Status == true)
                {
                    return Ok(result);
                }
                else if(result.Status == false && result.Messege == "Role Already Exist !")
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            } catch(Exception ex)
            {
                return null;
            }
        }


        [HttpPost,Route("UpdateRole")]
        public ActionResult UpdateRole(TbRoleModel role)
        {
            try
            {
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var Id = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);
                role.UpdBy = Id;

               var result =  _roleRepository.UpdateRole(role);

                if (result.Status == true)
                {
                    return Ok(result);
                }

                if (result.Status == false)
                {
                    return Ok(result);
                }

                else if (result.Status == false && result.Messege == "Something Went Wrong !")
                {
                    return BadRequest(result);
                }
                else
                {
                    return BadRequest("Something Went Wrong");
                }


            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}