﻿
myApp.controller('MyAccountCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.UserDetails = "";
    $scope.RPModel = { UserEnccryptedPassword: "", Id: "" };
         
    $scope.GetUserById = function () {

        $http.get(serviceBasePath + "User/GetUserById/" + $sessionStorage.UsrId).then(function success(response) {

            if (response.data.Status == true) {

                $scope.UserDetails = response.data.Result;
            }

        }, function error() {

        });
    };

    $scope.GetUserById();


    $scope.ResetPwd = function () {


        $scope.RPModel.Id = $sessionStorage.UsrId;

        $scope.ResetPasswordForm.$submitted = true;

        if ($scope.ResetPasswordForm.$valid) {


            $http.post(serviceBasePath + "MyAccount/ResetPwd", $scope.RPModel).then(function success(response) {


                if (response.data.Status === true) {

                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {
                            $sessionStorage.user = null;


                            $window.location.href = ridirectPath;

                        }
                    );
                }


            }, function error() {


            });
        }
    };


}]);
