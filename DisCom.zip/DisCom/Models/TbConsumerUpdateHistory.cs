﻿using System;
using System.Collections.Generic;

namespace DisCom.Models
{
    public partial class TbConsumerUpdateHistory
    {
        public int Id { get; set; }
        public string ConsumerNumber { get; set; }
        public string NewMeterNumber { get; set; }
        public string OldMeterNumber { get; set; }
        public string OldMeterReading { get; set; }
        public string BoxSeal1 { get; set; }
        public string BoxSeal2 { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public DateTime? InstalledDate { get; set; }
        public string NewMeterImage { get; set; }
        public string LatestEleBillImage { get; set; }
        public int CrtBy { get; set; }
        public DateTime? CrtDate { get; set; }
        public int? UpdBy { get; set; }
        public DateTime? UpdDate { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}
