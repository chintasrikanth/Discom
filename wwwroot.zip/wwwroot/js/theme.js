(function($) {
  'use strict';

  var initBodyClass = "";
  if($("body").hasClass("sidebar-collapse")) {
    initBodyClass = "sidebar-collapse";
  } else if ($("body").hasClass("sidebar-expand")) {
    initBodyClass = "sidebar-expand";
  }

  var uiadmin = {
    init: function() {
      this.collapseNavbar();
      $(window).scroll(this.collapseNavbar);
      this.contentHeight();

      this.header();
      this.sidebar();
      this.content();
      this.enableScrollbar();
      this.inputFocus();
      this.productLineMorrisChart();
      this.enableTooltip();
      this.enableRadioCheckbox();
      this.enableValidation();
      this.enablePace();
      this.enablePlugins();
    },

    enablePace: function() {
      Pace.on('done', function() {
        $(document).trigger('PACE_DONE');
      });
    },

    enablePlugins: function() {
      this.enableSweetAlert();
      // this.enableDataTables();
      this.enableInputMask();
      this.enableDateRangePicker();
      this.enablePredefinedDateRangePicker();
      this.enableDatePicker();
      this.enableSelect2();
      this.enableMultiSelect();
    },

    collapseNavbar: function() {
      if( $(window).scrollTop() > 30 ) {
        $("#wrapper").addClass("fix-top");
      }
      else {
        $("#wrapper").removeClass("fix-top");
      }
    },

    header: function() {

    },

    contentHeight: function() {
      var width = window.innerWidth > 0 ? window.innerWidth:screen.width;
      var l;

      if ( width > 720 && $("body").hasClass("collapse-collapse") ) {
        l = $(".site-sidebar").outerHeight() - 1;
        $(".main-wrapper").css("min-height", l + "px");
      }
      if ( width > 720 && $("body").hasClass('sidebar-horizontal') ) {
        l = (window.innerHeight > 0 ? window.innerHeight : this.screen.height) - 1 - $(".navbar").outerHeight() - $('.site-sidebar').outerHeight();
        $(".main-wrapper").css("min-height", l + "px");
      }
      else if (width > 720) {
        l = (window.innerHeight > 0 ? window.innerHeight : this.screen.height) - 1 - $(".navbar").outerHeight();
        $(".main-wrapper").css("min-height", l + "px");
      }
    },

    content: function() {
      $(".card-expandable .card-header").on("click",function(e) {
        $(this).parents(".card").toggleClass("card-expanded");
      });

      this.enableMagnificPopup();

      var scrollToBottom = document.getElementsByClassName('scroll-to-bottom');
      for( var i = 0; i < scrollToBottom.length; i++ ) {
        scrollToBottom[i].scrollTop = scrollToBottom[i].scrollHeight;
      }

      $('.blog-post-share-links .toggle-link').click(function() {
        $(this).closest('ul').toggleClass('active');
      });
    },

    initScrollbar: function($el) {
      $el.perfectScrollbar($el[0].dataset);
    },

    sidebar: function() {
      var self = this;
      if( document.body.classList.contains('sidebar-expand') )
      $('.side-menu').metisMenu({ preventDefault: true });
      $('.side-menu').on('show.metisMenu',function() {
        $('.site-sidebar.scrollbar-enabled').perfectScrollbar('destroy');
        self.initScrollbar( $('.site-sidebar.scrollbar-enabled') );
      });
      this.sidebarToggle();
      this.sidebarUserToggle();
    },

    setMenu: function(){
      var self = this;
      var width = window.innerWidth > 0 ? window.innerWidth:screen.width;
      var $body = $("body");
      $('.site-sidebar.scrollbar-enabled').perfectScrollbar('destroy').removeClass('ps');

      if (width < 961) {
        $('.side-menu').metisMenu({ preventDefault: true });
      }
      else if (width > 960 && width < 1170 && initBodyClass == "sidebar-expand") {
        $(".site-sidebar").show();
        $body.removeClass("sidebar-expand");
        $body.addClass("sidebar-collapse");
      }
      else if (width >= 1170 && initBodyClass == "sidebar-expand") {
        $(".site-sidebar").show();
        $body.removeClass("sidebar-collapse");
        $body.addClass("sidebar-expand");
        uiadmin.initScrollbar( $('.site-sidebar.scrollbar-enabled') );
      }
      else if ($body.hasClass("sidebar-expand")) {
        $(".site-sidebar").show();
        uiadmin.initScrollbar( $('.site-sidebar.scrollbar-enabled') );
      }
      else if ( document.body.classList.contains('sidebar-horizontal') ) {
        $(".site-sidebar").show();
        $('.side-menu').metisMenu('dispose');
      }
      else {
        $(".site-sidebar").show();
      }
    },

    sidebarToggle: function() {
      var self = this;
      $(".sidebar-toggle a").on("click",function(){
        var width = window.innerWidth > 0 ? window.innerWidth : screen.width;
				var $body = $("body");
        $('.site-sidebar.scrollbar-enabled').perfectScrollbar('destroy').removeClass('ps');

        if (width < 961) {
          $(".site-sidebar").toggle();
        }
        else if ($body.hasClass("sidebar-expand")) {
          $body.removeClass("sidebar-expand");
          $body.addClass("sidebar-collapse");
          $(".side-user > a").removeClass("active");
          $(".side-user > a").siblings(".side-menu").hide();
          $('.side-menu .sub-menu').css('height', 'auto');
          $('.side-menu').metisMenu('dispose');
        }
        else if ($body.hasClass("sidebar-collapse")) {
          $body.removeClass("sidebar-collapse");
          $body.addClass("sidebar-expand");
          self.initScrollbar( $('.site-sidebar.scrollbar-enabled') );
          $('.side-menu').metisMenu({ preventDefault: true });
        }

        uiadmin.contentHeight();
        if( width > 961 ) {
          $(document).trigger("SIDEBAR_CHANGED_WIDTH");
        }
      });

    },

    sidebarUserToggle: function() {
      $(".side-user > a").on("click",function(){
        if ($('body').hasClass("sidebar-collapse") === false) {
          $(this).toggleClass("active");
          $(this).siblings(".side-menu").toggle();
        }
      });
    },

    enableMagnificPopup: function() {
      var el = $('[data-toggle="lightbox"], [data-toggle="lightbox-gallery"]');
      if(!el.length) return;
      el.each(function() {
        var $this = $(this),
            src = $this.data('src'),
            type = $this.data('type'),
            defaults = {},
            options = $this.data('plugin-options') !== undefined ? $this.data('plugin-options') : {},
            lightboxClass = $this.data('lightbox-class') !== undefined ? $this.data('lightbox-class') : "";

        if( $this.data('toggle') === "lightbox" ) {
          defaults = {
            type: type,
            callbacks: {
              beforeOpen: function() {
                this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure animated ' + this.st.el.attr('data-effect') );
              }
            }
          };
          options = $.extend( {}, defaults, options);
          $this.magnificPopup(options);
        }

        else if( $this.data('toggle') === "lightbox-gallery" ) {
          defaults = {
            type: type,
            delegate: 'a',
            gallery: {
              enabled: true,
            },
            callback: {
              beforeOpen: function() {
                this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure animated ' + this.st.el.attr('data-effect') );
              }
            }
          };
          options = $.extend( {}, defaults, options);
          $this.magnificPopup(options);
        }
      });
    },

    enableScrollbar: function() {
      var el = $('.scrollbar-enabled, .dropdown-list-group ');
      if(!el.length) return;
      el.each(function(index){

        var $this = $(this);
        var options = {
          wheelSpeed: 0.5
        };
        if( this.classList.contains('suppress-x') ) options.suppressScrollX = true;
        if( this.classList.contains('suppress-y') ) options.suppressScrollY = true;
        $this.perfectScrollbar(options);

        if($this.parent().parent().hasClass('dropdown-card')) {
          $(document).on('shown.bs.dropdown',$this.parent().parent(), function(){
            $this.perfectScrollbar('update');
          });
        }

        $(document).on('show.metisMenu, hide.metisMenu', function() {
          $this.perfectScrollbar('update');
        });

        if ( this.classList.contains('scroll-to-bottom') ) {
          this.scrollTop = this.scrollHeight;
          $this.perfectScrollbar('update');
        }

      });
    },

    inputFocus: function() {
      var el = $('input:not([type=checkbox]):not([type=radio]), textarea');
      if( !el.length ) return;

      el.each(function() {
        var $this = $(this),
            self = this;

        var hasValueFunction = function() {
          if( self.value.length > 0 ) {
            self.parentNode.classList.add('input-has-value');
            $(self).closest('.form-group').addClass('input-has-value');
          }
          else {
            self.parentNode.classList.remove('input-has-value');
            $(self).closest('.form-group').removeClass('input-has-value');
          }
        };

        hasValueFunction(this);
        $this.on('input', hasValueFunction);

        $this.focusin(function() {
          this.parentNode.classList.add('input-focused');
          $this.closest('.form-group').addClass('input-focused');
        });
        $this.focusout(function() {
          this.parentNode.classList.remove('input-focused');
          $this.closest('.form-group').removeClass('input-focused');
        });

        $this.find('.remove-focus').on('click',function() {
          $this.emit('focusout');
        });
      });
    },

    /*************** Morris charts ****************/
    productLineMorrisChart: function() {
      //var ctx = document.getElementById("productLineMorris");
      //if ( ctx === null ) return;

      //var chart = Morris.Area({
      //  element: 'productLineMorris',
      //  data: [{
      //    period: '2010',
      //    Pending: 70,
      //    Indexed: 110,
      //    Installed: 80
      //  }, {
      //    period: '2011',
      //    Pending: 75,
      //    Indexed: 95,
      //    Installed: 90
      //  }, {
      //    period: '2012',
      //    Pending: 85,
      //    Indexed: 102,
      //    sony: 75
      //  }, {
      //    period: '2013',
      //    Pending: 75,
      //    Indexed: 90,
      //    sony: 104
      //  }, {
      //    period: '2014',
      //    Pending: 95,
      //    Indexed: 105,
      //    sony: 75
      //  }, {
      //    period: '2015',
      //    Pending: 87,
      //    Indexed: 95,
      //    sony: 80
      //  },
      //  {
      //    period: '2016',
      //    Pending: 92,
      //    Indexed: 108,
      //    sony: 70
      //  }],
      //  xkey: 'period',
      //  ykeys: ['Pending', 'Indexed', 'Installed'],
      //    labels: ['Pending', 'Indexed', 'Installed'],
      //  ymax: 'auto[110]',
      //  ymin: 'auto[70]',
      //  pointSize: 3,
      //  fillOpacity: 0,
      //  pointStrokeColors:['#00bfc7', '#fb9678', '#9675ce'],
      //  behaveLikeLine: true,
      //  gridLineColor: '#e0e0e0',
      //  lineWidth: 1,
      //  hideHover: 'auto',
      //  lineColors: ['#00bfc7', '#fb9678', '#9675ce'],
      //  resize: true
      //});

      //$(document).on('SIDEBAR_CHANGED_WIDTH', chart.resizeHandler);
    },

    enableDataTables: function() {
      $('.datatable').DataTable();
    },
    enableTooltip: function() {
      $('[data-toggle="tooltip"]').tooltip();
    },

    enableMailbox: function() {
      this.enableMailboxInbox();
    },



    enableRadioCheckbox: function() {
      var input = document.getElementsByTagName('input');
      for( var i = 0; i < input.length; i++ ) {
        if( input[i].type === 'checkbox' ) {
          if( input[i].checked === true ) {
            input[i].parentNode.classList.add('checkbox-checked');
          }
          input[i].addEventListener('change', function() {
            if( this.checked === true ) {
              this.parentNode.classList.add('checkbox-checked');
            } else {
              this.parentNode.classList.remove('checkbox-checked');
            }
          });
        }
      }
    },

    enableValidation: function() {
      if( typeof $.validate === 'function' ) {
        $.validate({
          modules: 'security, date',
          errorMessageClass: 'invalid-feedback',
          errorElementClass: 'is-invalid',
        });
      }

      this.enableFieldLengthIndicator();
    },

    enableFieldLengthIndicator: function() {
      var el = $('.field-length-indicator');
      if( !el.length ) return;
      el.each(function() {
        var $this = $(this),
            target = $this.data('length-target');

        $(target).restrictLength( $this.find('.indicator') );
      });
    },

    enableSweetAlert: function() {
      if( typeof swal === 'function' ) {
        swal.setDefaults({
          buttonsStyling: false, // disables plugn styles for buttons
          cancelButtonClass: 'btn btn-default',
          confirmButtonClass: 'btn btn-info'
        });
      }

      var el = $('.modal-alert');
      if( !el.length ) return;
      el.each(function() {
        var $this = $(this);
        var options = {};

        if ( $this.data('title') !== undefined ) options.title = $this.data('title');
        if ( $this.data('text') !== undefined ) options.text = $this.data('text');

        if ( $this.data('type') !== undefined ) {
          options.type = $this.data('type');

          switch( $this.data('type') ) {
            case 'success': options.confirmButtonClass = 'btn btn-success'; break;
            case 'warning': options.confirmButtonClass = 'btn btn-warning'; break;
            case 'error': options.confirmButtonClass = 'btn btn-danger'; break;
            default: options.confirmButtonClass = 'btn btn-info';
          }
        } else {
          options.confirmButtonClass = 'btn btn-info';
        }

        if ( $this.data('button-text') !== undefined ) options.confirmButtonText = $this.data('button-text');

        $this.click(function() {
          swal(options);
        });
      });
    },


    enableInputMask: function() {
      var el = $('[data-masked-input]');
      if(!el.length) return;
      $.mask.definitions.h = "[A-Fa-f0-9]";
      $.mask.definitions['~']='[+-]';
      el.each(function() {
        var $this = $(this),
            mask = $this.data('masked-input');
        $this.mask(mask);
      });
    },

    enableDateRangePicker: function() {
      var el = $('.daterange');
      if( !el.length ) return;
      var defaults = {
        locale: {
          format: 'MMMM D',
        },
      };
      el.each(function(){
        var $this = $(this),
            options = $this.data('plugin-options');

        if( this.uiadmin === undefined )
          this.uiadmin = {};

        if( options === undefined ) options = {};
        options = $.extend({}, defaults, options);
        $this.daterangepicker(options);
        this.uiadmin.daterangepicker = $this.data('daterangepicker');
      });
    },

    enablePredefinedDateRangePicker: function() {
      var $el = $('.predefinedRanges');
      if ( !$el.length ) return;
      var defaults = {
        locale: {
          format: 'MMMM-D',
        },
        startDate: moment().subtract(29, 'days'),
        endDate: moment(),
        opens: "left",
        ranges: {
          'Today': [moment(), moment()],
          'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month': [moment().startOf('month'), moment().endOf('month')],
          'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
      };
      $el.each( function() {
        var start = moment().subtract(29, 'days');
        var end = moment();
        var $this = $(this);
        var options = $this.data('plugin-options');
        options = $.extend({}, defaults, options);
        function cb(start, end) {
          $this.find('span').html(start.format(options.locale.format) + ' - ' + end.format(options.locale.format));
        }

        if( this.uiadmin === undefined )
          this.uiadmin = {};

        $this.daterangepicker(options, cb);
        this.uiadmin.daterangepicker = $this.data('daterangepicker');
        cb(start, end);
      });
    },

    enableDatePicker: function() {
      var el = $('.datepicker');
      if( !el.length ) return;
      var defaults = {
      };
      el.each(function(){
        var $this = $(this),
            options = $this.data('plugin-options');

        if( this.uiadmin === undefined )
          this.uiadmin = {};

        if( options === undefined ) options = {};
        options = $.extend({}, defaults, options);
        $this.datepicker(options);
        this.uiadmin.datepicker = $this.data('datepicker');
      });
    },

    enableSelect2: function() {
      var el = $('[data-toggle="select2"]');
      if(!el.length) return;
      el.each( function() {
        var $this = $(this),
            options = $this.data('plugin-options');

        if( this.uiadmin === undefined )
          this.uiadmin = {};

        $this.select2(options);
        this.uiadmin.select2 = $this.data('select2');
      });
    },

    enableMultiSelect: function() {
      var el = $('[data-toggle="multiselect"]');
      if(!el.length) return;
      this.enableMultiSelectBtns();
      el.each(function() {
        var $this = $(this);
        if( this.uiadmin === undefined )
          this.uiadmin = {};
        this.uiadmin.multiselect = $this.multiSelect();
      });
    },

    enableMultiSelectBtns: function() {
      var el = $('[data-multiselect-target]');
      if(!el.length) return;
      el.each(function() {
        var $this = $(this),
            $targetData = $this.data('multiselect-target'),
            $method = $this.data('multiselect-method'),
            $event = $this.data('event');

        var $target = $( $targetData );
        $this.on( $event, function(e) {
          e.preventDefault();

          switch ( $method ) {
            case "addOption":
              $target.multiSelect( 'addOption', { value: 'test', text: 'test', index: 0, nested: 'optgroup_label' });
              break;
            default:
              $target.multiSelect( $method );
          }
        });
      });
    },

    
  };

  document.addEventListener('DOMContentLoaded', function() {
    Pace.options = {
      ajax: {
        ignoreURLs: [
          'assets/vendors/theme-widgets/getTwitterFeed', 
          'assets/vendors/theme-widgets/getFacebookFeed'
        ],
      }
    }
    uiadmin.init();
    uiadmin.setMenu();
  });

  window.addEventListener('resize', uiadmin.setMenu);
  window.addEventListener('resize', uiadmin.contentHeight);
})(jQuery);
