﻿using System;
using System.Collections.Generic;

namespace DisCom.Models
{
    public partial class TbRole
    {
        public int Id { get; set; }
        public string Role { get; set; }
        public int? ReportingRole { get; set; }
        public long CrtBy { get; set; }
        public DateTime CrtDt { get; set; }
        public long? UpdBy { get; set; }
        public DateTime? UpdDt { get; set; }
        public byte? IsActive { get; set; }
    }
}
