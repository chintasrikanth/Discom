﻿

myApp.controller('LayoutAppCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, ridirectPath) {

    $scope.RoleId = $sessionStorage.RoleId;
    $scope.UsrId = $sessionStorage.UsrId;
    $scope.UserName = $sessionStorage.UserName;
    $scope.Role = $sessionStorage.Role;

    myApp.config(['$locationProvider', function ($locationProvider) {
        // for enabling html5 mod  
        $locationProvider.html5Mode(true);
    }]);

    if ($sessionStorage.user == null) {
        $window.location.href = ridirectPath;
    }
   
    $scope.logOut = function () {
        $sessionStorage.user = null;
        $window.location.href = ridirectPath;            
    };


}]);
