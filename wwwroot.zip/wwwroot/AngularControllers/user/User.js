﻿
myApp.controller('UserCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.numPerPageList = [{ 'name': "5", "value": 5 }, { 'name': "10", "value": 10 }, { 'name': "20", "value": 20 }];
    $scope.sortBy = 'CreatedOn';
    $scope.reverse = true;
    $scope.numPerPage = 5;

    $scope.sort = function (keyname) {
        $scope.sortBy = keyname;   //set the sortBy to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    $scope.getSortClass = function (column) {
        if ($scope.sortBy === column) {
            return $scope.reverse ? 'feather feather-arrow-down' : 'feather feather-arrow-up';
        }
    };

    $scope.UserList = null;
    $scope.RoleList = null;
    $scope.Circle = false;
    $scope.Division = false;
    $scope.SubDivion = false;
    $scope.SubStation = false;
    $scope.Feeder = false;
    $scope.Dtr = false;
    $scope.ReportingMgr = false;   

    $scope.StatusList = [{ 'name': "Active", 'value': 1 }, { 'name': "IN-Active", 'value': 0 }];

    $scope.dLoadDisabled = true;
    $scope.GetUsers = function () {
        $http.get(serviceBasePath + "user/GetUsers").then(function success(response) {
            if (response.data.Status === true) {
                $scope.UserList = response.data.Result;
                $scope.dLoadDisabled = false;
            }
        }, function error() {

        });
    };

    $scope.DownloadExcel = function () { // ex: '#my-table'
        $scope.dLoadDisabled = true;

        var row = $scope.UserList;
        var Head = [[
            //'Discom',
            //'Circlename',
            //'Divisionname',
            //'Subdivisionname',
            //'Substationname',
            //'SubstationCode',
            //'Town Name',
            //'Feedername',
            //'Feedercode',
            //'Dtrname',
            //'Dtrcode',

            'UserName',
            'Email',
            'Mobile',
            'Role',
            'Reporting Manager',
            'Status',
        ]];

        for (var item = 0; item < row.length; ++item) {

            Head.push([
                //row[item].Discom.replace(/,/g, '"'),
                //row[item].Circle.replace(/,/g, '"'),
                //row[item].Division.replace(/,/g, '"'),
                //row[item].SubDivision.replace(/,/g, '"'),
                //row[item].SubStation.replace(/,/g, '"'),
                //row[item].SubStationCode.replace(/,/g, '"'),
                //row[item].TownName.replace(/,/g, '"'),
                //row[item].FeederName.replace(/,/g, '"'),
                //row[item].FeederCode.replace(/,/g, '"'),
                //row[item].DtrName.replace(/,/g, '"'),
                //row[item].DtrCode.replace(/,/g, '"'),

                row[item].UserName.replace(/,/g, '"'),
                row[item].Email,
                row[item].Mobile,
                row[item].Role,
                row[item].ReportingManagerName,
                row[item].StatusDisp,
            ]);
        }

        var csvRows = [];
        for (var cell = 0; cell < Head.length; ++cell) {
            csvRows.push(Head[cell].join(','));
        }

        var csvString = csvRows.join("\n");
        let csvFile = new Blob([csvString], { type: "text/csv" });
        let downloadLink = document.createElement("a");

        downloadLink.download = 'UserList.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = "none";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        $scope.dLoadDisabled = false;
    } 

    $scope.GetActiveRoles = function () {
        $http.get(serviceBasePath + "user/GetActiveRoles").then(function success(response) {
            if (response.data.Status === true) {
                $scope.RoleList = response.data.Result;
            }
        }, function error() {

        });
    };

    //$scope.GetDiscom = function () {

    //    $scope.CircleList = null;

    //    $http.get(serviceBasePath + "Circle/GetDiscom").then(function success(response) {

    //        if (response.data.Status === true) {
    //            $scope.DiscomList = response.data.Result;
    //        }

    //    }, function error() {

    //    });
    //};
    
    $scope.ResetForm = function () {

        $scope.UserForm.$setPristine();
        $scope.UserForm.$setUntouched();

        $scope.UModel = { UserName: "", Email: "", Mobile: "", RoleId: "", CircleId: "", DivisionId: "", SubDivionId: "", SubStationId: "", FeederCodeList: "", DtrCodeList: "", ReportingManager: "", IsActive: "" };
    };

    $scope.RoleChange = function (RoleId) {
      
        $scope.UserForm.$setPristine();
        $scope.UserForm.$setUntouched();

        switch (RoleId) {
            case 1:
            case 5:
            case 6:
            case 15: case 18:
            
                $scope.UModel.CircleId = "";
                $scope.UModel.DivisionId = "";
                $scope.UModel.SubDivionId = "";
                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = false;
                $scope.Division = false;
                $scope.SubDivion = false;
                $scope.SubStation = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;

                break;

            case 2: case 17:

                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.DivisionId = "";
                $scope.UModel.SubDivionId = "";
                $scope.SubStation = false;
                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = false;
                $scope.SubDivion = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;

                break;

            case 3:

                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.SubDivionId = "";
                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = true;
                $scope.SubDivion = false;
                $scope.SubStation = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;

                break;


            case 4:
                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = true;
                $scope.SubDivion = true;
                $scope.SubStation = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;

                break;

            case 7:

                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = true;
                $scope.SubDivion = true;
                $scope.SubStation = true;
                $scope.Feeder = true;
                $scope.Dtr = true;
                $scope.ReportingMgr = false;

                break;


            case 8:

                //$scope.GetCircles();
                $scope.GetDiscom();               

                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = true;
                $scope.SubDivion = true;
                $scope.SubStation = true;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = true;

                break;


            case 13:

                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = false;
                $scope.Division = false;
                $scope.SubDivion = false;
                $scope.SubStation = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;
                break;

            case 14:

                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = true;
                $scope.SubDivion = true;
                $scope.SubStation = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;
                break;

            case 16:

                //$scope.GetCircles();
                $scope.GetDiscom();

                $scope.UModel.CircleId = "";
                $scope.UModel.DivisionId = "";
                $scope.UModel.SubDivionId = "";
                $scope.SubStation = false;
                $scope.UModel.FeederCode = "";
                $scope.UModel.DtrCodeList = "";
                $scope.UModel.ReportingManager = "";

                $scope.Circle = true;
                $scope.Division = false;
                $scope.SubDivion = false;
                $scope.Feeder = false;
                $scope.Dtr = false;
                $scope.ReportingMgr = false;

                break;

          

            default:

        }
    };    
    
    $scope.InitEdit = function (Id) {

        $window.open(ridirectPath + '/User/Edit/' + Id, "_self");
    };

    $scope.CreateUser = function () {
        $scope.UserForm.$submitted = true;
        if ($scope.UserForm.$valid) {

            $http.post(serviceBasePath + "user/CreateUser", $scope.UModel).then(function success(response) {

                if (response.data.Status == false) {

                    swal({ title: "", text: response.data.Messege, type: "error" },
                        function () {
                            return false;
                        }
                    );

                } else {
                    swal({ title: "", text: response.data.Messege, type: "success" },
                        function () {
                            $window.location.href = ridirectPath + '/user/index';
                        }
                    );
                }

            }, function error() {

            });
        }
    };
        
    $scope.GetUsers();

    $scope.GetActiveRoles();     

}]);