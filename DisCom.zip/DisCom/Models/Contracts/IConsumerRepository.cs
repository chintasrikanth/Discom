﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models.ViewModels;

namespace DisCom.Models.Contracts
{
    public interface IConsumerRepository
    {
        ResponseModel GetConsumers(int numPerPage, int pageNum, string searchString, int uId, int roleId, int consType);

        ResponseModel GetConsumerList(int roleId);

        ResponseModel GetConsumersByStatOffLine(ConsumerListModelParam Filterpamrams);

        ResponseModel UpdateConsumerData(ConsumerDataModel consumer, int UsrId);

        ResponseModel CnsmrOldNewMtrDetailsByCnsmr(int Id);

        //ResponseModel ConsumerUpdateUpload(UploadConsumerUpdateModelTest MasterList, int CreatedBy);

    }
}
