﻿
myApp.controller('ConsumerUpdateExcelCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', '$timeout', 'Excel', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath, $timeout, Excel) {

    //$scope.numPerPageList = [{ 'name': "5", "value": 5 }, { 'name': "10", "value": 10 }, { 'name': "20", "value": 20 }];
    //$scope.sortBy = 'ConsumerName';
    //$scope.reverse = true;
    //$scope.numPerPage = 10;
    //$scope.pageNum = 1;
    //$scope.totalCount = 0;
    //$scope.logResultyes = "";
    //$scope.Details = "";
    //$scope.disCIbtn = false;
    //$scope.searchString = "";

    //$scope.sort = function (keyname) {
    //    $scope.sortBy = keyname;   //set the sortBy to the param passed
    //    $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    //};

    //$scope.getSortClass = function (column) {
    //    if ($scope.sortBy === column) {
    //        return $scope.reverse ? 'feather feather-arrow-down' : 'feather feather-arrow-up';
    //    }
    //};


  
    $scope.msg = "";
    $scope.loadFile = function (files) {

        $scope.$apply(function () {

            $scope.selectedFile = files[0];

        });

    };    

    $scope.ImportCDUpdateFile = function () {

        var file = $scope.selectedFile;

        if (file) {

            var reader = new FileReader();

            reader.onload = function (e) {

                var data = e.target.result;

                var workbook = XLSX.read(data, { type: 'binary' });

                var first_sheet_name = workbook.SheetNames[0];

                var headerNames = XLSX.utils.sheet_to_json(workbook.Sheets[first_sheet_name], { header: 1 })[0];

                var hdr = headerNames[1];

                var dataObjects = XLSX.utils.sheet_to_json(workbook.Sheets[first_sheet_name]);

                //console.log(excelData);  

                if (dataObjects.length > 0) {

                    $scope.UpdateCUploadData(dataObjects, hdr);

                } else {

                    swal("There is No Data in Excel!");
                }

            };

            reader.onerror = function (ex) {

            };

            reader.readAsBinaryString(file);
        } else {

            swal("Please select file.");
        }
    };

    $scope.UpdateCUploadData = function (data, hdr) {
        $scope.dLoadDisabled = true;
        Pace.restart();
        //$scope.logResultyes = "Yes";
        //var resBody = { "data": data, "columnName": hdr };
        var resBody = { "UploadConsumerUpdate": data, "columnName": hdr };

        $http.post(serviceBasePath + 'Consumer/ConsumerUpdateUpload', resBody).then(function (response) {

            if (response.data.Status == false) {

                swal({ title: "", text: response.data.Messege, type: "error" },
                    function () {
                        $window.location.href = ridirectPath + '/Consumer/ConsumerUpdateExcel';

                    }
                );

            } else {
                swal({ title: "", text: response.data.Messege, type: "success" },
                    function () {
                        $window.location.href = ridirectPath + '/Consumer/ConsumerUpdateExcel';

                    }
                );
            }


        }, function (error) {
            $scope.dLoadDisabled = false;
            swal({ title: "", text: "Something went wrong!.", type: "error" },
                function () {
                    return false;
                }
            );
        });
    };

    $scope.GetUploadLogs = function () {

        $http.get(serviceBasePath + "Consumer/GetUploadLogs").then(function success(response) {
            if (response.data.Status == true) {
                $scope.logResult = response.data.Result;
            }
            if (response.data.Status == false) {
                $scope.logResult = response.data.Result;
            }
        }, function error() {
        });
    };
    $scope.GetUploadLogs();

    $scope.GetUploadLogs_CI = function () {

        $http.get(serviceBasePath + "Consumer/GetUploadLogs_CDUpate").then(function success(response) {
            if (response.data.Status == true) {
                $scope.logResultCI = response.data.Result;
            }
            if (response.data.Status == false) {
                $scope.logResultCI = response.data.Result;
            }
        }, function error() {
        });
    };

    $scope.GetUploadLogs_CI();


    $scope.DownloadExcel = function (tableId) { // ex: '#my-table'

        var exportHref;

        if (tableId === '#MasterDataLogsTable') {
            //if (!$scope.leadList) {
            //    alert("No data to export to excel.");
            //} else if ($scope.leadList.length === 0) {
            //    alert("No data to export to excel.");
            //} else {
            exportHref = Excel.tableToExcel(tableId, 'Reports');
            $timeout(function () { location.href = exportHref; }, 100); // trigger download
            //}
        }

    }
    $scope.DownloadFormatedExcel = function (tableId) { // ex: '#my-table'
        var exportHref;
        if (tableId === '#MasterDataFormatedTable') {
            exportHref = Excel.tableToExcel(tableId, 'Reports');
            $timeout(function () { location.href = exportHref; }, 100); // trigger download            
        }
    }


}]);