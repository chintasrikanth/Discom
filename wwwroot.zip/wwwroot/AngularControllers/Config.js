﻿/* Local Dev Env*/
//myApp.constant('serviceBasePath', 'http://localhost:60487/api/');
//myApp.constant('ridirectPath', '');

/* QA Server Dev Env*/
myApp.constant('serviceBasePath', 'http://appnet.karvyclick.com/discom/api/');
myApp.constant('ridirectPath', 'smartmeter');

/* QA Server Dev Env*/
//myApp.constant('serviceBasePath', 'https://192.168.83.11/discom/api/');
//myApp.constant('ridirectPath', 'smartmeter');

/* QA Server Dev Env*/
//myApp.constant('serviceBasePath', 'http://srv-ecommiis1/DisCom/api/');
//myApp.constant('ridirectPath', 'smartmeter');

/* Azure UAT Server Env*/
//myApp.constant('serviceBasePath', 'http://40.81.73.132/SmartMeterAPI/api/');
//myApp.constant('ridirectPath', '');

/* Azure Dev Server Env*/
//myApp.constant('serviceBasePath', 'https://devkarvy.smart-energymeters.co.in/Discom/api/');
//myApp.constant('ridirectPath', '');

/* Azure UAT Test Server Env*/
//myApp.constant('serviceBasePath', 'https://testkarvy.smart-energymeters.co.in/Discom/api/');
//myApp.constant('ridirectPath', '');

/* Azure PreProduction Server Env*/
//myApp.constant('serviceBasePath', 'https://karvy-preprod.smart-energymeters.co.in/Discom/api/');
//myApp.constant('ridirectPath', '');

/* Azure Production Server Env*/
//myApp.constant('serviceBasePath', 'https://karvy.smart-energymeters.co.in/Discom/api/');
//myApp.constant('ridirectPath', '');