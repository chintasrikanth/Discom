﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models;
using DisCom.Models.ViewModels;

namespace DisCom.Models.Contracts
{
   public interface IUserRepository
    {
        ResponseModel GetUsers(int Id,int RoleId);

        TbUserModel GetUser(TbUserModel user);

        ResponseModel GetUserById(int Id);


        ResponseModel SendOtpForSetPwd(SetPasswordModel user);

        ResponseModel ResetPwd(ResetPasswordModel user);

        ResponseModel CreateUser(TbUserModel user);

        ResponseModel UpdateUser(TbUserModel user);

        ResponseModel GetReportingManegers(int RoleId,int SubStationId);       

    }
}
