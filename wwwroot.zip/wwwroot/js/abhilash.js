abhilash = {}

abhilash.init = function(){
	this.initHandler()
}

abhilash.initHandler  = function(){
	$('.current-page').on('click', function(){
		alert()
	})
}