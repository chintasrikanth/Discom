﻿
myApp.controller('ConsumerDetailsCtr', ['$scope', '$http', '$window', '$sessionStorage', 'userService', '$rootScope', 'serviceBasePath', 'ridirectPath', function ($scope, $http, $window, $sessionStorage, userService, $rootScope, serviceBasePath, ridirectPath) {

    $scope.RoleId = $sessionStorage.RoleId;

    $scope.Id = "";

    $scope.init = function (Id) {

        $scope.Id = Id; 

        $scope.CnsmrOldNewMtrDetailsByCnsmr = function (Id) {
            $http.get(serviceBasePath + "Consumer/CnsmrOldNewMtrDetailsByCnsmr/" + Id).then(function success(response) {
                $scope.CnsmrOldNewMtrDetails = response.data.Result;

                /* Oldmeter Image Section*/
                $(".NewMeterImage li").attr('data-src', $scope.CnsmrOldNewMtrDetails.ConsumerObj.NewMeterImage);
                $(".Latest_Ele_BillImage li").attr('data-src', $scope.CnsmrOldNewMtrDetails.ConsumerObj.Latest_Ele_BillImage);

            }, function error() {

            });
        };

        $scope.CnsmrOldNewMtrDetailsByCnsmr($scope.Id);
    };

    $scope.goBack = function () {
        $window.history.back(-1);
        //$route.reload();
    };

    /* Image View Code */

    $scope.MeterImage = "";
    $scope.MeterImageView = function (MeterImage) {

        console.log(MeterImage);

        $scope.MeterImage = MeterImage;
        $("#MeterImage").modal("show");
    };

    $scope.MeterImageClose = function () {

        $scope.MeterImage = "";
        $("#MeterImage").modal("hide");
    };

    /* Image View Code Ends */

}]);