﻿using System;
using System.Collections.Generic;

namespace DisCom.Models
{
    public partial class TbConsumerVisit
    {
        public int Id { get; set; }
        public string ConsumerNumber { get; set; }
        public string Remarks { get; set; }
        public DateTime? CrtDt { get; set; }
        public int? CrtBy { get; set; }
    }
}
