﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DisCom.Models
{
    public partial class DiscomContext : DbContext
    {
        public DiscomContext()
        {
        }

        public DiscomContext(DbContextOptions<DiscomContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TbBoxdetails> TbBoxdetails { get; set; }
        public virtual DbSet<TbCircle> TbCircle { get; set; }
        public virtual DbSet<TbConsumerUpdateHistory> TbConsumerUpdateHistory { get; set; }
        public virtual DbSet<TbConsumerVisit> TbConsumerVisit { get; set; }
        public virtual DbSet<TbConsumers> TbConsumers { get; set; }
        public virtual DbSet<TbDemandSupply> TbDemandSupply { get; set; }
        public virtual DbSet<TbDiscom> TbDiscom { get; set; }
        public virtual DbSet<TbDivision> TbDivision { get; set; }
        public virtual DbSet<TbDtr> TbDtr { get; set; }
        public virtual DbSet<TbErrorcodes> TbErrorcodes { get; set; }
        public virtual DbSet<TbExcelciuploadlog> TbExcelciuploadlog { get; set; }
        public virtual DbSet<TbExcelciuploadlogEesl> TbExcelciuploadlogEesl { get; set; }
        public virtual DbSet<TbExcelconsumerupdatelog> TbExcelconsumerupdatelog { get; set; }
        public virtual DbSet<TbExcelmiuploadlog> TbExcelmiuploadlog { get; set; }
        public virtual DbSet<TbExcelnewmeteruploadlog> TbExcelnewmeteruploadlog { get; set; }
        public virtual DbSet<TbExceluploadlog> TbExceluploadlog { get; set; }
        public virtual DbSet<TbFeeder> TbFeeder { get; set; }
        public virtual DbSet<TbFielddevice> TbFielddevice { get; set; }
        public virtual DbSet<TbLastlogin> TbLastlogin { get; set; }
        public virtual DbSet<TbMakeMfr> TbMakeMfr { get; set; }
        public virtual DbSet<TbManpowerDeployment> TbManpowerDeployment { get; set; }
        public virtual DbSet<TbMcostatus> TbMcostatus { get; set; }
        public virtual DbSet<TbNewmeter> TbNewmeter { get; set; }
        public virtual DbSet<TbNewmeterFaultyStaus> TbNewmeterFaultyStaus { get; set; }
        public virtual DbSet<TbNewmeterImageUpdate> TbNewmeterImageUpdate { get; set; }
        public virtual DbSet<TbNewmeterInstallHistory> TbNewmeterInstallHistory { get; set; }
        public virtual DbSet<TbNewmeterOutward> TbNewmeterOutward { get; set; }
        public virtual DbSet<TbNewmeterinwardBoxdetails> TbNewmeterinwardBoxdetails { get; set; }
        public virtual DbSet<TbNewmeterinwardTemp> TbNewmeterinwardTemp { get; set; }
        public virtual DbSet<TbNewmeteroutwardMeterrepo> TbNewmeteroutwardMeterrepo { get; set; }
        public virtual DbSet<TbNewmeteroutwardMeterrepoTemp> TbNewmeteroutwardMeterrepoTemp { get; set; }
        public virtual DbSet<TbOldmeters> TbOldmeters { get; set; }
        public virtual DbSet<TbPole> TbPole { get; set; }
        public virtual DbSet<TbQcAroMovement> TbQcAroMovement { get; set; }
        public virtual DbSet<TbQcHistory> TbQcHistory { get; set; }
        public virtual DbSet<TbRejectionRemarks> TbRejectionRemarks { get; set; }
        public virtual DbSet<TbRejectionRemarksMi> TbRejectionRemarksMi { get; set; }
        public virtual DbSet<TbRole> TbRole { get; set; }
        public virtual DbSet<TbSubdivision> TbSubdivision { get; set; }
        public virtual DbSet<TbSubstation> TbSubstation { get; set; }
        public virtual DbSet<TbUser> TbUser { get; set; }
        public virtual DbSet<TbWarehouse> TbWarehouse { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySQL("server=localhost;Database=Discomkarvy;user id=username;password=password;");
                //optionsBuilder.UseMySQL("server=192.168.83.57;Database=Discom;user id=username;password=password;");
                //Dev
                //optionsBuilder.UseMySQL("server=eesl-dev-south-karvy-mysql-01.mysql.database.azure.com;Database=discom;user id=mysqlkarvyadmin@eesl-dev-south-karvy-mysql-01;password=H>mxynOj3E<{[GU;");
                //Test
                //optionsBuilder.UseMySQL("server=eesl-test-dc-karvy-mysqlsvr-01.mysql.database.azure.com;Database=discom;user id=adminkarvymysql@eesl-test-dc-karvy-mysqlsvr-01;password=56K4irH`nZjnc.+;");
                //PP
                //optionsBuilder.UseMySQL("server=eesl-preproduction-dc-wfm-mysql-01.mysql.database.azure.com;Database=Discom;user id=wfmmysqladmin@eesl-preproduction-dc-wfm-mysql-01;password=Ns:@@5V|LIS@mo;");
                //optionsBuilder.UseMySQL("server=eesl-preproduction-dr-wfm-mysql-01.mysql.database.azure.com;Database=Discom;user id=wfmmysqladmin@eesl-preproduction-dr-wfm-mysql-01;password=Ns:@@5V|LIS@mo;");
                //Production
                //optionsBuilder.UseMySQL("server=eesl-production-dc-wfm-mysql-01.mysql.database.azure.com;Database=Discom;user id=wfmmysqlprod@eesl-production-dc-wfm-mysql-01;password=B^7$?Vf=`>!*Su*G;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<TbBoxdetails>(entity =>
            {
                entity.ToTable("tb_boxdetails", "discom");

                entity.Property(e => e.BoxBarCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CircleId).HasColumnName("Circle_Id");

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.CreatedBy).HasColumnName("Created_By");

                entity.Property(e => e.ForceCloseReason)
                    .HasColumnName("Force_Close_Reason")
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .HasColumnName("Is_Active")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.IsDispatched).HasDefaultValueSql("0");

                entity.Property(e => e.MeterCount).HasColumnName("Meter_Count");

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");

                entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");

                entity.Property(e => e.WhId).HasColumnName("Wh_Id");
            });

            modelBuilder.Entity<TbCircle>(entity =>
            {
                entity.ToTable("tb_circle", "discom");

                entity.Property(e => e.DiscomId).HasDefaultValueSql("0");

                entity.Property(e => e.TownName)
                    .IsRequired()
                    .HasColumnName("Town_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbConsumerUpdateHistory>(entity =>
            {
                entity.ToTable("tb_consumer_update_history", "discom");

                entity.Property(e => e.ConsumerBillingType)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.CreatedBy).HasColumnName("Created_By");

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterManufacturer)
                    .HasColumnName("Old_MeterManufacturer")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterNumber)
                    .HasColumnName("Old_MeterNumber")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterReading)
                    .HasColumnName("Old_Meter_Reading")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Phase)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");

                entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");
            });

            modelBuilder.Entity<TbConsumerVisit>(entity =>
            {
                entity.ToTable("tb_consumer_visit", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks)
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbConsumers>(entity =>
            {
                entity.ToTable("tb_consumers", "discom");

                entity.HasIndex(e => e.ConsumerNumber)
                    .HasName("ind_CNo")
                    .IsUnique();

                entity.HasIndex(e => e.IsIndexed)
                    .HasName("ind_IsIndexed");

                entity.HasIndex(e => new { e.IsIndexed, e.DtrCode })
                    .HasName("ind_consuner_Index_DTRCode");

                entity.HasIndex(e => new { e.Id, e.IsIndexed, e.DtrCode })
                    .HasName("ind_consuner_Index_DTRCode_KNo");

                entity.Property(e => e.Address)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ApprovalStatus)
                    .HasColumnName("approval_status")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.AroDoneBy).HasColumnName("aroDoneBy");

                entity.Property(e => e.AroDoneDate).HasColumnName("aroDoneDate");

                entity.Property(e => e.AroRejBy).HasColumnName("aroRejBy");

                entity.Property(e => e.AroRejDate).HasColumnName("aroRejDate");

                entity.Property(e => e.AroRemarksId).HasColumnName("aroRemarksId");

                entity.Property(e => e.Category)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CategoryCode)
                    .HasColumnName("Category_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CircleId).HasColumnName("Circle_Id");

                entity.Property(e => e.ConnectedLoad)
                    .HasColumnName("Connected_Load")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerArea)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerBillingType)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerName)
                    .IsRequired()
                    .HasColumnName("Consumer_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerTownName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerType)
                    .HasColumnName("Consumer_Type")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerType1)
                    .HasColumnName("ConsumerType")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ContractedLoad)
                    .HasColumnName("Contracted_Load")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.DiscomId).HasColumnName("Discom_Id");

                entity.Property(e => e.DivisionId).HasColumnName("Division_Id");

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EeslApproval)
                    .HasColumnName("eeslApproval")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.EeslDoneBy).HasColumnName("eeslDoneBy");

                entity.Property(e => e.EeslDoneDate).HasColumnName("eeslDoneDate");

                entity.Property(e => e.EeslRejBy).HasColumnName("eeslRejBy");

                entity.Property(e => e.EeslRejDate).HasColumnName("eeslRejDate");

                entity.Property(e => e.EeslRemarksId).HasColumnName("eeslRemarksId");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.IdProofImage)
                    .HasColumnName("idProofImage")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.IndexedDate).HasColumnName("indexedDate");

                entity.Property(e => e.IndexedDoneBy)
                    .HasColumnName("indexedDoneBy")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.InstallDoneBy)
                    .HasColumnName("installDoneBy")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.InstalledDate).HasColumnName("installedDate");

                entity.Property(e => e.IsIndexed)
                    .HasColumnName("isIndexed")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.LoadUnit)
                    .HasColumnName("Load_Unit")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Mcostatus)
                    .HasColumnName("mcostatus")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MeterImage)
                    .HasColumnName("meterImage")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.MeterImage1)
                    .HasColumnName("meterImage1")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .HasColumnName("Mobile_Number")
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.NetworkProvider)
                    .HasColumnName("networkProvider")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.QcApproval)
                    .HasColumnName("qcApproval")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.QcDoneBy).HasColumnName("qcDoneBy");

                entity.Property(e => e.QcDoneDate).HasColumnName("qcDoneDate");

                entity.Property(e => e.QcRejBy).HasColumnName("qcRejBy");

                entity.Property(e => e.QcRejDate).HasColumnName("qcRejDate");

                entity.Property(e => e.QcRemarksId).HasColumnName("qcRemarksId");

                entity.Property(e => e.Remarks)
                    .HasColumnName("remarks")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.SignalCategory)
                    .HasColumnName("signalCategory")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.SignalLevel).HasColumnName("signalLevel");

                entity.Property(e => e.SignalStrength)
                    .HasColumnName("signalStrength")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SubDivisionId).HasColumnName("SubDivision_Id");

                entity.Property(e => e.SuperQc)
                    .HasColumnName("superQC")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.SupplyReleaseDate).HasColumnName("Supply_Release_Date");
            });

            modelBuilder.Entity<TbDemandSupply>(entity =>
            {
                entity.ToTable("tb_demand_supply", "discom");

                entity.Property(e => e.CrtDate).HasColumnName("Crt_Date");

                entity.Property(e => e.Demand1p).HasColumnName("Demand_1P");

                entity.Property(e => e.Demand3p).HasColumnName("Demand_3P");

                entity.Property(e => e.DemandLtct).HasColumnName("Demand_LTCT");

                entity.Property(e => e.DiscomId).HasDefaultValueSql("0");

                entity.Property(e => e.Month)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbDiscom>(entity =>
            {
                entity.ToTable("tb_discom", "discom");

                entity.Property(e => e.DiscomName)
                    .IsRequired()
                    .HasColumnName("Discom_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbDivision>(entity =>
            {
                entity.ToTable("tb_division", "discom");

                entity.HasIndex(e => e.CircleId)
                    .HasName("Circle_Id");

                entity.HasIndex(e => new { e.OfficeName, e.CircleId })
                    .HasName("ind_DivCir");

                entity.Property(e => e.CircleId).HasColumnName("Circle_Id");

                entity.Property(e => e.OfficeName)
                    .IsRequired()
                    .HasColumnName("Office_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Circle)
                    .WithMany(p => p.TbDivision)
                    .HasForeignKey(d => d.CircleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("tb_division_ibfk_1");
            });

            modelBuilder.Entity<TbDtr>(entity =>
            {
                entity.ToTable("tb_dtr", "discom");

                entity.HasIndex(e => e.DtrCode)
                    .HasName("ind_DCode");

                entity.Property(e => e.DtrCode)
                    .IsRequired()
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtrName)
                    .IsRequired()
                    .HasColumnName("Dtr_Name")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .IsRequired()
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbErrorcodes>(entity =>
            {
                entity.HasKey(e => e.ErrorCode);

                entity.ToTable("tb_errorcodes", "discom");

                entity.Property(e => e.ErrorCode)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.ErrorDesc)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbExcelciuploadlog>(entity =>
            {
                entity.ToTable("tb_excelciuploadlog", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);
            });

            modelBuilder.Entity<TbExcelciuploadlogEesl>(entity =>
            {
                entity.ToTable("tb_excelciuploadlog_eesl", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);
            });

            modelBuilder.Entity<TbExcelconsumerupdatelog>(entity =>
            {
                entity.ToTable("tb_excelconsumerupdatelog", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);
            });

            modelBuilder.Entity<TbExcelmiuploadlog>(entity =>
            {
                entity.ToTable("tb_excelmiuploadlog", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);
            });

            modelBuilder.Entity<TbExcelnewmeteruploadlog>(entity =>
            {
                entity.ToTable("tb_excelnewmeteruploadlog", "discom");

                entity.Property(e => e.AccuracyClass)
                    .HasColumnName("Accuracy_Class")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmpRating)
                    .HasColumnName("AMP_Rating")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BlockSupplyType)
                    .HasColumnName("Block_Supply_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.BodySealNo)
                    .HasColumnName("Body_Seal_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DenominatorMf)
                    .HasColumnName("Denominator_MF")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FinancialYear)
                    .HasColumnName("Financial_Year")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Imeino).IsUnicode(false);

                entity.Property(e => e.IpAddress).IsUnicode(false);

                entity.Property(e => e.MeterMakeId)
                    .HasColumnName("Meter_Make_ID")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeterStatusCode)
                    .HasColumnName("Meter_Status_Code")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeterType)
                    .HasColumnName("Meter_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeteringVoltageId)
                    .HasColumnName("Metering_Voltage_ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNo).IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKva)
                    .HasColumnName("NewMeter_Current_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKvah)
                    .HasColumnName("NewMeter_Current_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKwh)
                    .HasColumnName("NewMeter_Current_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentReadingDate).HasColumnName("NewMeter_Current_Reading_Date");

                entity.Property(e => e.NewMeterInstallationDate).IsUnicode(false);

                entity.Property(e => e.NewMeterManufacturer).IsUnicode(false);

                entity.Property(e => e.NewMeterMf)
                    .HasColumnName("NewMeter_MF")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNetCons)
                    .HasColumnName("NewMeter_Net_CONS")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNetMdi)
                    .HasColumnName("NewMeter_Net_MDI")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNumber).IsUnicode(false);

                entity.Property(e => e.NewMeterPf)
                    .HasColumnName("NewMeter_PF")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPhase).IsUnicode(false);

                entity.Property(e => e.NewMeterPrevReadingDate).HasColumnName("NewMeter_Prev_Reading_Date");

                entity.Property(e => e.NewMeterPreviousKva)
                    .HasColumnName("NewMeter_Previous_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPreviousKvah)
                    .HasColumnName("NewMeter_Previous_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPreviousKwh)
                    .HasColumnName("NewMeter_Previous_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterReading).IsUnicode(false);

                entity.Property(e => e.NoDigits)
                    .HasColumnName("No_Digits")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumeratorMf)
                    .HasColumnName("Numerator_MF")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);

                entity.Property(e => e.RentCode)
                    .HasColumnName("Rent_Code")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.SimNo).IsUnicode(false);

                entity.Property(e => e.SimType).IsUnicode(false);

                entity.Property(e => e.SupplyType)
                    .HasColumnName("Supply_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.TelecomOperator).IsUnicode(false);

                entity.Property(e => e.TenderNo)
                    .HasColumnName("Tender_No")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TerminalSealNo)
                    .HasColumnName("Terminal_Seal_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TerminalSealStatus)
                    .HasColumnName("Terminal_Seal_Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfIdAddress).IsUnicode(false);

                entity.Property(e => e.VectorType)
                    .HasColumnName("Vector_Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbExceluploadlog>(entity =>
            {
                entity.ToTable("tb_exceluploadlog", "discom");

                entity.Property(e => e.AccountNo).IsUnicode(false);

                entity.Property(e => e.Address).IsUnicode(false);

                entity.Property(e => e.BinderNo).IsUnicode(false);

                entity.Property(e => e.Category).IsUnicode(false);

                entity.Property(e => e.ConsumerArea).IsUnicode(false);

                entity.Property(e => e.ConsumerBillingType).IsUnicode(false);

                entity.Property(e => e.ConsumerName)
                    .HasColumnName("Consumer_Name")
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerTownName).IsUnicode(false);

                entity.Property(e => e.ConsumerType).IsUnicode(false);

                entity.Property(e => e.ContractedLoad)
                    .HasColumnName("Contracted_Load")
                    .IsUnicode(false);

                entity.Property(e => e.CurrentKva)
                    .HasColumnName("Current_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentKvah)
                    .HasColumnName("Current_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentKwh)
                    .HasColumnName("Current_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentReadingDate).HasColumnName("Current_Reading_Date");

                entity.Property(e => e.CurrentStatus)
                    .HasColumnName("Current_Status")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DiscomName)
                    .HasColumnName("Discom_Name")
                    .IsUnicode(false);

                entity.Property(e => e.DivisionName).IsUnicode(false);

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .IsUnicode(false);

                entity.Property(e => e.DtrName)
                    .HasColumnName("Dtr_Name")
                    .IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .IsUnicode(false);

                entity.Property(e => e.FeederName)
                    .HasColumnName("Feeder_Name")
                    .IsUnicode(false);

                entity.Property(e => e.FinalizationDate).HasColumnName("Finalization_Date");

                entity.Property(e => e.Latitude).IsUnicode(false);

                entity.Property(e => e.LoadUnit)
                    .HasColumnName("Load_Unit")
                    .IsUnicode(false);

                entity.Property(e => e.Longitude).IsUnicode(false);

                entity.Property(e => e.MeterManufacturer)
                    .HasColumnName("Meter_Manufacturer")
                    .IsUnicode(false);

                entity.Property(e => e.MeterNumber)
                    .HasColumnName("Meter_Number")
                    .IsUnicode(false);

                entity.Property(e => e.MeterReading)
                    .HasColumnName("Meter_Reading")
                    .IsUnicode(false);

                entity.Property(e => e.MeterType)
                    .HasColumnName("Meter_Type")
                    .IsUnicode(false);

                entity.Property(e => e.Mf)
                    .HasColumnName("MF")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .HasColumnName("Mobile_Number")
                    .IsUnicode(false);

                entity.Property(e => e.NetCons)
                    .HasColumnName("Net_CONS")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.NetMdi)
                    .HasColumnName("Net_MDI")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.OfficeName)
                    .HasColumnName("Office_Name")
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate).HasColumnName("Order_Date");

                entity.Property(e => e.Pf)
                    .HasColumnName("PF")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.Phase).IsUnicode(false);

                entity.Property(e => e.PoleId)
                    .HasColumnName("Pole_Id")
                    .IsUnicode(false);

                entity.Property(e => e.PoleLatitude)
                    .HasColumnName("Pole_Latitude")
                    .IsUnicode(false);

                entity.Property(e => e.PoleLongitude)
                    .HasColumnName("Pole_Longitude")
                    .IsUnicode(false);

                entity.Property(e => e.PrevReadingDate).HasColumnName("Prev_Reading_Date");

                entity.Property(e => e.PreviousKva)
                    .HasColumnName("Previous_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PreviousKvah)
                    .HasColumnName("Previous_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PreviousKwh)
                    .HasColumnName("Previous_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks).IsUnicode(false);

                entity.Property(e => e.RentCode)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.StatusCode)
                    .HasColumnName("Status_Code")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.SubDivisionName)
                    .HasColumnName("SubDivision_Name")
                    .IsUnicode(false);

                entity.Property(e => e.SubStationCode)
                    .HasColumnName("SubStation_Code")
                    .IsUnicode(false);

                entity.Property(e => e.SubStationName).IsUnicode(false);

                entity.Property(e => e.TariffCode).IsUnicode(false);

                entity.Property(e => e.TownName)
                    .HasColumnName("Town_Name")
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbFeeder>(entity =>
            {
                entity.ToTable("tb_feeder", "discom");

                entity.HasIndex(e => new { e.FeederCode, e.SubStationId })
                    .HasName("ind_FCSubStn");

                entity.Property(e => e.FeederCode)
                    .IsRequired()
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FeederName)
                    .IsRequired()
                    .HasColumnName("Feeder_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SubStationId).HasColumnName("SubStation_Id");
            });

            modelBuilder.Entity<TbFielddevice>(entity =>
            {
                entity.ToTable("tb_fielddevice", "discom");

                entity.Property(e => e.ConsumerId).HasColumnName("Consumer_Id");

                entity.Property(e => e.DtrId).HasColumnName("Dtr_Id");

                entity.Property(e => e.ImeiNumber)
                    .IsRequired()
                    .HasColumnName("IMEI_Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IpAddress)
                    .IsRequired()
                    .HasColumnName("IP_Address")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .IsRequired()
                    .HasColumnName("Mobile_Number")
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SimNumber)
                    .IsRequired()
                    .HasColumnName("Sim_Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SimType)
                    .IsRequired()
                    .HasColumnName("Sim_Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TelecomeOperator)
                    .IsRequired()
                    .HasColumnName("Telecome_Operator")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfIdAddress)
                    .IsRequired()
                    .HasColumnName("TypeOf_ID_Address")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbLastlogin>(entity =>
            {
                entity.ToTable("tb_lastlogin", "discom");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbMakeMfr>(entity =>
            {
                entity.ToTable("tb_make_mfr", "discom");

                entity.HasIndex(e => e.Make)
                    .HasName("ind_make")
                    .IsUnique();

                entity.Property(e => e.CrtBy).HasColumnName("crtBy");

                entity.Property(e => e.CrtDt).HasColumnName("crtDt");

                entity.Property(e => e.Make)
                    .IsRequired()
                    .HasColumnName("make")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbManpowerDeployment>(entity =>
            {
                entity.ToTable("tb_manpower_deployment", "discom");

                entity.HasIndex(e => e.SubDivisionId)
                    .HasName("ind_SD")
                    .IsUnique();

                entity.Property(e => e.CiCount).HasColumnName("CI_Count");

                entity.Property(e => e.CrtDate).HasColumnName("Crt_Date");

                entity.Property(e => e.DeployDate).HasColumnName("Deploy_Date");

                entity.Property(e => e.MiCount).HasColumnName("MI_Count");

                entity.Property(e => e.SubDivisionId).HasColumnName("SubDivision_Id");
            });

            modelBuilder.Entity<TbMcostatus>(entity =>
            {
                entity.ToTable("tb_mcostatus", "discom");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ConsumerId)
                    .HasColumnName("Consumer_ID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorMessage)
                    .HasColumnName("errorMessage")
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.Mcodata)
                    .HasColumnName("mcodata")
                    .HasMaxLength(2000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeter>(entity =>
            {
                entity.ToTable("tb_newmeter", "discom");

                entity.HasIndex(e => e.ConsumerId)
                    .HasName("ind_ConMeter")
                    .IsUnique();

                entity.Property(e => e.AccuracyClass)
                    .HasColumnName("Accuracy_Class")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmpRating)
                    .HasColumnName("AMP_Rating")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BlockSupplyType)
                    .HasColumnName("Block_Supply_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.BodySealNo)
                    .HasColumnName("Body_Seal_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BoxBarCode).IsUnicode(false);

                entity.Property(e => e.ConsumerId).HasColumnName("Consumer_Id");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.DenominatorMf)
                    .HasColumnName("Denominator_MF")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DiscomId).HasDefaultValueSql("0");

                entity.Property(e => e.DocImage)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorCode)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FieldDeviceId)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FinancialYear)
                    .HasColumnName("Financial_Year")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Imeino)
                    .HasColumnName("IMEINo")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Ipaddress)
                    .HasColumnName("IPAddress")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive).HasDefaultValueSql("1");

                entity.Property(e => e.IsWired).HasDefaultValueSql("0");

                entity.Property(e => e.KarvyMeterSealNo)
                    .HasColumnName("karvyMeterSealNo")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.KarvyMeterSealNo2)
                    .HasColumnName("karvyMeterSealNo2")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MeterImage)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.MeterMakeId)
                    .HasColumnName("Meter_Make_ID")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeterManufacturer)
                    .HasColumnName("Meter_Manufacturer")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MeterNumber)
                    .HasColumnName("Meter_Number")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MeterReading)
                    .HasColumnName("Meter_Reading")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MeterStatusCode)
                    .HasColumnName("Meter_Status_Code")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeterType)
                    .HasColumnName("Meter_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MeterVoltageId)
                    .HasColumnName("Meter_Voltage_ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNo)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKva)
                    .HasColumnName("NewMeter_Current_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKvah)
                    .HasColumnName("NewMeter_Current_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentKwh)
                    .HasColumnName("NewMeter_Current_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterCurrentReadingDate).HasColumnName("NewMeter_Current_Reading_Date");

                entity.Property(e => e.NewMeterMf)
                    .HasColumnName("NewMeter_MF")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNetCons)
                    .HasColumnName("NewMeter_Net_CONS")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNetMdi)
                    .HasColumnName("NewMeter_Net_MDI")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPf)
                    .HasColumnName("NewMeter_PF")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPrevReadingDate).HasColumnName("NewMeter_Prev_Reading_Date");

                entity.Property(e => e.NewMeterPreviousKva)
                    .HasColumnName("NewMeter_Previous_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPreviousKvah)
                    .HasColumnName("NewMeter_Previous_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPreviousKwh)
                    .HasColumnName("NewMeter_Previous_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NoDigits)
                    .HasColumnName("No_Digits")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumeratorMf)
                    .HasColumnName("Numerator_MF")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterImage)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterReading)
                    .HasColumnName("oldMeterReading")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phase)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RentCode)
                    .HasColumnName("Rent_Code")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.SimNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SimType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SupplyType)
                    .HasColumnName("Supply_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.TelecomeOperator)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TenderNo)
                    .HasColumnName("Tender_No")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasDefaultValueSql("TN-IT-28");

                entity.Property(e => e.TerminalSealNo)
                    .HasColumnName("Terminal_Seal_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TerminalSealStatus)
                    .HasColumnName("Terminal_Seal_Status")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("YES");

                entity.Property(e => e.TypeOfIdaddress)
                    .HasColumnName("TypeOfIDAddress")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");

                entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");

                entity.Property(e => e.VectorType)
                    .HasColumnName("Vector_Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeterFaultyStaus>(entity =>
            {
                entity.ToTable("tb_newmeter_faulty_staus", "discom");

                entity.Property(e => e.IsActive).HasDefaultValueSql("1");

                entity.Property(e => e.Status)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeterImageUpdate>(entity =>
            {
                entity.ToTable("tb_newmeter_image_update", "discom");

                entity.Property(e => e.ConsumerNumber)
                    .IsRequired()
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.McoImage)
                    .HasColumnName("MCO_Image")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.NewmeterImage)
                    .HasColumnName("Newmeter_Image")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterImage)
                    .HasColumnName("OldMeter_Image")
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeterInstallHistory>(entity =>
            {
                entity.ToTable("tb_newmeter_install_history", "discom");

                entity.Property(e => e.CrtBy).HasColumnName("crtBy");

                entity.Property(e => e.CrtDate).HasColumnName("crtDate");

                entity.Property(e => e.IndexedDate).HasColumnName("indexedDate");

                entity.Property(e => e.InstalledDate).HasColumnName("installedDate");

                entity.Property(e => e.NewMeterNumber)
                    .HasColumnName("newMeterNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterNumber)
                    .HasColumnName("oldMeterNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeterOutward>(entity =>
            {
                entity.ToTable("tb_newmeter_outward", "discom");
            });

            modelBuilder.Entity<TbNewmeterinwardBoxdetails>(entity =>
            {
                entity.ToTable("tb_newmeterinward_boxdetails", "discom");

                entity.Property(e => e.BoxBarcode).IsUnicode(false);

                entity.Property(e => e.MeterManufacturer)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MeterPhase)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeterinwardTemp>(entity =>
            {
                entity.ToTable("tb_newmeterinward_temp", "discom");

                entity.Property(e => e.BoxBarCode).IsUnicode(false);

                entity.Property(e => e.MeterManufacturer)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MeterPhase)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbNewmeteroutwardMeterrepo>(entity =>
            {
                entity.ToTable("tb_newmeteroutward_meterrepo", "discom");

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.NewMeterNumber)
                    .HasColumnName("New_Meter_Number")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NewmeterOutwardId).HasColumnName("Newmeter_Outward_Id");

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");
            });

            modelBuilder.Entity<TbNewmeteroutwardMeterrepoTemp>(entity =>
            {
                entity.ToTable("tb_newmeteroutward_meterrepo_temp", "discom");

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.NewMeterNumber)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatdAt).HasColumnName("Updatd_At");
            });

            modelBuilder.Entity<TbOldmeters>(entity =>
            {
                entity.ToTable("tb_oldmeters", "discom");

                entity.HasIndex(e => e.ConsumerId)
                    .HasName("ind_CID")
                    .IsUnique();

                entity.Property(e => e.Accuracy)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BoxBarCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerId).HasColumnName("Consumer_Id");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.CurrentKva)
                    .HasColumnName("Current_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentKvah)
                    .HasColumnName("Current_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentKwh)
                    .HasColumnName("Current_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CurrentReadingDate).HasColumnName("Current_Reading_Date");

                entity.Property(e => e.CurrentStatus)
                    .HasColumnName("Current_Status")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DtrCode)
                    .IsRequired()
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExistMeterSealStatus)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FinalizationDate).HasColumnName("Finalization_Date");

                entity.Property(e => e.Latitude)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MeterLocation)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MeterManufacturer)
                    .HasColumnName("Meter_Manufacturer")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MeterNumber)
                    .HasColumnName("Meter_Number")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MeterReading)
                    .HasColumnName("Meter_Reading")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MeterType)
                    .HasColumnName("Meter_Type")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Mf)
                    .HasColumnName("MF")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NetCons)
                    .HasColumnName("Net_CONS")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.NetMdi)
                    .HasColumnName("Net_MDI")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.OldmeterBarcode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate).HasColumnName("Order_Date");

                entity.Property(e => e.Pf)
                    .HasColumnName("PF")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.Phase)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PoleId)
                    .HasColumnName("Pole_Id")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PoleLatitude)
                    .HasColumnName("Pole_Latitude")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PoleLongitude)
                    .HasColumnName("Pole_Longitude")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PrevReadingDate).HasColumnName("Prev_Reading_Date");

                entity.Property(e => e.PreviousKva)
                    .HasColumnName("Previous_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PreviousKvah)
                    .HasColumnName("Previous_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PreviousKwh)
                    .HasColumnName("Previous_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.RentCode)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.SealingStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLineStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.StatusCode)
                    .HasColumnName("Status_Code")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.StatusofServicecable)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");

                entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");
            });

            modelBuilder.Entity<TbPole>(entity =>
            {
                entity.ToTable("tb_pole", "discom");

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.IsIndexed)
                    .HasColumnName("isIndexed")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.PoleId)
                    .IsRequired()
                    .HasColumnName("Pole_Id")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PoleImage)
                    .HasColumnName("pole_image")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.PoleLatitude)
                    .IsRequired()
                    .HasColumnName("Pole_Latitude")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PoleLongitude)
                    .IsRequired()
                    .HasColumnName("Pole_Longitude")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbQcAroMovement>(entity =>
            {
                entity.ToTable("tb_qc_aro_movement", "discom");

                entity.Property(e => e.AroRejBy).HasColumnName("aroRejBy");

                entity.Property(e => e.AroRejDate).HasColumnName("aroRejDate");

                entity.Property(e => e.AroRemarksId).HasColumnName("aroRemarksId");

                entity.Property(e => e.AroVerified).HasDefaultValueSql("0");

                entity.Property(e => e.ConsumerNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.EeslRejBy).HasColumnName("eeslRejBy");

                entity.Property(e => e.EeslRejDate).HasColumnName("eeslRejDate");

                entity.Property(e => e.EeslRemarksId).HasColumnName("eeslRemarksId");

                entity.Property(e => e.EeslVerified).HasDefaultValueSql("0");

                entity.Property(e => e.QcRejBy).HasColumnName("qcRejBy");

                entity.Property(e => e.QcRejDate).HasColumnName("qcRejDate");

                entity.Property(e => e.QcRemarksId).HasColumnName("qcRemarksId");

                entity.Property(e => e.QcVerified).HasDefaultValueSql("0");

                entity.Property(e => e.SuperQc)
                    .HasColumnName("superQC")
                    .HasColumnType("tinyint(1)")
                    .HasDefaultValueSql("0");
            });

            modelBuilder.Entity<TbQcHistory>(entity =>
            {
                entity.ToTable("tb_qc_history", "discom");

                entity.Property(e => e.AroRemarksId).HasColumnName("aroRemarksId");

                entity.Property(e => e.ConsumerBillingType)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerId).HasColumnName("Consumer_Id");

                entity.Property(e => e.ConsumerNumber)
                    .HasColumnName("Consumer_Number")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnName("Created_At");

                entity.Property(e => e.CreatedBy).HasColumnName("Created_By");

                entity.Property(e => e.EeslRemarksId).HasColumnName("eeslRemarksId");

                entity.Property(e => e.NewMeterCurrentKvah)
                    .HasColumnName("NewMeter_Current_KVAH")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterPreviousKwh)
                    .HasColumnName("NewMeter_Previous_KWH")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NewMeterReading)
                    .HasColumnName("New_Meter_Reading")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NewOldMeterReading)
                    .HasColumnName("New_oldMeterReading")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterCurrentKva)
                    .HasColumnName("Old_Meter_Current_KVA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterCurrentKvah)
                    .HasColumnName("Old_Meter_Current_KVAH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterCurrentKwh)
                    .HasColumnName("Old_Meter_Current_KWH")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterManufacturer)
                    .HasColumnName("Old_Meter_Manufacturer")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterNumber)
                    .HasColumnName("Old_Meter_Number")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterPhase)
                    .HasColumnName("Old_meter_Phase")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OldMeterReading)
                    .HasColumnName("Old_Meter_Reading")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.QcRemarksId).HasColumnName("qcRemarksId");

                entity.Property(e => e.UpdateType)
                    .HasColumnName("Update_Type")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");

                entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");
            });

            modelBuilder.Entity<TbRejectionRemarks>(entity =>
            {
                entity.ToTable("tb_rejection_remarks", "discom");

                entity.Property(e => e.AroRemarks)
                    .HasColumnName("aroRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CrtBy).HasColumnName("crtBy");

                entity.Property(e => e.CrtDt).HasColumnName("crtDt");

                entity.Property(e => e.EeslRemarks)
                    .HasColumnName("eeslRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.QcRemarks)
                    .HasColumnName("qcRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbRejectionRemarksMi>(entity =>
            {
                entity.ToTable("tb_rejection_remarks_mi", "discom");

                entity.Property(e => e.AroRemarks)
                    .HasColumnName("aroRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CrtBy).HasColumnName("crtBy");

                entity.Property(e => e.CrtDt).HasColumnName("crtDt");

                entity.Property(e => e.EeslRemarks)
                    .HasColumnName("eeslRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.QcRemarks)
                    .HasColumnName("qcRemarks")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbRole>(entity =>
            {
                entity.ToTable("tb_role", "discom");

                entity.Property(e => e.Role)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbSubdivision>(entity =>
            {
                entity.ToTable("tb_subdivision", "discom");

                entity.HasIndex(e => e.DivisionId)
                    .HasName("Division_Id");

                entity.HasIndex(e => new { e.SubDivisionName, e.DivisionId })
                    .HasName("ind_SubDivDiv");

                entity.Property(e => e.DivisionId).HasColumnName("Division_Id");

                entity.Property(e => e.SubDivisionName)
                    .IsRequired()
                    .HasColumnName("SubDivision_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbSubstation>(entity =>
            {
                entity.ToTable("tb_substation", "discom");

                entity.HasIndex(e => new { e.SubStationName, e.DivisionId })
                    .HasName("ind_SubStnDiv");

                entity.Property(e => e.DivisionId).HasColumnName("Division_Id");

                entity.Property(e => e.SubStationCode)
                    .IsRequired()
                    .HasColumnName("SubStation_Code")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SubStationName)
                    .IsRequired()
                    .HasColumnName("SubStation_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbUser>(entity =>
            {
                entity.ToTable("tb_user", "discom");

                entity.Property(e => e.CircleId).HasColumnName("Circle_Id");

                entity.Property(e => e.CreatedOn).HasColumnName("Created_On");

                entity.Property(e => e.DivisionId).HasColumnName("Division_Id");

                entity.Property(e => e.DtrCode)
                    .HasColumnName("Dtr_Code")
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FeederCode)
                    .HasColumnName("Feeder_Code")
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .HasColumnName("Is_Active")
                    .HasColumnType("tinyint(1)");

                entity.Property(e => e.LastLogonTimeStamp).HasColumnName("LastLogon_TimeStamp");

                entity.Property(e => e.Logincnt).HasDefaultValueSql("0");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Otp)
                    .HasColumnName("OTP")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OtpCreatedOn).HasColumnName("OTP_CreatedOn");

                entity.Property(e => e.ReportingManager).HasColumnName("Reporting_Manager");

                entity.Property(e => e.RoleId).HasColumnName("Role_Id");

                entity.Property(e => e.SubStationId).HasColumnName("SubStation_id");

                entity.Property(e => e.UpdatedOn).HasColumnName("Updated_On");

                entity.Property(e => e.UserEnccryptedPassword)
                    .IsRequired()
                    .HasColumnName("User_Enccrypted_Password")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasColumnName("User_Name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbWarehouse>(entity =>
            {
                entity.ToTable("tb_warehouse", "discom");

                entity.Property(e => e.WhName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });
        }
    }
}
