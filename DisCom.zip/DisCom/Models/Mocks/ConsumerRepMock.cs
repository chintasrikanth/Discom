using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using DisCom.Models;
using Microsoft.Extensions.Configuration;
using System.Text;
using System.Security.Claims;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using System.IO;
using DisCom.AppConfig;
using Microsoft.Extensions.Logging;

namespace DisCom.Models.Mocks
{
    public class ConsumerRepMock : IConsumerRepository
    {
        private ICommonRepository _commonRepository;

        private IConfiguration _configuration;
        
        public ConsumerRepMock(ICommonRepository commonRepository, IConfiguration config)
        {
            _commonRepository = commonRepository;
            _configuration = config;            
        }

        public ResponseModel UpdateConsumerData(ConsumerDataModel consumer, int UsrId)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {                    
                    ResponseModel ResObj = new ResponseModel();
                    TbConsumers CnsmrObj = new TbConsumers();

                    if (consumer.ConsumerNumber != null)
                    {
                        int cnt = db.TbConsumers.Where(x => x.ConsumerNumber == consumer.ConsumerNumber).Count();
                        if (cnt > 0)
                        {
                            ResObj.Status = false;
                            ResObj.Messege = "Consumer Number Already Exist, please check!";
                            return ResObj;
                        }
                        else
                        {
                            CnsmrObj.ConsumerNumber = consumer.ConsumerNumber;
                            CnsmrObj.NewMeterNumber = consumer.NewMeter_Number;
                            CnsmrObj.OldMeterNumber = consumer.OldMeter_Number;
                            CnsmrObj.OldMeterReading = consumer.OldMeter_Reading;
                            CnsmrObj.BoxSeal1 = consumer.BoxSeal1;
                            CnsmrObj.BoxSeal2 = consumer.BoxSeal2;
                            CnsmrObj.Address = consumer.Address;
                            CnsmrObj.MobileNumber = consumer.MobileNumber;
                            CnsmrObj.Latitude = consumer.Latitude;
                            CnsmrObj.Longitude = consumer.Longitude;
                            if (consumer.InstalledDate != null)
                            {
                                CnsmrObj.InstalledDate = Convert.ToDateTime(consumer.InstalledDate);
                            }
                            consumer.NewMeterImage = consumer.newMeterImage != null ? _commonRepository.ImageUpload(consumer.newMeterImage, "Oldmeter1") : CnsmrObj.NewMeterImage;
                            consumer.Latest_Ele_BillImage = consumer.latest_Ele_BillImage != null ? _commonRepository.ImageUpload(consumer.latest_Ele_BillImage, "Oldmeter1") : CnsmrObj.LatestEleBillImage;
                            CnsmrObj.NewMeterImage = consumer.NewMeterImage == "" ? null : consumer.NewMeterImage;
                            CnsmrObj.LatestEleBillImage = consumer.Latest_Ele_BillImage == "" ? null : consumer.Latest_Ele_BillImage;
                            if (consumer.CrtDate != null)
                            {
                                CnsmrObj.CrtDate = Convert.ToDateTime(consumer.CrtDate);
                            }
                            else
                            {
                                CnsmrObj.CrtDate = DateTime.Now;
                            }
                            CnsmrObj.CrtBy = UsrId;

                            db.TbConsumers.Add(CnsmrObj);
                            db.SaveChanges();

                            TbConsumerVisit obj = new TbConsumerVisit();
                            obj.ConsumerNumber = CnsmrObj.ConsumerNumber;
                            obj.CrtDt = DateTime.Now;
                            obj.CrtBy = UsrId;

                            db.TbConsumerVisit.Add(obj);
                            db.SaveChanges();

                            TbConsumerUpdateHistory HistoryObj = new TbConsumerUpdateHistory()
                            {
                                ConsumerNumber = consumer.ConsumerNumber,
                                NewMeterNumber = consumer.NewMeter_Number,
                                OldMeterNumber = consumer.OldMeter_Number,
                                OldMeterReading = consumer.OldMeter_Reading,
                                BoxSeal1 = consumer.BoxSeal1,
                                BoxSeal2 = consumer.BoxSeal2,
                                Address = consumer.Address,
                                MobileNumber = consumer.MobileNumber,
                                Latitude = consumer.Latitude,
                                Longitude = consumer.Longitude,
                                InstalledDate = consumer.InstalledDate != null ? consumer.InstalledDate : null,
                                NewMeterImage = consumer.newMeterImage != null ? _commonRepository.ImageUpload(consumer.newMeterImage, "Oldmeter1") : CnsmrObj.NewMeterImage,
                                LatestEleBillImage = consumer.latest_Ele_BillImage != null ? _commonRepository.ImageUpload(consumer.latest_Ele_BillImage, "Oldmeter1") : CnsmrObj.LatestEleBillImage,
                                CrtDate = consumer.CrtDate != null ? consumer.CrtDate : DateTime.Now,
                                CrtBy = UsrId,
                            };

                            db.TbConsumerUpdateHistory.Add(HistoryObj);
                            db.SaveChanges();

                            ResObj.Status = true;
                            ResObj.Messege = "Consumer & Meter Details Updated Successfully!";
                            return ResObj;
                        }                        
                    }
                    else
                    {
                        ResObj.Status = false;
                        ResObj.Messege = "Consumer Number cannot be blank, Please check!";
                        return ResObj;
                    }
                    //var uploads = Path.Combine(env.WebRootPath, "images");
                    //bool exists = Directory.Exists(uploads);
                    //if (!exists)
                    //    Directory.CreateDirectory(uploads);

                    //var fileName = consumer.meterImage.FileName;
                    //var fileStream = new FileStream(Path.Combine(uploads, consumer.meterImage.FileName), FileMode.Create);
                    //string mimeType = consumer.meterImage.ContentType;
                    //byte[] fileData = new byte[consumer.meterImage.Length];

                    //BlobStorageService objBlobService = new BlobStorageService();

                    //consumer.ImagePath = objBlobService.UploadFileToBlob(consumer.meterImage.FileName, fileData, mimeType);
                    
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("ConsumerRepMock-UpdateConsumerData", "", ex.Message);
                return new ResponseModel { Status = false, Result = ex, Messege = "Something Went Wrong !" };
            }
        }

        public ResponseModel CnsmrOldNewMtrDetailsByCnsmr(int Id)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    //var BasePathOldMeter = Convert.ToString(_configuration.GetSection("BasePath").GetSection("api").Value + "Resources/Images/Oldmeter/");                    
                    ConsumerDataModel ConsumerObj = (from item in db.TbConsumers
                                                     where item.Id == Id
                                                     select new ConsumerDataModel
                                                     {
                                                         Id = item.Id,
                                                         ConsumerNumber = item.ConsumerNumber,
                                                         Address = item.Address,
                                                         MobileNumber = item.MobileNumber,
                                                         NewMeter_Number = item.NewMeterNumber,
                                                         OldMeter_Number = item.OldMeterNumber,
                                                         OldMeter_Reading = item.OldMeterReading,
                                                         BoxSeal1 = item.BoxSeal1,
                                                         BoxSeal2 = item.BoxSeal2,
                                                         InstalledDate = item.InstalledDate,
                                                         //IdProofImage = Convert.ToString(item.IdProofImage) == null ? null : (Convert.ToString(BasePathIdproof) + Convert.ToString(item.IdProofImage)),
                                                         NewMeterImage = item.NewMeterImage == null ? null : item.NewMeterImage,
                                                         Latest_Ele_BillImage = item.LatestEleBillImage == null ? null : item.LatestEleBillImage,
                                                         Latitude = item.Latitude,
                                                         Longitude = item.Longitude,
                                                         CrtName = db.TbUser.FirstOrDefault(x => x.Id == item.CrtBy).UserName,
                                                         CrtDate = item.CrtDate,
                                                         UpdBy = item.UpdBy,
                                                         UpdName = db.TbUser.FirstOrDefault(x => x.Id == item.UpdBy).UserName,
                                                         UpdDate = item.UpdDate,
                                                     }).FirstOrDefault();

                    ResponseModel ResObj = new ResponseModel
                    {

                        Status = true,
                        Result = new { ConsumerObj = ConsumerObj },
                        Messege = "Consumer Detials By Consumer!"
                    };

                    return ResObj;
                }

            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("ConsumerRepMock-CnsmrOldNewMtrDetailsByCnsmr", "", ex.Message);
                ResponseModel ResObj = new ResponseModel
                {
                    Status = true,
                    Result = ex,
                    Messege = "Something Went Wrong"
                };

                return ResObj;
            }

        }

        ResponseModel IConsumerRepository.GetConsumers(int numPerPage, int pageNum, string searchString, int uId, int roleId, int consType)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    if (!string.IsNullOrEmpty(searchString))
                    {
                        searchString = searchString.Replace("@", "/");
                        if (roleId == 1 || roleId == 3)
                        {
                            var list = (from item in db.TbConsumers
                                        where item.ConsumerNumber == searchString
                                        select new ConsumerDataModel
                                        {
                                            Id = item.Id,
                                            ConsumerNumber = item.ConsumerNumber,
                                            Address = item.Address,
                                            CrtDate = item.CrtDate,
                                            MobileNumber = item.MobileNumber,
                                            OldMeter_Number=item.OldMeterNumber,
                                            NewMeter_Number = item.NewMeterNumber
                                        });

                            var result = list.OrderByDescending(x => x.CrtDate).Skip((pageNum - 1) * numPerPage).Take(numPerPage).ToList();
                            var totalCount = list.Count();

                            ResponseModel ResObj = new ResponseModel { Status = true, Result = new { ConsumerList = result, totalCount = totalCount }, Messege = "Consumer List" };

                            return ResObj;
                        }
                        else
                        {
                            ResponseModel ResObj = new ResponseModel { Status = false, Result = new { ConsumerList = 0, totalCount = 0 }, Messege = "This User type not allowed to access the list!" };

                            return ResObj;
                        }
                    }
                    else
                    {
                        if (roleId == 1 || roleId == 3)
                        {
                            var list = (from item in db.TbConsumers
                                        //where isInd.Contains(item.IsIndexed) && appStatus.Contains(item.ApprovalStatus)
                                        select new ConsumerDataModel
                                        {

                                            Id = item.Id,
                                            ConsumerNumber = item.ConsumerNumber,
                                            Address = item.Address,
                                            CrtDate = item.CrtDate,
                                            MobileNumber = item.MobileNumber,
                                            OldMeter_Number = item.OldMeterNumber,
                                            NewMeter_Number = item.NewMeterNumber
                                        });

                            var result = list.OrderByDescending(x => x.CrtDate).Skip((pageNum - 1) * numPerPage).Take(numPerPage).ToList();
                            var totalCount = list.Count();

                            ResponseModel ResObj = new ResponseModel { Status = true, Result = new { ConsumerList = result, totalCount = totalCount }, Messege = "Consumer List" };

                            return ResObj;
                        }
                        else
                        {
                            ResponseModel ResObj = new ResponseModel { Status = false, Result = new { ConsumerList = 0, totalCount = 0 }, Messege = "This User type not allowed to access the list!" };

                            return ResObj;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("ConsumerRepMock-GetConsumers", "", ex.Message);
                ResponseModel ResObj = new ResponseModel { Status = false, Result = ex, Messege = "Something Went Wrong" };
                return null;
            }
        }

        ResponseModel IConsumerRepository.GetConsumerList(int roleId)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    if (roleId == 1 || roleId == 3)
                    {
                        var list = (from item in db.TbConsumers
                                    select new ConsumerDataModel
                                    {
                                        Id = item.Id,
                                        ConsumerNumber = item.ConsumerNumber,
                                        Address = item.Address,
                                        MobileNumber = item.MobileNumber,
                                        OldMeter_Number = item.OldMeterNumber,
                                        OldMeter_Reading = item.OldMeterReading,
                                        NewMeter_Number = item.NewMeterNumber,
                                        InstalledDate = item.InstalledDate,
                                        NewMeterImage = item.NewMeterImage,
                                        Latest_Ele_BillImage = item.LatestEleBillImage,
                                        Latitude = item.Latitude,
                                        Longitude = item.Longitude,
                                        BoxSeal1 = item.BoxSeal1,
                                        BoxSeal2 = item.BoxSeal2,
                                        CrtDate = item.CrtDate,
                                        CrtName = db.TbUser.FirstOrDefault(x=>x.Id==item.CrtBy).UserName,
                                        UpdDate = item.UpdDate,
                                        UpdName = db.TbUser.FirstOrDefault(x => x.Id == item.UpdBy).UserName,
                                    }).OrderByDescending(x=>x.CrtDate);

                        var result = list.ToList();
                        var totalCount = list.Count();

                        ResponseModel ResObj = new ResponseModel { Status = true, Result = new { ConsumerList = result, totalCount = totalCount }, Messege = "Consumer List" };

                        return ResObj;
                    }
                    else
                    {
                        ResponseModel ResObj = new ResponseModel { Status = false, Result = new { ConsumerList = 0, totalCount = 0 }, Messege = "This User type not allowed to access the list!" };

                        return ResObj;
                    }
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("ConsumerRepMock-GetConsumerList", "", ex.Message);
                ResponseModel ResObj = new ResponseModel { Status = false, Result = ex, Messege = "Something Went Wrong" };
                return null;
            }
        }

        /* Code For Listing Consumers For Mobile For FE And Supervisior Login */
        ResponseModel IConsumerRepository.GetConsumersByStatOffLine(ConsumerListModelParam Filterpamrams)
        {
            try
            {
                using (DiscomkarvyContext db = new DiscomkarvyContext())
                {
                    List<ConsumerDataModel> ConsOldMeter = new List<ConsumerDataModel>();
                    var today = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yy 00:00:00"));
                    if (!string.IsNullOrEmpty(Filterpamrams.SearchString))
                    {
                        ResponseModel ResObj = new ResponseModel();
                        if (Filterpamrams.RoleId == 1 || Filterpamrams.RoleId == 2)
                        {
                            ConsOldMeter = (from item in db.TbConsumers
                                            where (item.ConsumerNumber.ToString().Contains(Filterpamrams.SearchString))
                                            where item.CrtBy == Filterpamrams.UserId
                                            && (item.CrtDate >= today && item.CrtDate < today.AddDays(1))
                                            select new ConsumerDataModel
                                            {
                                                Id = item.Id,
                                                ConsumerNumber = item.ConsumerNumber,
                                                Address = item.Address,
                                                MobileNumber = item.MobileNumber,
                                                NewMeter_Number = item.NewMeterNumber,
                                                OldMeter_Number = item.OldMeterNumber,
                                                OldMeter_Reading = item.OldMeterReading,
                                                BoxSeal1=item.BoxSeal1,
                                                BoxSeal2=item.BoxSeal2,
                                                Latitude =item.Latitude,
                                                Longitude=item.Longitude,
                                                InstalledDate = item.InstalledDate,
                                                CrtDate = item.CrtDate,
                                                CrtBy = item.CrtBy,
                                                //IdProofImage = Convert.ToString(item.IdProofImage) == null ? null : Convert.ToString(item.IdProofImage),
                                                //OldMeterImage = Convert.ToString(item.NewMeterImage) == null ? null : Convert.ToString(item.NewMeterImage),
                                                //OldMeterImage1 = Convert.ToString(item.LatestEleBillImage) == null ? null : Convert.ToString(item.LatestEleBillImage),                                                

                                            }).OrderByDescending(x => x.Id).ToList();
                                                          
                            ResObj.Status = true;
                            ResObj.Result = ConsOldMeter;
                            ResObj.Messege = "Consumer List";
                        }
                        else
                        {
                            ResObj.Status = false;
                            ResObj.Result = ConsOldMeter;
                            ResObj.Messege = "Something Went Wrong!";
                        }

                        return ResObj;
                    }
                    else
                    {
                        ResponseModel ResObj = new ResponseModel();

                        if (Filterpamrams.RoleId == 1 || Filterpamrams.RoleId == 2)
                        {
                            ConsOldMeter = (from item in db.TbConsumers
                                            where item.CrtBy == Filterpamrams.UserId
                                            && (item.CrtDate >= today && item.CrtDate < today.AddDays(1))
                                            select new ConsumerDataModel
                                            {
                                                Id = item.Id,
                                                ConsumerNumber = item.ConsumerNumber,
                                                Address = item.Address,
                                                MobileNumber = item.MobileNumber,
                                                NewMeter_Number = item.NewMeterNumber,
                                                OldMeter_Number = item.OldMeterNumber,
                                                OldMeter_Reading = item.OldMeterReading,
                                                BoxSeal1 = item.BoxSeal1,
                                                BoxSeal2 = item.BoxSeal2,
                                                Latitude = item.Latitude,
                                                Longitude = item.Longitude,
                                                InstalledDate = item.InstalledDate,
                                                CrtDate=item.CrtDate,
                                                CrtBy=item.CrtBy,
                                            }).OrderByDescending(x => x.CrtDate).ToList();

                            if (ConsOldMeter.Count > 0)
                            {
                                ResObj.Status = true;
                                ResObj.Result = ConsOldMeter;
                                ResObj.Messege = "Consumer List!";
                            }
                            else
                            {
                                ResObj.Status = false;
                                ResObj.Result = ConsOldMeter;
                                ResObj.Messege = "No Consumer List found today!";
                            }
                        }                        
                        else
                        {
                            ResObj.Status = false;
                            ResObj.Result = ConsOldMeter;
                            ResObj.Messege = "Something Went Wrong!";
                        }

                        return ResObj;
                    }
                }
            }
            catch (Exception ex)
            {
                CommonRepoMock.writeLog("ConsumerRepMock-GetConsumersByStatOffLine", "", ex.Message);
                ResponseModel ResObj = new ResponseModel { Status = false, Result = ex, Messege = "Something Went Wrong" };
                return null;
            }
        }
               
        //public ResponseModel ConsumerUpdateUpload(UploadConsumerUpdateModelTest MasterList, int createdBy)
        //{
        //    try
        //    {
        //        using (DiscomkarvyContext db = new DiscomkarvyContext())
        //        {
        //            int i = 0;
        //            var totalRows = MasterList.UploadConsumerUpdate.Count();

        //            var deleteLogTable = from a in db.TbExcelconsumerupdatelog select a;
        //            db.TbExcelconsumerupdatelog.RemoveRange(deleteLogTable);
        //            db.SaveChanges();

        //            MySqlConnection mySQLCon = new MySqlConnection("server=localhost;Database=Discom;user id=username;password=password;");
        //            //MySqlConnection mySQLCon = new MySqlConnection("server=192.168.83.57;Database=Discom;user id=username;password=password;");
                    
        //            if (mySQLCon.State.ToString() == "Closed")
        //            {
        //                mySQLCon.Open();
        //            }
        //            MySqlCommand mySQLCmd;
        //            string strSQLPend = "";
        //            string subSQL1 = "";
        //            //string subSQL = MasterList.columnName;                                        

        //            TbExcelconsumerupdatelog objExcel = new TbExcelconsumerupdatelog();
                    
        //            foreach (var data in MasterList.UploadConsumerUpdate)
        //            {                        
        //                bool check = true;
        //                if (MasterList.columnName == "QueryEditor1")
        //                {
        //                    strSQLPend = "" + data.QueryEditor1 + "";
        //                    mySQLCmd = new MySqlCommand(strSQLPend, mySQLCon);
        //                    var resPend = Convert.ToInt32(mySQLCmd.ExecuteScalar());
        //                    i++;
        //                }
        //                else if (string.IsNullOrEmpty(data.ConsumerNumber) || data.ConsumerNumber != null && data.ConsumerNumber.Length > 12)
        //                {
        //                    objExcel.Remarks = "Consumer Number should not empty (or) Consumer Number should not reach more than 12 characters!";
        //                    check = false;
        //                }
        //                //else if (data.ConsumerNumber != null && data.ConsumerNumber.All(char.IsDigit) == false)
        //                //{
        //                //    check = false;
        //                //    objExcel.Remarks = "Consumer Number should be numeric !";
        //                //}
        //                else
        //                {
        //                    var objConsumer = db.TbConsumers.Where(x => x.ConsumerNumber.ToString() == data.ConsumerNumber.ToString()).Select(x => x).FirstOrDefault();

        //                    if (objConsumer != null)
        //                    {
        //                        if (MasterList.columnName == "QueryEditor")
        //                        {
        //                            if (objConsumer.IsIndexed == 2)
        //                            {
        //                                strSQLPend = "" + data.QueryEditor + "";
        //                            }
        //                            else if (objConsumer.IsIndexed == 3)
        //                            {
        //                                check = false;
        //                                objExcel.Remarks = "New Meter Installation Already Done!";
        //                                goto QE;
        //                            }
        //                            else if (objConsumer.IsIndexed == 1)
        //                            {
        //                                check = false;
        //                                objExcel.Remarks = "Indexing Not Yet Done!";
        //                                goto QE;
        //                            }
        //                        }
        //                        else if (MasterList.columnName == "Mobile_Number")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Mobile_Number + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Email")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Email + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Meter_Number")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Meter_Number + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Meter_Manufacturer")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Meter_Manufacturer + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Meter_Reading")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Meter_Reading + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Current_KWH")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Current_KWH + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Current_KVAH")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Current_KVAH + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Current_KVA")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Current_KVA + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "ExistMeterSealStatus")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.ExistMeterSealStatus + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "SealingStatus")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.SealingStatus + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "StatusofServicecable")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.StatusofServicecable + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "NoofJointsInServiceCable")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.NoofJointsInServiceCable + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "ServiceLineStatus")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.ServiceLineStatus + "'";
        //                            strSQLPend = "update tb_oldmeters set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "signalStrength")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.signalStrength + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "signalLevel")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.signalLevel + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "signalCategory")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.signalCategory + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "IsWired")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.IsWired + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else if (MasterList.columnName == "Address")
        //                        {
        //                            subSQL1 = MasterList.columnName + "='" + data.Address + "'";
        //                            strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";
        //                        }
        //                        else
        //                        {
        //                            ResponseModel ResObj = new ResponseModel { Status = false, Messege = "Invalid Column Name, please check the list" };
        //                            return ResObj;                                    
        //                        }
        //                        //string strSQLPend = "update tb_consumers set " + subSQL1 + " where Consumer_Number='" + data.ConsumerNumber + "'";

        //                        mySQLCmd = new MySqlCommand(strSQLPend, mySQLCon);
        //                        var resPend = Convert.ToInt32(mySQLCmd.ExecuteScalar());
        //                        i++;                                
        //                    }
        //                    else
        //                    {
        //                        check = false;
        //                        objExcel.Remarks = "Consumer Number does not exist!";
        //                    }
        //                }
        //                QE:
        //                if (check == false)
        //                {
        //                    TbExcelconsumerupdatelog objConsumers = new TbExcelconsumerupdatelog();
        //                    objConsumers.ConsumerNumber = data.ConsumerNumber;
        //                    objConsumers.Remarks = objExcel.Remarks;
        //                    db.TbExcelconsumerupdatelog.Add(objConsumers);
        //                    db.SaveChanges();
        //                }
        //            }

        //            if (totalRows == 0)
        //            {
        //                ResponseModel ResObj = new ResponseModel { Status = true, Messege = " No Records in Uploaded Excel File!" };
        //                return ResObj;
        //            }
        //            else if (i != totalRows)
        //            {
        //                var RejectedRecords = totalRows - i;

        //                ResponseModel ResObj = new ResponseModel { Status = true, Messege = i + " : Records Uploaded Succssfully And " + RejectedRecords + " : Records Failed !" };
        //                return ResObj;
        //            }
        //            else
        //            {
        //                ResponseModel ResObj = new ResponseModel { Status = true, Messege = totalRows + " : Records Uploaded Successfully !" };
        //                return ResObj;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        CommonRepoMock.writeLog("ConsumerRepMock-ConsumerUpdateUpload", "", ex.Message);
        //        ResponseModel ResObj = new ResponseModel { Status = false, Messege = ex.Message };
        //        return ResObj;
        //    }
        //}

        //public ResponseModel GetUploadLogs_CDUpate()
        //{
        //    try
        //    {
        //        using (DiscomkarvyContext db = new DiscomkarvyContext())
        //        {
        //            var Result = db.TbExcelconsumerupdatelog.Select(y => y).ToList();
        //            if (Result.Count > 0)
        //            {
        //                ResponseModel ResObj = new ResponseModel { Status = true, Result = Result, Messege = "Upload Log List." };
        //                return ResObj;
        //            }
        //            else
        //            {
        //                ResponseModel ResObj = new ResponseModel { Status = true, Result = Result, Messege = "No records found." };
        //                return ResObj;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        CommonRepoMock.writeLog("ConsumerRepMock-GetUploadLogs_CDUpate", "", ex.Message);
        //        ResponseModel ResObj = new ResponseModel { Status = false, Result = ex, Messege = "Something went wrong." };
        //        return ResObj;
        //    }
        //}
                
    }
}
