﻿using DisCom.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.Contracts   
{
    public interface IRoleRepository
    {
        ResponseModel GetRoles();

        ResponseModel GetActiveRoles();

        ResponseModel CreateRole(TbRoleModel role);

        ResponseModel UpdateRole(TbRoleModel role);
    }
}
