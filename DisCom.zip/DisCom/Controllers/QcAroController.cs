﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisCom.Models.Contracts;
using DisCom.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DisCom.Controllers
{
    [Route("api/[controller]")]
    [ApiController, Authorize]
    public class QcAroController : ControllerBase
    {
        private readonly IQcAroRepository _qcAroRepository;

        public QcAroController(IQcAroRepository qcAroRepository)
        {
            _qcAroRepository = qcAroRepository;
        }

        [HttpGet, Route("GetQcPendings_CI/{type}")]
        public ActionResult GetQcPendings_CI(string type)
        {
            try
            {
                ResponseModel ResObj = _qcAroRepository.GetQcPendings_CI(type);
                if (ResObj.Status == true)
                {
                    return Ok(ResObj);
                }
                else if (ResObj.Status == false && ResObj.Messege != "Something Went Wrong !")
                {
                    return Ok(ResObj);
                }
                else
                {
                    return BadRequest(ResObj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
                
        [HttpPost, Route("UpdateQc_CI")]
        public ActionResult UpdateQc_CI(QcHistoryModel details)
        {
            try
            {
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var UsrId = Convert.ToInt32(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value);
                ResponseModel ResObj = _qcAroRepository.UpdateQc_CI(details, UsrId);
                if (ResObj.Status == true)
                {
                    return Ok(ResObj);
                }
                else if (ResObj.Status == false && ResObj.Messege != "Something Went Wrong !")
                {
                    return Ok(ResObj);
                }
                else
                {
                    return BadRequest(ResObj);
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        
    }
}