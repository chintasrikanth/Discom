﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DisCom.Models.ViewModels
{
    public class QcHistoryModel
    {
        public int Id { get; set; }
        public string ConsumerNumber { get; set; }
        public string NewMeter_Number { get; set; }
        public string OldMeter_Number { get; set; }
        public string OldMeter_Reading { get; set; }
        public string BoxSeal1 { get; set; }
        public string BoxSeal2 { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public IFormFile newMeterImage { get; set; }
        public IFormFile latest_Ele_BillImage { get; set; }
        public string NewMeterImage { get; set; }
        public string Latest_Ele_BillImage { get; set; }
        public DateTime? InstalledDate { get; set; }
        public DateTime? CrtDate { get; set; }
        public int? CrtBy { get; set; }
        public string CrtName { get; set; }
        public DateTime? UpdDate { get; set; }
        public int? UpdBy { get; set; }
        public string type { get; set; }
        public string updType { get; set; }
        public List<uploadFiles> fileUploadList { get; set; }
        public List<uploadFiles> fileUploadListOld { get; set; }
    }
    public class uploadFiles
    {
        public string fileBytes { get; set; }
        public string name { get; set; }
        public string extension { get; set; }
    }
}
